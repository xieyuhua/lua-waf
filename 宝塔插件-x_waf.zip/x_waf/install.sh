#!/bin/bash
# ============================================================================
#  x_waf —— 宝塔面板 Nginx Lua 网站防火墙（x_waf 分支）
#  安装 / 更新 / 卸载入口：install.sh install | update | uninstall [purge]
#
#  目录约定（要改名只改下面两处：本文件顶部变量 + x_waf_main.py 顶部常量）：
#    $pluginPath  面板插件目录
#    $waf_path    运行时目录（lua 引擎 / 规则 / 配置）
#                 —— 已由 /www/server/free_waf 迁移到 /www/server/x_waf
#    $waf_log     拦截日志目录
# ============================================================================

export PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:$PATH

plugin_name='x_waf'
pluginPath="/www/server/panel/plugin/${plugin_name}"
waf_path='/www/server/x_waf'
waf_log='/www/wwwlogs/x_waf_log'

legacy_waf_path='/www/server/free_waf'
legacy_waf_log='/www/wwwlogs/free_waf_log'

nginx_dir='/www/server/nginx'
nginx_bin="${nginx_dir}/sbin/nginx"
nginx_conf="${nginx_dir}/conf/nginx.conf"
# vhost 目录不再写死：由 resolve_vhost_dir() 从 nginx.conf 里探测，
# 探测不到就创建并把 include 补进 nginx.conf（很多环境没有 /www/server/panel/vhost/nginx）
vhost_dir='/www/server/panel/vhost/nginx'
VHOST_DIR=''
VHOST_GLOB=''
conf_name='x_waf.conf'
icon_name="ico-${plugin_name}.png"
icon_dir='/www/server/panel/static/img/soft_ico'
install_tmp='/tmp/bt_install.pl'
data_zip="${pluginPath}/x_waf_data.zip"
tmp_data='/tmp/x_waf_data'

# ---------------------------------------------------------------------------
# 安装日志：全程写文件 + 同步打到标准输出（面板"安装日志"窗口能实时看到）
# ---------------------------------------------------------------------------
LOG_FILE="${waf_path}/install.log"
mkdir -p "$waf_path" 2>/dev/null || LOG_FILE='/tmp/x_waf_install.log'
: > "$LOG_FILE" 2>/dev/null || LOG_FILE='/tmp/x_waf_install.log'
if command -v tee >/dev/null 2>&1; then
    exec > >(tee -a "$LOG_FILE") 2>&1
fi

# 输出一条带时间戳的信息日志（同时写 install.log）
info(){ echo "[$(date '+%H:%M:%S')] $*"; }
# 输出警告日志
warn(){ echo "[$(date '+%H:%M:%S')] [警告] $*"; }
# 输出分步标题（1/8、2/8 …）
step(){ echo; echo "[$(date '+%H:%M:%S')] ===== $* ====="; }
# 执行命令并把输出记进安装日志
run(){   # 执行并记录命令，失败时把输出留在日志里
    info "\$ $*"
    eval "$@" 2>&1
}

# 致命错误：打印原因并退出安装
die(){
    echo "[$(date '+%H:%M:%S')] [失败] $*"
    echo "$@" > "$install_tmp"
    echo "详细安装日志：$LOG_FILE"
    exit 1
}

# 平滑重载 nginx（失败不退出）
reload_nginx(){
    if [ -x /etc/init.d/nginx ]; then
        /etc/init.d/nginx reload >/dev/null 2>&1 || /etc/init.d/nginx restart >/dev/null 2>&1
    else
        "$nginx_bin" -s reload >/dev/null 2>&1
    fi
}

NGINX_RESTART_RC=0
# 重启 nginx，退出码记到 NGINX_RESTART_RC
restart_nginx(){
    if [ -x /etc/init.d/nginx ]; then
        /etc/init.d/nginx restart >/tmp/x_waf_restart.log 2>&1
        NGINX_RESTART_RC=$?
    else
        # 注意：nginx -s 没有 restart 子命令
        {
            "$nginx_bin" -s stop
            sleep 1
            "$nginx_bin"
        } >/tmp/x_waf_restart.log 2>&1
        NGINX_RESTART_RC=$?
    fi
    sleep 1
    return 0
}

# 软检测：nginx 到底有没有在跑。只用来看日志，不再作为安装失败的判据
# （不同机器上 80 端口没站点 / 没装 ss / 没装 pgrep 都会导致误判）
nginx_running(){
    local pidfile="${nginx_dir}/logs/nginx.pid"
    if [ -f "$pidfile" ]; then
        kill -0 "$(cat "$pidfile" 2>/dev/null)" 2>/dev/null && return 0
    fi
    ps -ef 2>/dev/null | grep -q '[n]ginx: master' && return 0
    command -v pgrep >/dev/null 2>&1 && pgrep -f 'nginx: master' >/dev/null 2>&1 && return 0
    command -v ss >/dev/null 2>&1 && ss -lntp 2>/dev/null | grep -q nginx && return 0
    command -v curl >/dev/null 2>&1 && curl -s -o /dev/null -m 3 http://127.0.0.1/ && return 0
    return 1
}

# ---------------------------------------------------------------------------
# 0. 前置检查：环境、冲突
# ---------------------------------------------------------------------------
check_env(){
    step "1/8 环境检查"
    info "Nginx     : $nginx_bin"
    info "nginx.conf: $nginx_conf"
    [ -x "$nginx_bin" ] || die "未检测到 Nginx（$nginx_bin），本插件仅支持 Nginx 环境"
    [ -f "$nginx_conf" ] || die "未找到 nginx 主配置（$nginx_conf），请确认 Nginx 安装完整"
    info "Nginx 版本: $("$nginx_bin" -v 2>&1)"

    # lua 模块是硬前提：没有它，lua_shared_dict/init_by_lua_file 全是未知指令，装完 nginx 起不来
    if lua_module_ok; then
        info "lua 模块 : 已编译"
    else
        warn "当前 Nginx 未探测到 lua 模块（lua_nginx_module / ngx_http_lua）"
        if [ "$FORCE" != "1" ]; then
            die "当前 Nginx 未编译 lua 模块，装上也无法拦截。请到面板【软件商店 → Nginx】切换/重装为 1.22 或 1.24（宝塔官方源默认带 lua 模块）后再装。确要强行继续请设 FORCE=1。"
        fi
    fi

    if [ -f "${vhost_dir}/btwaf.conf" ]; then
        die "检测到宝塔付费版「Nginx 网站防火墙」(btwaf.conf)，两者使用同名 lua 共享内存，不能共存。请先卸载付费版再安装 x_waf。"
    fi
    if [ -f "${vhost_dir}/free_waf.conf" ]; then
        warn "检测到原版「Nginx免费防火墙」的 free_waf.conf，将移除它避免 lua_shared_dict 重名"
    fi
    if [ -d "$legacy_waf_path" ]; then
        warn "检测到旧运行时目录 $legacy_waf_path：会优先从它复制 lua 引擎；装好后请在面板卸载原版插件，否则两边会互相覆盖配置"
    fi

    # 旧版残留：只清理本插件自己的 nginx 包含文件
    if [ -f "${vhost_dir}/free_waf.conf" ]; then
        rm -f "${vhost_dir}/free_waf.conf"
        info "已移除旧版 ${vhost_dir}/free_waf.conf"
    fi
    # 清理上次安装失败残留在四层目录（tcp/udp）里的本插件配置
    local stray
    for stray in "${vhost_dir}/tcp/${conf_name}" "${vhost_dir}/udp/${conf_name}"; do
        if [ -f "$stray" ]; then
            rm -f "$stray"
            warn "已清理上次失败残留：$stray"
        fi
    done
    return 0
}

# 是否编译了 lua 模块（BT 1.22+ 与 OpenResty 都带）
lua_module_ok(){
    local v
    v=$("$nginx_bin" -V 2>&1)
    echo "$v" | grep -qiE 'lua[-_]nginx[-_]module|ngx_http_lua|openresty|ngx_devel_kit' && return 0
    [ -d "${nginx_dir}/lib/lua/ngx" ] && return 0
    [ -d "${nginx_dir}/lualib/ngx" ] && return 0
    return 1
}

# ---------------------------------------------------------------------------
# 0.1 定位 nginx 的 vhost 包含目录
#     宝塔 nginx.conf 里通常有三类包含：
#       include /www/server/panel/vhost/nginx/*.conf;        <- 站点配置（http 上下文，正确位置）
#       include /www/server/panel/vhost/rewrite/*.conf;      <- 站点重写（server 上下文，不能用）
#       include /www/server/panel/vhost/nginx/tcp/*.conf;    <- 四层转发（stream 上下文，绝不能用！）
#     放到 stream 上下文里会直接报 "access_by_lua_file directive is not allowed here"
# ---------------------------------------------------------------------------
vhost_candidates(){
    [ -f "$nginx_conf" ] || return 0
    grep -hoE '^[[:space:]]*include[[:space:]]+[^;]*vhost[^;]*\.conf' "$nginx_conf" 2>/dev/null \
      | sed -E 's/^[[:space:]]*include[[:space:]]+//; s/;.*$//; s/[[:space:]]+$//' \
      | grep -viE 'rewrite|/tcp/|/udp/|stream' \
      | while read -r g; do dirname "$g"; done \
      | awk '!seen[$0]++'
}

# 确定最终把 x_waf.conf 写到哪个目录（含目录不存在时创建）
resolve_vhost_dir(){
    VHOST_DIR=''
    local dir
    for dir in $(vhost_candidates); do
        VHOST_DIR="$dir"
        VHOST_GLOB="${VHOST_DIR}/*.conf"
        [ -d "$VHOST_DIR" ] || mkdir -p "$VHOST_DIR" 2>/dev/null
        info "候选站点配置目录：$VHOST_DIR"
        return 0
    done
    VHOST_DIR="$vhost_dir"
    VHOST_GLOB="${VHOST_DIR}/*.conf"
    mkdir -p "$VHOST_DIR" 2>/dev/null || die "无法创建目录 $VHOST_DIR"
    info "nginx.conf 中没有 http 级 vhost 包含，改用默认目录 $VHOST_DIR 并补写 include"
    return 0
}

# nginx -t 双通道校验：既测编译内置的默认配置，也测宝塔实际使用的那份
nginx_t_check(){
    local out1 out2
    out1=$("$nginx_bin" -t 2>&1)
    out2=$("$nginx_bin" -t -c "$nginx_conf" 2>&1)
    {
        echo "--- nginx -t（编译默认配置） ---"
        echo "$out1"
        echo "--- nginx -t -c ${nginx_conf} ---"
        echo "$out2"
    } > /tmp/x_waf_nginx_test.log
    if echo "$out1 $out2" | grep -qi 'emerg'; then
        return 1
    fi
    echo "$out1 $out2" | grep -q 'test is successful' || return 1
    return 0
}

# 往 nginx.conf 的 http{} 里补 include（仅当没有任何 http 级 vhost 包含时）
ensure_include(){
    if grep -qF "include ${VHOST_DIR}/${conf_name};" "$nginx_conf" 2>/dev/null; then
        return 0
    fi
    cp -f "$nginx_conf" "${nginx_conf}.x_waf.bak"
    awk -v ins="    include ${VHOST_DIR}/${conf_name};" '
        BEGIN{done=0}
        {
            if (!done && $0 ~ /^[[:space:]]*http[[:space:]]*\{/) {
                print; print ins; done=1; next
            }
            print
        }' "${nginx_conf}.x_waf.bak" > "$nginx_conf"
    if ! nginx_t_check; then
        cp -f "${nginx_conf}.x_waf.bak" "$nginx_conf"
        warn "往 nginx.conf 写入 include 后校验失败，已还原"
        return 1
    fi
    mkdir -p "$waf_path" 2>/dev/null
    : > "${waf_path}/.nginx_include_added"
    info "已把 include ${VHOST_DIR}/${conf_name}; 写入 nginx.conf（备份 ${nginx_conf}.x_waf.bak）"
    return 0
}

# 写入包含文件，直到某个候选目录能通过 nginx -t 为止
install_conf(){
    local dir ok=0
    for dir in $(vhost_candidates) "$vhost_dir"; do
        [ -n "$dir" ] || continue
        mkdir -p "$dir" 2>/dev/null || continue
        \cp -f "${pluginPath}/${conf_name}" "$dir/${conf_name}" 2>/dev/null || continue
        VHOST_DIR="$dir"
        if nginx_t_check; then
            info "包含文件写入并通过 nginx -t：${dir}/${conf_name}"
            return 0
        fi
        warn "${dir} 放进去后 nginx -t 不通过（可能不是 http 上下文），已移除并尝试下一个目录"
        rm -f "$dir/${conf_name}"
    done

    # 所有已有候选都不行：用默认目录 + 主动往 http{} 补 include
    VHOST_DIR="$vhost_dir"
    mkdir -p "$VHOST_DIR" 2>/dev/null || die "无法创建目录 $VHOST_DIR"
    \cp -f "${pluginPath}/${conf_name}" "${VHOST_DIR}/${conf_name}" 2>/dev/null || die "复制 ${conf_name} 失败（权限？）"
    if ensure_include && nginx_t_check; then
        info "包含文件写入并通过 nginx -t：${VHOST_DIR}/${conf_name}"
        return 0
    fi
    rm -f "${VHOST_DIR}/${conf_name}"
    return 1
}

# 卸载时移除 resolve_vhost_dir 加进去的那行 include
remove_added_include(){
    [ -f "${waf_path}/.nginx_include_added" ] || return 0
    if grep -qF "include ${VHOST_DIR}/${conf_name};" "$nginx_conf" 2>/dev/null; then
        grep -vF "include ${VHOST_DIR}/${conf_name};" "$nginx_conf" > "${nginx_conf}.tmp" && \
            mv -f "${nginx_conf}.tmp" "$nginx_conf"
        info "已从 nginx.conf 移除本插件写入的 include"
    fi
    rm -f "${waf_path}/.nginx_include_added"
    return 0
}

# ---------------------------------------------------------------------------
# 1. 准备 lua 引擎（waf.lua / init.lua / 规则 / 配置）
#    来源优先级：插件 data/ → x_waf_data.zip → 旧版插件目录 → 当前运行时目录
#    只要机器上还有一份能跑的引擎，就不必再找原始 zip
# ---------------------------------------------------------------------------
prepare_data(){
    step "2/8 准备 lua 引擎"
    DATA_SRC=''
    if [ -f "${pluginPath}/data/waf.lua" ]; then
        DATA_SRC="${pluginPath}/data"
        info "数据源：data/ 里的引擎（优先于内置引擎）"
    elif [ -f "${pluginPath}/waf.lua" ]; then
        DATA_SRC="${pluginPath}"
        info "数据源：插件自带的 x_waf lua 引擎"
    elif [ -f "${pluginPath}/free_waf/data/waf.lua" ]; then
        DATA_SRC="${pluginPath}/free_waf/data"
        info "数据源：原版插件目录"
    elif [ -f "$data_zip" ]; then
        rm -rf "$tmp_data"; mkdir -p "$tmp_data"
        unzip -o -q "$data_zip" -d "$tmp_data" >/dev/null 2>&1 || die "解压 $data_zip 失败"
        if [ -f "${tmp_data}/data/waf.lua" ]; then
            DATA_SRC="${tmp_data}/data"
        elif [ -f "${tmp_data}/waf.lua" ]; then
            DATA_SRC="$tmp_data"
        elif [ -f "${tmp_data}/free_waf/waf.lua" ]; then
            DATA_SRC="${tmp_data}/free_waf"
        elif [ -f "${tmp_data}/x_waf/waf.lua" ]; then
            DATA_SRC="${tmp_data}/x_waf"
        else
            die "压缩包里没有找到 waf.lua，无法安装"
        fi
        info "数据源：$data_zip"
    elif [ -f "${legacy_waf_path}/waf.lua" ]; then
        DATA_SRC="${legacy_waf_path}"
        info "数据源：旧版运行时目录 ${legacy_waf_path}（拷贝后会在新目录对齐路径）"
    elif [ -f "${waf_path}/waf.lua" ]; then
        DATA_SRC="${waf_path}"
        info "数据源：现有运行时目录（升级安装，原地保留）"
    else
        die "没有找到 lua 引擎文件（waf.lua / init.lua）。三种补齐方式任选其一：
  1) 把原插件包的 free_waf_data.zip 放到 ${pluginPath}/ 下重跑本脚本；
  2) 解压到 ${pluginPath}/data/（需含 waf.lua、init.lua，可选 rule/ html/）；
  3) 如果旧版插件还装在别的目录，把它的 *.lua 拷到 ${waf_path}/ 再重跑。"
    fi

    if ! ls "${DATA_SRC}"/*.lua >/dev/null 2>&1; then
        die "数据源 ${DATA_SRC} 里没有 .lua 文件，引擎不完整"
    fi
    info "引擎文件：$(ls "${DATA_SRC}"/*.lua 2>/dev/null | xargs -n1 basename 2>/dev/null | tr '\n' ' ')"
}

# ---------------------------------------------------------------------------
# 2. 编译安装 lua 5.1.5（引擎用 lua 命令行处理规则/蜘蛛池）
# ---------------------------------------------------------------------------
Install_lua515(){
    local top="${waf_path}/lua515"
    if [ -x "${top}/bin/lua" ]; then
        info "Lua 5.1.5 已存在，跳过"
        return 0
    fi
    local pkg="${pluginPath}/lua-5.1.5.tar.gz"
    if [ ! -f "$pkg" ]; then
        warn "缺少 lua-5.1.5.tar.gz，跳过（不影响面板与拦截功能）"
        return 0
    fi
    mkdir -p "$top"
    cd "$pluginPath" || return 1
    tar xzf lua-5.1.5.tar.gz >/dev/null 2>&1 || { warn "解压 lua 源码失败，跳过"; return 1; }
    cd lua-5.1.5 || { warn "进入 lua 源码目录失败，跳过"; return 1; }
    make clean >/dev/null 2>&1
    # generic 目标不依赖 readline，避免没装 libreadline-dev 的机器编译失败；失败再退回 linux
    if ! make generic install INSTALL_TOP="$top" >/dev/null 2>&1; then
        make linux install INSTALL_TOP="$top" >/dev/null 2>&1
    fi
    cd "$pluginPath" || return 1
    rm -rf lua-5.1.5
    if [ -x "${top}/bin/lua" ]; then
        info "Lua 5.1.5 安装完成：$("${top}/bin/lua" -e 'print(_VERSION)')"
    else
        warn "Lua 编译失败，跳过（系统自带 lua 时不影响使用）"
    fi
}

# ---------------------------------------------------------------------------
# 3. 安装 cjson（先用预编译 .so；架构/ABI 不匹配时回退源码编译）
# ---------------------------------------------------------------------------
cjson_ok(){
    command -v luajit >/dev/null 2>&1 || return 0
    ! luajit -e "require 'cjson'" 2>&1 | grep -q 'undefined symbol\|cannot open'
}

# 安装 lua-cjson：优先用预编译库，ABI 不匹配则源码编译
Install_cjson(){
    local pre="${pluginPath}/cjson.so"
    local dir
    local -a dirs=(/usr/local/lib/lua/5.1 /usr/lib64/lua/5.1 /usr/lib/lua/5.1)

    if [ -f "$pre" ]; then
        for dir in "${dirs[@]}"; do mkdir -p "$dir"; done
        \cp -f "$pre" "${waf_path}/cjson.so"
        for dir in "${dirs[@]}"; do \cp -f "$pre" "${dir}/cjson.so"; done
        if cjson_ok; then
            info "cjson 使用预编译库"
            return 0
        fi
        warn "预编译 cjson 与当前架构不匹配，改为源码编译"
    fi

    local pkg="${pluginPath}/lua-cjson-2.1.0.tar.gz"
    [ -f "$pkg" ] || { warn "缺少 lua-cjson-2.1.0.tar.gz，跳过"; return 0; }
    cd "$pluginPath" || return 1
    tar xzf lua-cjson-2.1.0.tar.gz >/dev/null 2>&1 || { warn "解压 cjson 源码失败，跳过"; return 0; }
    ( cd lua-cjson-2.1.0 && make clean >/dev/null 2>&1; make >/dev/null 2>&1 && make install >/dev/null 2>&1 )
    rm -rf lua-cjson-2.1.0
    if [ -f /usr/local/lib/lua/5.1/cjson.so ]; then
        for dir in "${dirs[@]}"; do mkdir -p "$dir"; \cp -f /usr/local/lib/lua/5.1/cjson.so "${dir}/cjson.so"; done
        \cp -f /usr/local/lib/lua/5.1/cjson.so "${waf_path}/cjson.so"
        info "cjson 编译安装完成"
    else
        warn "cjson 编译失败，请手动安装 lua-cjson"
    fi
}

# ---------------------------------------------------------------------------
# 4. 高版本 Nginx / OpenResty：把 lua 依赖库同步到运行时目录
# ---------------------------------------------------------------------------
sync_lualib(){
    # 说明：v2.1 起不再往运行时目录拷贝 lualib，也**不删除** resty/ngx。
    # 之前这里会 rm -rf resty，把 openresty 的 lua-resty-core 删掉，
    # 导致 nginx 启动报 "failed to load the 'resty.core' module"。
    local ver
    ver=$("$nginx_bin" -v 2>&1)
    info "nginx：$ver（lua 依赖走 openresty 自带 lualib，不做覆盖）"
    return 0
}

# ---------------------------------------------------------------------------
# 5. nginx.conf 里原有的 lua_package_path 会被我们的包含文件顶成重复指令，
#    用标记注释掉，卸载时精确还原（原版是直接删除，卸载后回不来）
# ---------------------------------------------------------------------------
disable_nginx_lua_path(){
    if grep -qE '^[[:space:]]*lua_package_path' "$nginx_conf"; then
        cp -f "$nginx_conf" "${nginx_conf}.x_waf.bak"
        sed -i -E 's|^([[:space:]]*)lua_package_path([[:space:]])|\1#x_waf-disabled:\2|' "$nginx_conf"
        info "已临时注释 nginx.conf 中的 lua_package_path（备份 ${nginx_conf}.x_waf.bak）"
    fi
}

# 还原被旧版本注释掉的 lua_package_path（恢复 openresty 默认搜索路径）
restore_nginx_lua_path(){
    [ -f "$nginx_conf" ] || return 0
    if grep -qE '^[[:space:]]*#x_waf-disabled:[[:space:]]*lua_package_path' "$nginx_conf"; then
        sed -i -E 's|^([[:space:]]*)#x_waf-disabled:[[:space:]]*|\1|' "$nginx_conf"
        info "已还原 nginx.conf 中的 lua_package_path"
    fi
}

# ---------------------------------------------------------------------------
# 6. 部署文件
# ---------------------------------------------------------------------------
copy_once(){   # 只在目标不存在时复制，保护用户改过的规则/配置
    local src="$1" dst="$2"
    [ -f "$dst" ] && return 0
    if [ -f "$src" ]; then
        \cp -f "$src" "$dst"
    else
        warn "数据包缺少 $(basename "$dst")"
    fi
}

# 部署引擎、规则、配置、拦截页、依赖库到运行时目录
deploy_files(){
    step "4/8 部署文件"
    mkdir -p "$waf_path" "$waf_log"
    if [ -z "$VHOST_DIR" ]; then
        resolve_vhost_dir
    fi

    # 6.1 lua 引擎（代码，每次安装都覆盖；数据源就是当前目录时跳过避免自拷贝）
    if [ "$DATA_SRC" = "$waf_path" ]; then
        info "引擎已在 ${waf_path}，跳过自拷贝"
    else
        for f in init.lua init_worker.lua waf.lua limit.lua zhi.lua dns.lua multipart.lua; do
            if [ -f "${DATA_SRC}/${f}" ]; then
                \cp -f "${DATA_SRC}/${f}" "${waf_path}/${f}" && info "已部署 ${f}"
            fi
        done
        # 源目录里其它 lua 文件一并带过来（不同版本引擎文件名不完全一致）
        for f in "${DATA_SRC}"/*.lua; do
            [ -f "$f" ] || continue
            local bn
            bn=$(basename "$f")
            [ -f "${waf_path}/${bn}" ] || \cp -f "$f" "${waf_path}/${bn}"
        done
    fi
    # 原包把 init 引擎命名为 4.7.lua
    if [ ! -f "${waf_path}/init.lua" ] && [ -f "${DATA_SRC}/4.7.lua" ]; then
        \cp -f "${DATA_SRC}/4.7.lua" "${waf_path}/init.lua"
        info "已部署 4.7.lua -> init.lua"
    fi
    [ -f "${waf_path}/waf.lua" ] || die "部署失败：${waf_path}/waf.lua 不存在（lua 引擎数据不完整）"
    info "引擎已就位：$(ls "${waf_path}"/*.lua 2>/dev/null | xargs -n1 basename 2>/dev/null | tr '\n' ' ')"

    # 6.2 内置规则库：逐文件补齐
    #     原版只在"整个 rule 目录不存在"时才拷，导致目录在、文件空的情况下规则永远补不上
    #     规则来源优先级：data 包里的 rule/ > 插件自带 defaults/rule/
    mkdir -p "${waf_path}/rule"
    for f in url.json args.json post.json cookie.json user_agent.json scan_black.json \
             ip_white.json ip_black.json url_white.json url_black.json head_white.json cn.json; do
        dst="${waf_path}/rule/${f}"
        if [ -f "$dst" ]; then
            body=$(tr -d ' \t\r\n' < "$dst" 2>/dev/null)
            if [ -n "$body" ] && [ "$body" != "[]" ] && [ "$body" != "{}" ] && [ "$body" != "null" ]; then
                continue      # 已有内容，保持用户自己调过的规则
            fi
        fi
        if [ -f "${DATA_SRC}/rule/${f}" ] && [ -s "${DATA_SRC}/rule/${f}" ]; then
            \cp -f "${DATA_SRC}/rule/${f}" "$dst"
        elif [ -f "${pluginPath}/defaults/rule/${f}" ]; then
            \cp -f "${pluginPath}/defaults/rule/${f}" "$dst"
            info "已补入内置默认规则：${f}"
        fi
    done

    # 6.3 运行数据（缺失才补）。config/site 缺失要明确提示，其余为可选文件，缺了会自行生成
    for f in config.json site.json; do
        if [ -f "${waf_path}/${f}" ] && [ -s "${waf_path}/${f}" ]; then
            continue
        fi
        if [ -f "${DATA_SRC}/${f}" ]; then
            \cp -f "${DATA_SRC}/${f}" "${waf_path}/${f}"
        elif [ -f "${pluginPath}/defaults/${f}" ]; then
            \cp -f "${pluginPath}/defaults/${f}" "${waf_path}/${f}"
            info "已补入默认配置：${f}"
        fi
    done
    for f in 1.json 2.json 3.json 4.json 5.json 6.json 7.json total.json domains.json limit.json drop_ip.log; do
        [ -f "${waf_path}/${f}" ] && continue
        if [ -f "${DATA_SRC}/${f}" ]; then
            \cp -f "${DATA_SRC}/${f}" "${waf_path}/${f}"
        elif [ -f "${pluginPath}/defaults/${f}" ]; then
            \cp -f "${pluginPath}/defaults/${f}" "${waf_path}/${f}"
        fi
    done
    for f in zhizhu1.json zhizhu2.json zhizhu4.json zhizhu5.json zhizhu6.json; do
        if [ ! -f "${waf_path}/${f}" ]; then
            if [ -f "${DATA_SRC}/${f}" ]; then
                \cp -f "${DATA_SRC}/${f}" "${waf_path}/${f}"
            else
                echo '[]' > "${waf_path}/${f}"
            fi
        fi
    done
    [ -f "${waf_path}/drop_ip.log" ] || : > "${waf_path}/drop_ip.log"
    [ -f "${waf_path}/total.json" ] || echo '{"sites":{}}' > "${waf_path}/total.json"

    # 6.4 拦截页模板（面板「全局配置 → 操作 → 响应内容」直接编辑这几个文件，
    #     文件不存在时面板会提示"文件不存在"，所以必须保证 5 个文件都在）
    mkdir -p "${waf_path}/html"
    for f in get.html post.html cookie.html user_agent.html other.html; do
        dst="${waf_path}/html/${f}"
        [ -s "$dst" ] && continue
        if [ -s "${DATA_SRC}/html/${f}" ]; then
            \cp -f "${DATA_SRC}/html/${f}" "$dst"
        elif [ -s "${DATA_SRC}/html/get.html" ] && [ "$f" != "get.html" ]; then
            \cp -f "${DATA_SRC}/html/get.html" "$dst"
        elif [ -s "${pluginPath}/defaults/html/${f}" ]; then
            \cp -f "${pluginPath}/defaults/html/${f}" "$dst"
            info "已补入默认拦截页：html/${f}"
        else
            warn "缺少拦截页模板 html/${f}"
        fi
    done

    # 6.5 插件图标（nginx 包含文件在 install_conf 里写，需要逐个目录验证）
    [ -f "${pluginPath}/${conf_name}" ] || die "插件目录里缺少 ${conf_name}，插件包不完整"
    if [ -f "${pluginPath}/icon.png" ]; then
        mkdir -p "$icon_dir"
        \cp -f "${pluginPath}/icon.png" "${icon_dir}/${icon_name}"
    fi
    rm -f "${icon_dir}/ico-free_waf.png" 2>/dev/null
    return 0
}

# 数据包若写死了旧目录，安装时就地对齐（lua 引擎不在本仓库，只能这样处理）
patch_paths(){
    local f
    for f in "${waf_path}"/*.lua "${waf_path}"/*.json "${waf_path}"/html/*.html; do
        [ -f "$f" ] || continue
        sed -i "s#${legacy_waf_path}#${waf_path}#g; s#${legacy_waf_log}#${waf_log}#g" "$f" 2>/dev/null
    done
    info "已把数据包内的旧路径对齐为 ${waf_path}"
}

# 统一权限：目录 755、文件 644、运行期可写文件 666；SELinux 时打 httpd 上下文
fix_perms(){
    mkdir -p "$waf_log"
    chown -R root:root "$waf_path" 2>/dev/null
    chmod 755 "$waf_path"

    # 关键：cp 出来的文件可能带着 umask 077 变成 600，nginx 的 worker 用户(www)
    # 在请求阶段执行 access_by_lua_file 时读不到 → 报
    # "failed to load external Lua file ... Permission denied"，站点全部 500。
    # 这里把所有目录统一 755、所有代码/配置文件统一 644。
    find "$waf_path" -type d -exec chmod 755 {} + 2>/dev/null
    find "$waf_path" -type f \( -name '*.lua' -o -name '*.json' -o -name '*.so' -o -name '*.html' -o -name '*.log' \) \
        -exec chmod 644 {} + 2>/dev/null
    chmod -R 755 "${waf_path}/lua515" 2>/dev/null

    # SELinux 处于 Enforcing 时，非标准路径的文件需要 httpd 可读上下文
    if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce 2>/dev/null)" = "Enforcing" ]; then
        if command -v chcon >/dev/null 2>&1; then
            chcon -R -t httpd_sys_content_t "$waf_path" 2>/dev/null && info "SELinux：已为 $waf_path 设置 httpd_sys_content_t"
        fi
    fi

    # 规则目录：nginx(www) 需要读写
    if [ -d "${waf_path}/rule" ]; then
        chown -R www:www "${waf_path}/rule"
        find "${waf_path}/rule" -type d -exec chmod 755 {} + 2>/dev/null
        find "${waf_path}/rule" -type f -exec chmod 644 {} + 2>/dev/null
    fi
    # 运行期由 nginx(www) 写入的文件
    for f in "${waf_path}/drop_ip.log" "${waf_path}/total.json" "${waf_path}"/zhizhu*.json; do
        [ -f "$f" ] || continue
        chown www:www "$f"
        chmod 666 "$f"
    done
    chown www:www "$waf_log"
    chmod 755 "$waf_log"
}

# www(nginx worker) 是否读得到某个文件；读不到说明权限/上下文有问题
www_can_read(){
    local f="$1"
    id www >/dev/null 2>&1 || return 0        # 没有 www 用户就没法测，直接放过
    su -s /bin/sh www -c "head -c 1 '$f' >/dev/null 2>&1"
}

# 逐个检查引擎文件，读不到就先尝试修复，再不行返回失败
ensure_www_readable(){
    local bad=0 f
    for f in "${waf_path}/init.lua" "${waf_path}/init_worker.lua" "${waf_path}/waf.lua" "${waf_path}/limit.lua"; do
        [ -f "$f" ] || continue
        if www_can_read "$f"; then
            continue
        fi
        warn "www 用户读不到 $f，尝试修复权限"
        chmod 644 "$f" 2>/dev/null
        chown root:root "$f" 2>/dev/null
        chmod 755 "$(dirname "$f")" 2>/dev/null
        if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce 2>/dev/null)" = "Enforcing" ] \
           && command -v chcon >/dev/null 2>&1; then
            chcon -t httpd_sys_content_t "$f" 2>/dev/null
        fi
        if www_can_read "$f"; then
            info "已修复：$f"
        else
            bad=$((bad+1))
            warn "仍然读不到：$f"
        fi
    done
    [ "$bad" -eq 0 ]
}

# www(nginx worker) 是否写得了某个文件（真正写一下：追加 0 字节）
www_can_write(){
    local f="$1"
    id www >/dev/null 2>&1 || return 0
    su -s /bin/sh www -c ": >> '$f'" 2>/dev/null
}

# nginx 错误日志里有没有 lua 文件加载失败（只看本次重启之后新增的行）
ERR_SKIP=0
# 检查本次重启之后 error.log 有没有 lua 加载失败
lua_load_error(){
    local log="${nginx_dir}/logs/error.log"
    [ -f "$log" ] || return 1
    local start=$(( ${ERR_SKIP:-0} + 1 ))
    tail -n "+${start}" "$log" 2>/dev/null | grep -q 'failed to load external Lua file'
}

# ---------------------------------------------------------------------------
# 7. 安装 / 卸载主流程
# ---------------------------------------------------------------------------
Install_btwaf(){
    info "===== x_waf 安装开始：$(date '+%Y-%m-%d %H:%M:%S') ====="
    info "日志文件：$LOG_FILE"
    check_env
    prepare_data
    resolve_vhost_dir

    step "3/8 依赖组件"
    mkdir -p "$pluginPath" "$waf_path" "$waf_log"
    Install_lua515
    Install_cjson

    deploy_files
    step "5/8 路径对齐 / lua 依赖库"
    patch_paths
    sync_lualib

    step "6/8 nginx 配置"
    # 老版本安装会注释掉 nginx.conf 里的 lua_package_path（那会导致 resty.core 找不到），这里还原
    restore_nginx_lua_path
    fix_perms
    ensure_www_readable || die "nginx 的 www 用户读不到 ${waf_path} 下的 lua 文件（权限或 SELinux 上下文问题），为免站点 500 已中止。可手动执行：chmod -R a+r ${waf_path}; chmod 755 ${waf_path}"
    install_conf || die "写入 x_waf.conf 后 nginx -t 始终不通过（已清理，站点未受影响）。可能原因：Nginx 未编译 lua 模块 / 与网站加速等插件冲突。完整日志：$LOG_FILE"

    step "7/8 重启 nginx"
    # 记录错误日志当前行数，后面只检查本次新增的部分
    if [ -f "${nginx_dir}/logs/error.log" ]; then
        ERR_SKIP=$(wc -l < "${nginx_dir}/logs/error.log" 2>/dev/null || echo 0)
    fi
    restart_nginx
    info "重启命令退出码：${NGINX_RESTART_RC}"
    if [ "${NGINX_RESTART_RC}" != "0" ] && [ -s /tmp/x_waf_restart.log ]; then
        info "----- 重启输出 -----"; cat /tmp/x_waf_restart.log; info "-------------------"
    fi

    step "8/8 校验"
    local vok=1
    [ "${NGINX_RESTART_RC}" = "0" ] || vok=0
    nginx_t_check || vok=0
    info "校验结果：重启退出码=${NGINX_RESTART_RC}，nginx -t=$([ "$vok" = "1" ] && echo 通过 || echo 未通过)"

    # 主动打一个请求，触发 worker 加载 access_by_lua_file，再看错误日志
    if command -v curl >/dev/null 2>&1; then
        curl -s -o /dev/null -m 3 "http://127.0.0.1/" >/dev/null 2>&1 || true
    fi
    if [ "$vok" = "1" ] && lua_load_error; then
        warn "nginx 错误日志出现 'failed to load external Lua file'（www 用户读不到 lua 文件）"
        vok=0
    fi
    info "权限自检：读=$(www_can_read "${waf_path}/waf.lua" && echo '✓' || echo '✗') 写=$(www_can_write "${waf_path}/total.json" && echo '✓' || echo '✗')（写失败会导致站点统计一直是 0）"

    if [ "$vok" = "1" ]; then
        if nginx_running; then
            info "nginx 运行状态：运行中 ✓"
        else
            warn "没探测到 nginx 进程，请手动确认：ps -ef | grep nginx"
        fi
        info "安装完成"
        info "  包含文件：${VHOST_DIR}/${conf_name}$([ -f "${VHOST_DIR}/${conf_name}" ] && echo ' ✓' || echo ' ✗ 缺失!')"
        info "  运行时目录：${waf_path}（lua：$(ls "${waf_path}"/*.lua 2>/dev/null | wc -l) 个）"
        info "  规则库  ：$(ls "${waf_path}"/rule/*.json 2>/dev/null | wc -l) 个文件"
        info "  拦截日志：${waf_log}"
        info "  安装日志：${LOG_FILE}"
        echo '安装完成' > "$install_tmp"
        rm -rf "$tmp_data"
        return 0
    fi

    # 回滚：撤掉包含文件，还原 nginx.conf，再重启
    warn "安装校验未通过，开始回滚（站点配置会恢复原状）"
    for f in /tmp/x_waf_nginx_test.log /tmp/x_waf_restart.log; do
        if [ -s "$f" ]; then
            info "----- $f -----"; cat "$f"; info "-------------------"
        fi
    done
    ps -ef 2>/dev/null | grep '[n]ginx' | head -5
    rm -f "${VHOST_DIR}/${conf_name}"
    restore_nginx_lua_path
    remove_added_include
    restart_nginx
    info "回滚后重启退出码：${NGINX_RESTART_RC}"
    rm -rf "$tmp_data"
    if nginx_t_check && nginx_running; then
        die "安装失败：已回滚，站点配置已还原。失败原因见上面 nginx -t / 重启输出。完整日志：$LOG_FILE"
    fi
    die "安装失败，且回滚后 nginx -t 仍不通过。注意：这通常说明该环境在安装前 nginx 配置本身就有问题（与插件无关），请按上面的 nginx -t 输出逐条修正。备份：${nginx_conf}.x_waf.bak。完整日志：$LOG_FILE"
}

# 卸载：移除 include 与配置文件，purge 时连运行时目录一起删
Uninstall_btwaf(){
    if [ -z "$VHOST_DIR" ]; then
        resolve_vhost_dir >/dev/null 2>&1
    fi
    [ -n "$VHOST_DIR" ] || VHOST_DIR="$vhost_dir"
    rm -f "${VHOST_DIR}/${conf_name}"
    remove_added_include
    rm -f "${icon_dir}/${icon_name}"
    restore_nginx_lua_path
    rm -rf "$waf_path"
    rm -rf "$pluginPath"
    reload_nginx
    info "已卸载 x_waf（拦截日志保留在 ${waf_log}，可手动删除）"
    if [ "$2" == 'purge' ]; then
        rm -rf "$waf_log"
        info "已清理日志目录 ${waf_log}"
    fi
}

# 诊断：只打印探测结果，不做任何修改
Show_env(){
    info "nginx        : $nginx_bin"
    [ -x "$nginx_bin" ] && info "nginx 版本   : $("$nginx_bin" -v 2>&1)"
    info "nginx.conf   : $nginx_conf $([ -f "$nginx_conf" ] && echo '(存在)' || echo '(不存在)')"
    info "插件目录     : $pluginPath $([ -d "$pluginPath" ] && echo '(存在)' || echo '(不存在)')"
    info "运行时目录   : $waf_path $([ -d "$waf_path" ] && echo '(存在)' || echo '(不存在)')"
    info "日志目录     : $waf_log $([ -d "$waf_log" ] && echo '(存在)' || echo '(不存在)')"
    info "默认vhost目录: $vhost_dir $([ -d "$vhost_dir" ] && echo '(存在)' || echo '(不存在)')"
    if [ -f "$nginx_conf" ]; then
        info "nginx.conf 中的 include："
        grep -nE '^[[:space:]]*include' "$nginx_conf" | sed 's/^/    /'
    fi
}

case "$1" in
    install|update)
        Install_btwaf
        ;;
    uninstall)
        Uninstall_btwaf "$@"
        ;;
    check|env)
        Show_env
        ;;
    *)
        echo "用法: install.sh install|update|uninstall [purge]|check"
        exit 1
        ;;
esac

exit 0
