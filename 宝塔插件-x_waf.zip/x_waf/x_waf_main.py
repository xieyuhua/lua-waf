# coding: utf-8
import sys, os

#if sys.version_info[0] == 2:
    #reload(sys)
    #sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel')
import json, time, public, string, re, hashlib

if __name__ != '__main__':
    from panelAuth import panelAuth


class x_waf_main:
    # ---- 路径常量：以后换目录只改这里 + install.sh 顶部变量 ----
    __path = '/www/server/x_waf/'                     # 运行时目录（lua 引擎 / 规则 / 配置）
    __logs = '/www/wwwlogs/x_waf_log/'                 # 拦截日志目录
    __PATH = '/www/server/panel/plugin/x_waf/'         # 插件目录
    __nginx_conf = '/www/server/nginx/conf/nginx.conf'
    __log_type = 'x_waf防火墙'                          # 写面板操作日志用的分类名
    # 是否允许把站点文件内容 / 蜘蛛IP 提交到第三方（bt.cn 云查杀、百度杀毒）——分支默认关闭
    __cloud = False
    __state = {True: '开启', False: '关闭', 0: '停用', 1: '启用'}
    __config = None

    # ---- 通用小工具 ----
    def __load_json(self, path, default=None):
        try:
            data = public.readFile(path)
            if not data or not str(data).strip():
                return default
            return json.loads(data)
        except Exception:
            return default

    __obj_default = {
        'open': True,
        'status': ''
    }

    # 全局默认配置（与 index.html 的 overall_show_config 一一对应，少一个前端就缺列）
    def __default_config(self):
        # 注意：这些 key 与 index.html 的 overall_show_config 一一对应，
        # 少一个前端"全局配置"表格就会缺列甚至渲染中断
        return {
            'open': True,
            'start_time': 0,
            'logs_path': self.__logs.rstrip('/'),
            'log_save': 15,
            'retry': 3,
            'retry_cycle': 60,
            'retry_time': 600,
            'from_data': True,
            'cc': {'open': False, 'cycle': 60, 'limit': 120, 'endtime': 600,
                   'status': '503', 'ps': '防御CC攻击'},
            'get': {'open': True, 'status': '403', 'ps': 'GET-URL/参数过滤'},
            'post': {'open': True, 'status': '403', 'ps': 'POST 过滤'},
            'cookie': {'open': True, 'status': '403', 'ps': 'Cookie 过滤'},
            'user-agent': {'open': True, 'status': '403', 'ps': 'User-Agent 过滤'},
            'scan': {'open': True, 'status': '403', 'ps': '常见扫描器'},
            'drop_abroad': {'open': False, 'status': '403', 'ps': '禁止海外访问'},
            'ip_white': {'open': True, 'status': '403', 'ps': '所有规则对IP白名单无效'},
            'ip_black': {'open': True, 'status': '403', 'ps': '禁止访问的IP'},
            'url_white': {'open': True, 'status': '403', 'ps': '大部分规则对URL白名单无效'}
        }

    # 把前端传来的下标收敛成合法整数，越界/非法返回 None（防止删错、改错）
    def __check_index(self, lst, index):
        # 前端传来的下标可能过期（规则被删过/列表为空），统一在这里收敛
        try:
            i = int(index)
        except (TypeError, ValueError):
            return None
        if not isinstance(lst, list) or i < 0 or i >= len(lst):
            return None
        return i

    # HTML/JS 转义；quote=False 时只转 & < >，用于解析面板日志（必须用 False，否则引号被转义 JSON 就坏了）
    def __escape(self, s, quote=True):
        # 兼容 py3.8+ 移除的 cgi.escape
        try:
            import html
            return html.escape(str(s), quote=quote)
        except Exception:
            import cgi
            return cgi.escape(str(s), quote=quote)

    # 返回面板里所有站点名列表
    def return_site(self, get):
        data = public.M('sites').field('name,path').select()
        ret = {}
        for i in data:
            ret[i['name']] = i['path']
        return public.returnMsg(True, ret)

    # 把 IP / CIDR / 起止 IP 统一解析成 [起始, 结束] 两元素列表，供 lua 二分匹配
    def is_ip_zhuanhuang(self,ip,ip2=False,ip_duan=False):
        try:
            ret = []
            if ip_duan:
                ip_ddd=int(ip.split('/')[1])
                ip = ip.split('/')[0].split('.')
                if ip_ddd>=32:return False
                if ip_ddd>=24:ip[-1]="0"
                if ip_ddd>=16 and ip_ddd<24:
                    ip[-1]="0"
                    ip[-2]="0"
                if ip_ddd>=8 and ip_ddd<16:
                    ip[-1]="0"
                    ip[-2]="0"
                    ip[-3]="0"
                from IPy import IP
                ip2 = IP("{}/{}".format('.'.join(ip),ip_ddd))
                return self.is_ip_zhuanhuang(str(ip2[0]),str(ip2[-1]))
            else:
                if not ip2:
                    ip=ip.split('.')
                    ret2=[]
                    for i in ip:
                        ret2.append(int(i))
                    ret.append(ret2)
                    ret.append(ret2)
                    return ret
                if ip2:
                    ip = ip.split('.')
                    ret2 = []
                    for i in ip:
                        ret2.append(int(i))
                    ret.append(ret2)
                    ip2 = ip2.split('.')
                    ret2 = []
                    for i in ip2:
                        ret2.append(int(i))
                    ret.append(ret2)
                    return ret
        except:return False


    # 严格的 IP 校验（原版正则没转义点号，"1a2b3c4d" 这种脏数据也会被吃进去）
    def __valid_ip(self, ip):
        tmp = str(ip).strip().split('.')
        if len(tmp) != 4: return False
        for i in tmp:
            if not i.isdigit() or not 0 <= int(i) <= 255: return False
        return True

    # 校验是不是合法 CIDR（如 1.2.3.0/24）
    def __valid_cidr(self, s):
        if '/' not in s: return False
        ip, mask = s.split('/', 1)
        return mask.isdigit() and 0 <= int(mask) <= 32 and self.__valid_ip(ip)

    # 校验是不是合法 IP 段（如 1.2.3.4-1.2.3.99）
    def __valid_range(self, s):
        if '-' not in s: return False
        a, b = s.split('-', 1)
        return self.__valid_ip(a) and self.__valid_ip(b)

    # 导入外部规则/黑名单数据（严格校验 IP，非法行整批拒绝）
    def import_data(self, get):
        name = get.s_Name;
        if name=='ip_white' or name=='ip_black':
            padata = get.pdata.strip().split()
            if not padata: return public.returnMsg(False, '数据格式不正确')
            iplist = self.__get_rule(name) or []
            ok = 0
            bad = 0
            for i in padata:
                if self.__valid_range(i):
                    ip = i.split('-')
                    ips = self.is_ip_zhuanhuang(ip[0], ip[1])
                elif self.__valid_cidr(i):
                    ips = self.is_ip_zhuanhuang(i, ip_duan=True)
                elif self.__valid_ip(i):
                    ips = self.is_ip_zhuanhuang(i)
                else:
                    bad += 1
                    continue
                if not ips or ips in iplist:
                    bad += 1
                    continue
                iplist.insert(0, ips)
                ok += 1
            self.__write_rule(name, iplist)
            return public.returnMsg(True, '导入成功! 新增 %d 条，忽略无效/重复 %d 条' % (ok, bad))
        else:
            try:
                pdata = json.loads(get.pdata)
            except:
                return public.returnMsg(False, '数据格式不正确');
            if not pdata: return public.returnMsg(False, '数据格式不正确');
            iplist = self.__get_rule(name) or [];
            for ips in pdata:
                if ips in iplist: continue;
                iplist.insert(0, ips)
            self.__write_rule(name, iplist)
            return public.returnMsg(True, '导入成功!')

    # 获取规则
    def shell_get_rule(self, get):
        ret = []
        if os.path.exists(self.__PATH + 'rule.json'):
            try:
                data = json.loads(public.ReadFile(self.__PATH + 'rule.json'))
                return data
            except:
                return False
        else:
            return False

    # 查询站点跟目录
    def getdir(self, dir, pc='', lis=None):
        # 修正：原版默认参数是可变的 []，同进程内多次调用会累积上一次的结果
        if lis is None:
            lis = []
        try:
            names = os.listdir(dir)
        except OSError:
            return lis
        for l in names:
            try:
                if os.path.isdir(dir + '/' + l):
                    lis = self.getdir(dir + '/' + l, pc, lis)
                elif str(l.lower())[-4:] == '.php' and str(dir + '/' + l).find(pc) == -1:
                    lis.append(dir + '/' + l)
            except Exception:
                continue
        return lis

    # 目录
    def getdir_list(self, get):
        path = get.path
        if os.path.exists(path):
            pc = 'hackcnm'
            rs = self.getdir(path, pc)
            return rs
        else:
            return False

    # 扫描指定目录找可疑文件（webshell 查杀入口）
    def scan(self, filelist, rule):
        self.__webshell_data = []
        import time
        time_data = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        ret = []
        for file in filelist:
            try:
                data = open(file).read()
            except:
                pass
            for r in rule:
                if re.compile(r).findall(data):
                    result = {}
                    result[file] = r
                    self.__webshell_data.append(result)
                    self.send_baota2(file)
                    data = ("%s [!] %s %s  \n" % (time_data, file, r))
                    self.insert_log(data)
        return self.__webshell_data

    # 往查杀日志里追加一条记录
    def insert_log(self, data):
        public.writeFile(self.__PATH + 'webshell.log', data, 'a+')

    # 读取查杀日志
    def get_log(self, get):
        path = self.__PATH + 'webshell.log'
        if not os.path.exists(path): return False
        return public.GetNumLines(path, 3000)

    # 把路径信息序列化成 JSON（查杀结果落盘用）
    def path_json(self, path, data):
        path_file = str(path).replace('/', '')
        if os.path.exists(path):
            if os.path.exists(self.__PATH + path_file + '.json'):
                try:
                    path_data = json.loads(public.ReadFile(self.__PATH + path_file + '.json'))
                except:
                    ret = []
                    public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
                    path_data = []
                if not path_data: return self.__webshell_data
                for i in self.__webshell_data:
                    for i2 in path_data:
                        if i2 in i:
                            self.__webshell_data.remove(i)
                return self.__webshell_data
            else:
                ret = []
                public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
                path_data = []
                return self.__webshell_data

    # 对目录名做基础安全检查，屏蔽系统关键目录
    def san_dir(self, get):
        file = self.getdir_list(get)
        if not file: return public.returnMsg(False, "目录不存在")
        rule = self.shell_get_rule(get)
        if not rule: return public.returnMsg(False, "规则为空或者规则文件错误")
        self.__webshell_data = []
        result = self.scan(file, rule)
        result = self.path_json(get.path, result)
        return self.__webshell_data

    # 对输出做 XSS 转义
    def xssencode(self, text):
        esc = self.__escape
        list = ['`', '~', '&', '<', '>']
        ret = []
        for i in text:
            if i in list:
                i = ''
            ret.append(i)
        str_convert = ''.join(ret)
        return esc(str_convert, quote=True)

    # 新增一条 webshell 查杀特征
    def shell_add_rule(self, get):
        rule = self.xssencode(get.rule)
        ret = []
        if os.path.exists(self.__PATH + 'rule.json'):
            try:
                data = json.loads(public.ReadFile(self.__PATH + 'rule.json'))
                if rule in data:
                    return public.returnMsg(False, '已经存在此规则')
                else:
                    data.append(rule)
                    public.WriteFile(self.__PATH + 'rule.json', json.dumps(data))
                    return public.returnMsg(True, '添加成功')
            except:
                return public.returnMsg(False, '规则库解析错误')
        else:
            return public.returnMsg(False, '规则库文件不存在')

    # 删除一条 webshell 查杀特征
    def shell_del_rule(self, get):
        rule = get.rule
        if os.path.exists(self.__PATH + 'rule.json'):
            try:
                data = json.loads(public.ReadFile(self.__PATH + 'rule.json'))
                if rule in data:
                    data.remove(rule)
                    public.WriteFile(self.__PATH + 'rule.json', json.dumps(data))
                    return public.returnMsg(True, '删除成功')
                else:
                    return public.returnMsg(False, '规则库不存在此规则')
            except:
                return public.returnMsg(False, '规则库解析错误')
        else:
            return public.returnMsg(False, '规则库文件不存在')

    # 把文件加入「不是木马」的白名单，避免重复误报
    def lock_not_webshell(self, get):
        path = get.path
        not_path = get.not_path
        if not os.path.exists(not_path): return public.returnMsg(False, '文件不存在')
        path_file = str(path).replace('/', '')
        if not os.path.exists(self.__PATH + path_file + '.json'):
            ret = []
            ret.append(not_path)
            public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
        else:
            try:
                path_data = json.loads(public.ReadFile(self.__PATH + path_file + '.json'))
                if not not_path in path_data:
                    path_data.append(not_path)
                    public.WriteFile(self.__PATH + path_file + '.json', json.dumps(path_data))
                    return public.returnMsg(True, '添加成功')
                else:
                    return public.returnMsg(False, '已经存在')
            except:
                ret = []
                ret.append(not_path)
                public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
                return public.returnMsg(True, '11111111')

    # 把可疑文件上传到面板云端分析（__cloud=False 时直接跳过）
    def upload_file_url(self, get):
        if not self.__cloud:
            return public.returnMsg(False, '云端查杀已关闭（x_waf 分支默认不把文件上传第三方）')
        try:
            if os.path.exists(get.filename):
                data = public.ExecShell(
                    '/usr/local/curl/bin/curl https://scanner.baidu.com/enqueue -F archive=@%s' % get.filename)
                data = json.loads(data[0])
                time.sleep(3)
                import requests
                default_headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
                }
                data_list = requests.get(url=data['url'], headers=default_headers, verify=False)
                data2 = data_list.json()
                if 'data' in data2[0]:
                    if len(data2[0]['data']) >= 1:
                        if 'descr' in data2[0]['data'][0]:
                            if 'WebShell' in data2[0]['data'][0]['descr']:
                                return public.returnMsg(True, '此文件为webshell')
                return public.returnMsg(True, '未查出风险,需等待一段时间后查询')
            else:
                return public.returnMsg(False, '文件不存在')
        except:
            return public.returnMsg(True, '未查出风险,需等待一段时间后查询')

    # 计算文件 MD5（判断文件是否变化）
    def read_file_md5(self, filename):
        if os.path.exists(filename):
            with open(filename, 'rb') as fp:
                data = fp.read()
            file_md5 = hashlib.md5(data).hexdigest()
            return file_md5
        else:
            return False

    # 提交数据到宝塔云端（默认关闭，不联网）
    def send_baota2(self, filename):
        if not self.__cloud:
            return False
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_submit'
        pdata = {'codetxt': public.ReadFile(filename), 'md5': self.read_file_md5(filename), 'type': '0',
                 'host_ip': public.GetLocalIp(), 'size': os.path.getsize(filename)}
        ret = public.httpPost(cloudUrl, pdata)
        return True

    # 提交数据到宝塔云端（默认关闭，不联网）
    def send_baota(self, get):
        if not self.__cloud:
            return public.returnMsg(False, '云端查杀已关闭（x_waf 分支默认不把文件上传第三方）')
        if 'filename' not in get: return public.returnMsg(False, '请选择你需要上传的文件')
        if not os.path.exists(get.filename): return public.returnMsg(False, '文件不存在')
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_submit'
        pdata = {'codetxt': public.ReadFile(get.filename), 'md5': self.read_file_md5(get.filename), 'type': '0',
                 'host_ip': public.GetLocalIp(), 'size': os.path.getsize(get.filename)}
        ret = public.httpPost(cloudUrl, pdata)
        if ret == '1':
            return self.check_webshell(get)
        elif ret == '-1':
            return self.check_webshell(get)
        else:
            return public.returnMsg(False, '系统错误')

    # 对单个文件执行 webshell 特征匹配
    def check_webshell(self, get):
        if 'filename' not in get: return public.returnMsg(False, '请选择你需要上传的文件')
        if not os.path.exists(get.filename): return public.returnMsg(False, '文件不存在')
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_check_file'
        pdata = {'md5': self.read_file_md5(get.filename), 'size': os.path.getsize(get.filename)}
        ret = public.httpPost(cloudUrl, pdata)
        if ret == '0':
            return public.returnMsg(True, '未查出风险,需等待一段时间后查询')
        elif ret == '1':
            return public.returnMsg(True, '该文件经过系统检测为webshell！！！！')
        elif ret == '-1':
            return public.returnMsg(True, '未查询到该文件,请上传检测')
        else:
            return public.returnMsg(False, '系统错误')

    # 计算字符串 MD5
    def __get_md5(self, s):
        m = hashlib.md5()
        m.update(s.encode('utf-8'))
        return m.hexdigest()

    # 读全局配置：缺字段自动补齐默认值并落盘自愈（status 为空会补成 403/503）
    def get_config(self, get):
        raw = self.__load_json(self.__path + 'config.json', None)
        defaults = self.__default_config()
        if not isinstance(raw, dict):
            # 安装不完整 / 文件损坏：自动写一份默认配置，保证"默认就有配置"且不会 500
            dflt = self.__load_json(self.__PATH + 'defaults/config.json', None)
            if not isinstance(dflt, dict):
                dflt = defaults
            try:
                public.writeFile(self.__path + 'config.json', json.dumps(dflt))
                public.serviceReload()
            except Exception:
                pass
            return dflt

        changed = False
        if 'from_data' not in raw:
            raw['from_data'] = True
            changed = True
        if 'retry_cycle' not in raw:
            raw['retry_cycle'] = 60
            changed = True
        try:
            start = int(float(raw.get('start_time') or 0))
        except (TypeError, ValueError):
            start = 0
        if start == 0:
            raw['start_time'] = int(time.time())
            changed = True
        if changed:
            self.__write_config(raw)

        # 返回给前端的结构做一次深度补齐，缺 key 时不再让 /plugin?action=a 直接失败，
        # 也不会让 index.html 里 _this.overall_config.cc.status 抛异常导致整页空白
        config = self.__default_config()
        config.update(raw)
        healed = False
        for k, dv in defaults.items():
            if isinstance(dv, dict):
                if not isinstance(config.get(k), dict):
                    config[k] = dict(dv)
                else:
                    for kk, vv in dv.items():
                        config[k].setdefault(kk, vv)
                    # status 为空会让前端「响应」列整格消失（点不到响应代码设置），补成默认值
                    if str(config[k].get('status', '')).strip() == '':
                        config[k]['status'] = dv.get('status', '403')
                        raw.setdefault(k, {})['status'] = config[k]['status']
                        healed = True
        if healed:
            try:
                self.__write_config(raw)
            except Exception:
                pass
        return config

    # 读站点配置；带参数时返回排序后的列表，并聚合每个站点的命中统计
    def get_site_config(self, get):
        if not os.path.exists(self.__logs):
            try:
                os.makedirs(self.__logs)
            except OSError:
                pass
        data = self.__check_site(self.__load_json(self.__path + 'site.json', {}))
        if get:
            total_all = self.get_total(None)['sites']
            mday = time.strftime('%Y-%m-%d', time.localtime())
            site_list = []
            for k in data.keys():
                agg = self.__collect_site_total(k, data[k], total_all)
                if not any(v for v in agg.values()):
                    # 引擎计数器还没落盘 / 站点名和 Host 对不上时，用当天日志兜底
                    agg = self.__count_today_log(k, mday)
                data[k]['total'] = self.__format_total(agg)
                siteInfo = data[k]
                siteInfo['siteName'] = k
                site_list.append(siteInfo)
            data = sorted(site_list, key=lambda x: x['log_size'], reverse=True)
        return data

    # 把 total.json 里「站点名 + 该站点所有域名」的计数合并（Host 与站点名不一致时也能统计到）
    def __collect_site_total(self, site_name, site_conf, total_all):
        """把 total.json 里 "站点名 / 该站点的各个域名" 的计数合并起来。
        引擎是按请求 Host 记录计数的，Host 可能是 www.a.com 而站点名是 a.com，
        不合并的话站点配置里就会一直是 0。"""
        names = [site_name]
        if isinstance(site_conf, dict):
            for d in (site_conf.get('domains') or []):
                if isinstance(d, str) and d.strip():
                    names.append(d.strip().lower())
        keys = ('args', 'url', 'post', 'cc', 'user_agent', 'cookie', 'scan', 'head')
        agg = {k: 0 for k in keys}
        for nm in names:
            item = total_all.get(nm)
            if not isinstance(item, dict):
                continue
            for k in keys:
                try:
                    agg[k] += int(item.get(k) or 0)
                except (TypeError, ValueError):
                    pass
        return agg

    # 兜底统计：直接解析当天日志文件，按过滤器字段归类计数
    def __count_today_log(self, site_name, mday):
        """按当天日志文件统计各类型命中数（兜底用，口径与「日志」页一致）"""
        agg = {'args': 0, 'url': 0, 'post': 0, 'cc': 0,
               'user_agent': 0, 'cookie': 0, 'scan': 0, 'head': 0}
        path = self.__logs + site_name + '_' + mday + '.log'
        if not os.path.exists(path):
            return agg
        filter_map = {
            'args': 'args', 'url': 'url', 'url_black': 'url',
            'post': 'post',
            'cc': 'cc', 'limit_ip': 'cc', 'limit_key': 'cc', 'drop_abroad': 'cc',
            'user_agent': 'user_agent', 'cookie': 'cookie',
            'scan': 'scan', 'head': 'head', 'ip_black': 'head', 'url_rule': 'head',
            'url_white': 'head', 'ip_white': 'head'
        }
        try:
            size = os.path.getsize(path)
            with open(path, 'rb') as fp:
                if size > 8 * 1024 * 1024:      # 超大文件只看最后 8MB，避免页面卡住
                    fp.seek(size - 8 * 1024 * 1024)
                    fp.readline()
                for line in fp:
                    try:
                        row = json.loads(line.decode('utf-8', 'ignore').strip())
                    except Exception:
                        continue
                    f = row[5] if len(row) > 5 else ''
                    key = filter_map.get(f)
                    if key:
                        agg[key] += 1
        except Exception:
            pass
        return agg

    # 按站点名取单个站点配置（站点设置弹窗用）
    def get_site_config_byname(self, get):
        site_config = self.get_site_config(None);
        config = site_config[get.siteName]
        config['top'] = self.get_config(None)
        return config

    # 开关防火墙总开关
    def set_open(self, get):
        config = self.get_config(None)
        if config['open']:
            config['open'] = False
            config['start_time'] = 0
        else:
            config['open'] = True
            config['start_time'] = int(time.time())
        self.__write_log(self.__state[config['open']] + '网站防火墙(WAF)');
        self.__write_config(config)
        return public.returnMsg(True, '设置成功!');

    # 开关全局某一项防护（GET/POST/CC/UA/扫描器…）
    def set_obj_open(self, get):
        config = self.get_config(None)
        if get.obj not in config:
            return public.returnMsg(False, '未知配置项：' + str(get.obj))
        if type(config[get.obj]) != bool:
            if config[get.obj]['open']:
                config[get.obj]['open'] = False
            else:
                config[get.obj]['open'] = True
            self.__write_log(self.__state[config[get.obj]['open']] + '【' + get.obj + '】功能');
        else:
            if config[get.obj]:
                config[get.obj] = False
            else:
                config[get.obj] = True
            self.__write_log(self.__state[config[get.obj]] + '【' + get.obj + '】功能');

        self.__write_config(config)
        return public.returnMsg(True, '设置成功!');

    # 开关某个站点的某一项防护（未单独设置过则继承全局）
    def set_site_obj_open(self, get):
        site_config = self.get_site_config(None)
        if get.siteName not in site_config:
            return public.returnMsg(False, '站点不存在：' + str(get.siteName))
        if get.obj not in site_config[get.siteName]:
            return public.returnMsg(False, '未知站点配置项：' + str(get.obj))
        if type(site_config[get.siteName][get.obj]) != bool:
            if site_config[get.siteName][get.obj]['open']:
                site_config[get.siteName][get.obj]['open'] = False
            else:
                site_config[get.siteName][get.obj]['open'] = True
            self.__write_log(self.__state[site_config[get.siteName][get.obj][
                'open']] + '网站【' + get.siteName + '】【' + get.obj + '】功能');
        else:
            if site_config[get.siteName][get.obj]:
                site_config[get.siteName][get.obj] = False
            else:
                site_config[get.siteName][get.obj] = True
            self.__write_log(
                self.__state[site_config[get.siteName][get.obj]] + '网站【' + get.siteName + '】【' + get.obj + '】功能');

        if get.obj == 'drop_abroad': self.__auto_sync_cnlist();
        self.__write_site_config(site_config)
        return public.returnMsg(True, '设置成功!');

    # 设置某一项防护命中后的响应码（200/403/404/444/503…）
    def set_obj_status(self, get):
        config = self.get_config(None)
        if not isinstance(config.get(get.obj), dict):
            return public.returnMsg(False, '该配置项不支持设置响应代码：' + str(get.obj))
        try:
            code = int(get.statusCode)
        except (TypeError, ValueError):
            return public.returnMsg(False, '响应代码不合法')
        config[get.obj]['status'] = code
        self.__write_config(config)
        return public.returnMsg(True, '设置成功!');

    # 保存全局 CC 防御参数（周期/次数/封禁时长）
    def set_cc_conf(self, get):
        config = self.get_config(None)
        config['cc']['cycle'] = int(get.cycle)
        config['cc']['limit'] = int(get.limit)
        config['cc']['endtime'] = int(get.endtime)
        config['cc']['increase'] = (get.increase == '1') | False
        self.__write_config(config)
        self.__write_log(
            '设置全局CC配置为：' + get.cycle + ' 秒内累计请求超过 ' + get.limit + ' 次后,封锁 ' + get.endtime + ' 秒' + ',增强:' + get.increase);
        return public.returnMsg(True, '设置成功!');

    # 保存单个站点的 CC 防御参数
    def set_site_cc_conf(self, get):
        site_config = self.get_site_config(None)
        site_config[get.siteName]['cc']['cycle'] = int(get.cycle)
        site_config[get.siteName]['cc']['limit'] = int(get.limit)
        site_config[get.siteName]['cc']['endtime'] = int(get.endtime)
        site_config[get.siteName]['cc']['increase'] = (get.increase == '1') | False
        self.__write_site_config(site_config)
        self.__write_log(
            '设置站点【' + get.siteName + '】CC配置为：' + get.cycle + ' 秒内累计请求超过 ' + get.limit + ' 次后,封锁 ' + get.endtime + ' 秒' + ',增强:' + get.increase);
        return public.returnMsg(True, '设置成功!');

    # 添加国内 IP 段（禁止海外访问用）
    def add_cnip(self, get):
        ipn = [self.__format_ip(get.start_ip), self.__format_ip(get.end_ip)]
        if not ipn[0] or not ipn[1]: return public.returnMsg(False, 'IP段格式不正确');
        if not self.__is_ipn(ipn): return public.returnMsg(False, '起始IP不能大于结束IP');
        iplist = self.__get_rule('cn')
        if ipn in iplist: return public.returnMsg(False, '指定IP段已存在!');
        iplist.insert(0, ipn)
        self.__write_rule('cn', iplist)
        self.__write_log('添加IP段[' + get.start_ip + '-' + get.end_ip + ']到国内IP库');
        return public.returnMsg(True, '添加成功!');

    # 删除国内 IP 段
    def remove_cnip(self, get):
        iplist = self.__get_rule('cn')
        index = self.__check_index(iplist, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        ipn = iplist[index]
        del (iplist[index])
        self.__write_rule('cn', iplist)
        self.__write_log('从国内IP库删除[' + '.'.join(map(str, ipn[0])) + '-' + '.'.join(map(str, ipn[1])) + ']');
        return public.returnMsg(True, '删除成功!');

    # 添加 IP 白名单（支持 IP/CIDR/段）
    def add_ip_white(self, get):
        ipn = [self.__format_ip(get.start_ip), self.__format_ip(get.end_ip)]
        if not ipn[0] or not ipn[1]: return public.returnMsg(False, 'IP段格式不正确');
        if not self.__is_ipn(ipn): return public.returnMsg(False, '起始IP不能大于结束IP');
        iplist = self.__get_rule('ip_white')
        if ipn in iplist: return public.returnMsg(False, '指定IP段已存在!');
        iplist.insert(0, ipn)
        self.__write_rule('ip_white', iplist)
        self.__write_log('添加IP段[' + get.start_ip + '-' + get.end_ip + ']到IP白名单');
        return public.returnMsg(True, '添加成功!');

    # 删除 IP 白名单
    def remove_ip_white(self, get):
        iplist = self.__get_rule('ip_white')
        index = self.__check_index(iplist, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        ipn = iplist[index]
        del (iplist[index])
        self.__write_rule('ip_white', iplist)
        self.__write_log('从IP白名单删除[' + '.'.join(map(str, ipn[0])) + '-' + '.'.join(map(str, ipn[1])) + ']');
        return public.returnMsg(True, '删除成功!');

    # 添加 IP 黑名单
    def add_ip_black(self, get):
        ipn = [self.__format_ip(get.start_ip), self.__format_ip(get.end_ip)]
        if not ipn[0] or not ipn[1]: return public.returnMsg(False, 'IP段格式不正确');
        if not self.__is_ipn(ipn): return public.returnMsg(False, '起始IP不能大于结束IP');
        iplist = self.__get_rule('ip_black')
        if ipn in iplist: return public.returnMsg(False, '指定IP段已存在!');
        iplist.insert(0, ipn)
        self.__write_rule('ip_black', iplist)
        self.__write_log('添加IP段[' + get.start_ip + '-' + get.end_ip + ']到IP黑名单');
        return public.returnMsg(True, '添加成功!');

    # 删除 IP 黑名单
    def remove_ip_black(self, get):
        iplist = self.__get_rule('ip_black')
        index = self.__check_index(iplist, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        ipn = iplist[index]
        del (iplist[index])
        self.__write_rule('ip_black', iplist)
        self.__write_log('从IP黑名单删除[' + '.'.join(map(str, ipn[0])) + '-' + '.'.join(map(str, ipn[1])) + ']');
        return public.returnMsg(True, '删除成功!');

    # 添加 URL 白名单（例外面）
    def add_url_white(self, get):
        url_white = self.__get_rule('url_white')
        url_rule = get.url_rule.strip()
        if get.url_rule in url_white: return public.returnMsg(False, '您添加的URL已存在')
        url_white.insert(0, url_rule)
        self.__write_rule('url_white', url_white)
        self.__write_log('添加url规则[' + url_rule + ']到URL白名单');
        return public.returnMsg(True, '添加成功!');

    # 删除 URL 白名单
    def remove_url_white(self, get):
        url_white = self.__get_rule('url_white')
        index = self.__check_index(url_white, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        url_rule = url_white[index]
        del (url_white[index])
        self.__write_rule('url_white', url_white)
        self.__write_log('从URL白名单删除URL规则[' + url_rule + ']');
        return public.returnMsg(True, '删除成功!');

    # 添加 URL 黑名单（直接拦截）
    def add_url_black(self, get):
        url_white = self.__get_rule('url_black')
        url_rule = get.url_rule.strip()
        if get.url_rule in url_white: return public.returnMsg(False, '您添加的URL已存在')
        url_white.insert(0, url_rule)
        self.__write_rule('url_black', url_white)
        self.__write_log('添加url规则[' + url_rule + ']到URL黑名单');
        return public.returnMsg(True, '添加成功!');

    # 删除 URL 黑名单
    def remove_url_black(self, get):
        url_white = self.__get_rule('url_black')
        index = self.__check_index(url_white, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        url_rule = url_white[index]
        del (url_white[index])
        self.__write_rule('url_black', url_white)
        self.__write_log('从URL黑名单删除URL规则[' + url_rule + ']');
        return public.returnMsg(True, '删除成功!');

    # 保存扫描器特征（scan_black：header/cookie/args 三段多行正则）
    def save_scan_rule(self, get):
        scan_rule = {'header': get.header, 'cookie': get.cookie, 'args': get.args}
        self.__write_rule('scan_black', scan_rule)
        self.__write_log('修改扫描器过滤规则');
        return public.returnMsg(True, '设置成功')

    # 设置全局容忍阈值（命中多少次后自动封 IP、封多久）
    def set_retry(self, get):
        config = self.get_config(None)
        config['retry'] = int(get.retry)
        config['retry_cycle'] = int(get.retry_cycle)
        config['retry_time'] = int(get.retry_time)
        self.__write_config(config)
        self.__write_log('设置非法请求容忍阈值: ' + get.retry_cycle + ' 秒内累计超过 ' + get.retry + ' 次, 封锁 ' + get.retry_time + ' 秒');
        return public.returnMsg(True, '设置成功!');

    # 设置单个站点的容忍阈值
    def set_site_retry(self, get):
        site_config = self.get_site_config(None)
        site_config[get.siteName]['retry'] = int(get.retry)
        site_config[get.siteName]['retry_cycle'] = int(get.retry_cycle)
        site_config[get.siteName]['retry_time'] = int(get.retry_time)
        self.__write_site_config(site_config)
        self.__write_log(
            '设置网站【' + get.siteName + '】非法请求容忍阈值: ' + get.retry_cycle + ' 秒内累计超过 ' + get.retry + ' 次, 封锁 ' + get.retry_time + ' 秒');
        return public.returnMsg(True, '设置成功!');

    # 设置站点是否在 CDN 后面（决定取真实 IP 的方式）
    def set_site_cdn_state(self, get):
        site_config = self.get_site_config(None)
        if site_config[get.siteName]['cdn']:
            site_config[get.siteName]['cdn'] = False
        else:
            site_config[get.siteName]['cdn'] = True
        self.__write_site_config(site_config)
        self.__write_log(self.__state[site_config[get.siteName]['cdn']] + '站点【' + get.siteName + '】CDN模式');
        return public.returnMsg(True, '设置成功!');

    # 读取站点的 CDN 真实 IP 头名（如 X-Forwarded-For）
    def get_site_cdn_header(self, get):
        site_config = self.get_site_config(None)
        return site_config[get.siteName]['cdn_header']

    # 为站点添加 CDN 真实 IP 头
    def add_site_cdn_header(self, get):
        site_config = self.get_site_config(None)
        get.cdn_header = get.cdn_header.strip().lower();
        if get.cdn_header in site_config[get.siteName]['cdn_header']: return public.returnMsg(False, '您添加的请求头已存在!');
        site_config[get.siteName]['cdn_header'].append(get.cdn_header)
        self.__write_site_config(site_config)
        self.__write_log('添加站点【' + get.siteName + '】CDN-Header【' + get.cdn_header + '】');
        return public.returnMsg(True, '添加成功!');

    # 移除站点的 CDN 真实 IP 头
    def remove_site_cdn_header(self, get):
        site_config = self.get_site_config(None)
        get.cdn_header = get.cdn_header.strip().lower();
        if not get.cdn_header in site_config[get.siteName]['cdn_header']: return public.returnMsg(False, '指定请求头不存在!');
        for i in range(len(site_config[get.siteName]['cdn_header'])):
            if get.cdn_header == site_config[get.siteName]['cdn_header'][i]:
                self.__write_log(
                    '删除站点【' + get.siteName + '】CDN-Header【' + site_config[get.siteName]['cdn_header'][i] + '】');
                del (site_config[get.siteName]['cdn_header'][i])
                break;
        self.__write_site_config(site_config)
        return public.returnMsg(True, '删除成功!');

    # 读取站点的自定义规则（URL 拦截/放行）
    def get_site_rule(self, get):
        site_config = self.get_site_config(None)
        return site_config[get.siteName][get.ruleName]

    # 给站点添加一条自定义规则
    def add_site_rule(self, get):
        site_config = self.get_site_config(None)
        if not get.ruleName in site_config[get.siteName]: return public.returnMsg(False, '指定规则不存在!');
        mt = type(site_config[get.siteName][get.ruleName])
        if mt == bool: return public.returnMsg(False, '指定规则不存在!');
        if mt == str: site_config[get.siteName][get.ruleName] = get.ruleValue
        if mt == list:
            if get.ruleName == 'url_rule' or get.ruleName == 'url_tell':
                for ruleInfo in site_config[get.siteName][get.ruleName]:
                    if ruleInfo[0] == get.ruleUri: return public.returnMsg(False, '指定URI已存在!');
                tmp = []
                tmp.append(get.ruleUri)
                tmp.append(get.ruleValue)
                if get.ruleName == 'url_tell':
                    self.__write_log(
                        '添加站点【' + get.siteName + '】URI【' + get.ruleUri + '】保护规则,参数【' + get.ruleValue + '】,参数值【' + get.rulePass + '】');
                    tmp.append(get.rulePass)
                else:
                    self.__write_log('添加站点【' + get.siteName + '】URI【' + get.ruleUri + '】过滤规则【' + get.ruleValue + '】');
                site_config[get.siteName][get.ruleName].insert(0, tmp)
            else:
                if get.ruleValue in site_config[get.siteName][get.ruleName]: return public.returnMsg(False, '指定规则已存在!');
                site_config[get.siteName][get.ruleName].insert(0, get.ruleValue)
                self.__write_log('添加站点【' + get.siteName + '】【' + get.ruleName + '】过滤规则【' + get.ruleValue + '】');
        self.__write_site_config(site_config)
        return public.returnMsg(True, '添加成功!');

    # 删除站点的一条自定义规则
    def remove_site_rule(self, get):
        site_config = self.get_site_config(None)
        index = int(get.index)
        if not get.ruleName in site_config[get.siteName]: return public.returnMsg(False, '指定规则不存在!');
        site_rule = site_config[get.siteName][get.ruleName][index]
        del (site_config[get.siteName][get.ruleName][index])
        self.__write_site_config(site_config)
        self.__write_log('删除站点【' + get.siteName + '】【' + get.ruleName + '】过滤规则【' + json.dumps(site_rule) + '】');
        return public.returnMsg(True, '删除成功!');

    # 导入内置默认规则（插件自带 defaults/rule/），只补不改：
    # 已存在的规则按"规则内容"去重，用户自己加的规则不会被覆盖
    def import_default_rule(self, get):
        names = ['url', 'args', 'post', 'cookie', 'user_agent',
                 'scan_black', 'ip_white', 'ip_black', 'url_white', 'url_black', 'head_white']
        only = ''
        try:
            if 'ruleName' in get and get.ruleName:
                only = str(get.ruleName)
        except Exception:
            only = ''
        if only:
            names = [only]

        report = []
        changed_any = False
        for name in names:
            default = self.__load_json(self.__PATH + 'defaults/rule/' + name + '.json', None)
            if default is None:
                report.append(name + ':无内置规则')
                continue
            dst = self.__path + 'rule/' + name + '.json'
            current = self.__load_json(dst, None)

            # scan_black 这类 {header, cookie, args} 结构
            if isinstance(default, dict):
                if not isinstance(current, dict) or not current:
                    public.writeFile(dst, json.dumps(default))
                    changed_any = True
                    report.append(name + ':已写入')
                    continue
                added = 0
                for k, v in default.items():
                    if not current.get(k):
                        current[k] = v
                        added += 1
                if added:
                    public.writeFile(dst, json.dumps(current))
                    changed_any = True
                    report.append(name + ':补全%d项' % added)
                else:
                    report.append(name + ':已存在')
                continue

            if not isinstance(default, list):
                continue
            if not isinstance(current, list):
                current = []

            # 四条一组 [状态, 正则, 说明, 可删除] 的过滤规则
            if default and isinstance(default[0], list) and len(default[0]) >= 2:
                exist = set()
                for it in current:
                    if isinstance(it, list) and len(it) > 1:
                        exist.add(str(it[1]))
                added = 0
                for it in default:
                    if str(it[1]) in exist:
                        continue
                    current.append(it)
                    exist.add(str(it[1]))
                    added += 1
                if added:
                    public.writeFile(dst, json.dumps(current))
                    changed_any = True
                report.append('%s:新增%d条' % (name, added))
            else:
                # IP 段 / URL 列表：只在为空时写入
                if current:
                    report.append(name + ':已有数据')
                    continue
                public.writeFile(dst, json.dumps(default))
                changed_any = True
                report.append(name + ':已写入')

        if changed_any:
            public.serviceReload()
        self.__write_log('导入内置默认规则：' + '，'.join(report))
        return public.returnMsg(True, '处理完成：' + '，'.join(report))

    # =========================================================================
    # 一键清空统计 / 历史日志
    # -------------------------------------------------------------------------
    # siteName 为空 = 全部站点：清空 total.json 的计数并把封锁历史、站点日志全删
    # siteName 指定 = 只清这个站点：清零它的统计并删除 logs/<站点>_*.log
    # =========================================================================
    def clear_site_data(self, get):
        """一键清空统计与历史日志（可指定站点，也可全部）"""
        site = str(self.__gv(get, 'siteName', '')).strip()
        keep_days = self.__gint(get, 'keep_days', 0)   # 预留：大于 0 时只删更早的日志
        removed = 0
        cleared = []

        total = self.__load_json(self.__path + 'total.json', {})
        if not isinstance(total, dict):
            total = {'rules': {}, 'sites': {}, 'total': 0}

        if site:
            if isinstance(total.get('sites'), dict) and site in total['sites']:
                item = total['sites'].pop(site)
                try:
                    total['total'] = max(0, int(total.get('total') or 0) - int(item.get('total') or 0))
                except (TypeError, ValueError):
                    pass
            cleared.append(site)
        else:
            total['sites'] = {}
            total['total'] = 0
            for k in list((total.get('rules') or {}).keys()):
                total['rules'][k] = 0
            cleared.append('全部站点')

        try:
            public.writeFile(self.__path + 'total.json', json.dumps(total, ensure_ascii=False))
            os.chmod(self.__path + 'total.json', 0o666)
        except Exception:
            pass

        # 删日志文件
        try:
            if site:
                paths = [self.__logs + site + '_' + time.strftime('%Y-%m-%d', time.localtime()) + '.log']
                import glob as _glob
                paths = _glob.glob(self.__logs + site + '_*.log')
            else:
                import glob as _glob
                paths = _glob.glob(self.__logs + '*.log')
            for p in paths:
                try:
                    os.remove(p)
                    removed += 1
                except OSError:
                    pass
        except Exception:
            pass

        # 站点配置里的 log_size 也归零
        sc = self.__load_json(self.__path + 'site.json', {})
        if isinstance(sc, dict):
            for name, item in sc.items():
                if site and name != site:
                    continue
                if isinstance(item, dict):
                    item['log_size'] = 0
            try:
                public.writeFile(self.__path + 'site.json', json.dumps(sc, ensure_ascii=False))
            except Exception:
                pass

        try:
            public.serviceReload()
        except Exception:
            pass
        self.__write_log('清空统计与日志：%s（删除日志 %d 个）' % (cleared[0], removed))
        return public.returnMsg(True, '已清空 %s 的统计，删除日志 %d 个' % (cleared[0], removed))

    # =========================================================================
    # 企业微信机器人推送提醒
    # -------------------------------------------------------------------------
    # 配置放在全局 config.json 的 notify 段，引擎侧 init_worker.lua 定时读取并推送。
    # rules 里每个开关对应一类命中：get/post/cc/scan/user_agent/cookie/head/limit/url_rule
    # =========================================================================
    # =========================================================================
    # 推送诊断 / 重新部署运行时引擎
    # -------------------------------------------------------------------------
    # 常见"日志有、但企业微信收不到"的原因：
    #   1) /www/server/x_waf/*.lua 还是旧版（只复制了插件目录，没跑 install.sh）
    #   2) 引擎文件更新了但 nginx 没 reload，worker 里还是老代码
    #   3) notify 没保存进 config.json，或开关没打开
    #   4) nginx 出网被限制（面板能发、nginx 发不了）
    # =========================================================================
    __ENGINE_FILES = ('init.lua', 'init_worker.lua', 'waf.lua', 'limit.lua')

    def notify_status(self, get):
        """推送诊断：检查运行时引擎版本 / 配置 / 错误日志，返回可读的结论"""
        out = []
        ok = True

        # 1) 运行时 lua 是否包含告警相关代码
        checks = [
            ('waf.lua', 'queue_alert', '命中入队代码'),
            ('init_worker.lua', 'notify_flush', '定时推送代码'),
            ('init.lua', 'XWAF.notify', '配置加载代码'),
        ]
        for fname, marker, desc in checks:
            path = self.__path + fname
            has = False
            if os.path.exists(path):
                try:
                    with open(path, 'rb') as fp:
                        has = marker.encode() in fp.read()
                except Exception:
                    pass
            out.append({'item': '运行时 %s 的%s' % (fname, desc),
                        'ok': has,
                        'msg': '已包含 ✓' if has else '缺失 ✗（引擎是旧版，需要重新部署）'})
            if not has:
                ok = False

        # 2) 插件包里的引擎是否比运行时的更新
        try:
            rt = os.path.getmtime(self.__path + 'init_worker.lua')
            src = os.path.getmtime(self.__PATH + 'init_worker.lua')
            diff = int(src - rt)
            out.append({'item': '引擎文件版本对比',
                        'ok': diff <= 0,
                        'msg': ('运行时不旧于插件包 ✓' if diff <= 0
                                else '插件包比运行时新 %d 秒，建议重新部署引擎' % diff)})
            if diff > 0:
                ok = False
        except Exception:
            out.append({'item': '引擎文件版本对比', 'ok': False, 'msg': '无法比较（文件缺失）'})
            ok = False

        # 3) 配置
        try:
            cfg = self.get_config(None)
            nf = cfg.get('notify') or {}
            out.append({'item': '配置中的推送开关',
                        'ok': bool(nf.get('open')),
                        'msg': ('已开启 ✓' if nf.get('open') else '未开启 ✗')})
            out.append({'item': '配置中的 Webhook',
                        'ok': bool(nf.get('webhook')),
                        'msg': nf.get('webhook') or '空 ✗'})
            rs = nf.get('rules') or {}
            picked = [k for k, v in rs.items() if v]
            out.append({'item': '勾选推送的规则类型',
                        'ok': len(picked) > 0,
                        'msg': ('、'.join(picked) if picked else '一个都没勾 ✗')})
            if not nf.get('open') or not nf.get('webhook') or not picked:
                ok = False
        except Exception as e:
            out.append({'item': '读取配置', 'ok': False, 'msg': '失败：' + str(e)})
            ok = False

        # 4) nginx 错误日志里有没有推送失败
        try:
            log = '/www/server/nginx/logs/error.log'
            tail = ''
            if os.path.exists(log):
                size = os.path.getsize(log)
                with open(log, 'rb') as fp:
                    if size > 200 * 1024:
                        fp.seek(size - 200 * 1024)
                    tail = fp.read().decode('utf-8', 'ignore')
            bad = [x for x in tail.splitlines() if '企业微信' in x or '无法写入' in x or '未匹配到站点' in x]
            out.append({'item': 'error.log 中的相关告警',
                        'ok': True,
                        'msg': ('\n'.join(bad[-5:]) if bad else '没有异常记录 ✓')})
        except Exception:
            pass

        tip = '全部正常' if ok else '发现问题，点「重新部署引擎并重载」再试'
        return public.returnMsg(ok, {'tip': tip, 'rows': out})

    def sync_engine(self, get):
        """把插件包里的 lua 引擎 / 拦截页重新部署到运行时目录，并 reload nginx"""
        done = []
        failed = []
        for fname in self.__ENGINE_FILES:
            src = self.__PATH + fname
            dst = self.__path + fname
            if not os.path.exists(src):
                failed.append(fname + '（插件包里没有）')
                continue
            try:
                with open(src, 'rb') as fp:
                    data = fp.read()
                with open(dst, 'wb') as fp:
                    fp.write(data)
                try:
                    os.chmod(dst, 0o644)
                except Exception:
                    pass
                done.append(fname)
            except Exception as e:
                failed.append('%s（%s）' % (fname, e))

        # 拦截提示页
        for fname in ('get.html', 'post.html', 'cookie.html', 'user_agent.html', 'other.html'):
            src = self.__PATH + 'defaults/html/' + fname
            dst = self.__path + 'html/' + fname
            if os.path.exists(src) and not os.path.exists(dst):
                try:
                    d = os.path.dirname(dst)
                    if not os.path.isdir(d):
                        os.makedirs(d)
                    with open(src, 'rb') as fp:
                        data = fp.read()
                    with open(dst, 'wb') as fp:
                        fp.write(data)
                    os.chmod(dst, 0o644)
                except Exception:
                    pass

        # reload nginx
        reload_msg = ''
        try:
            public.serviceReload()
            reload_msg = 'nginx 已 reload'
        except Exception as e:
            reload_msg = 'reload 调用失败：' + str(e)
        try:
            import subprocess
            for binp in ('/www/server/nginx/sbin/nginx', '/usr/sbin/nginx', 'nginx'):
                if binp == 'nginx' or os.path.exists(binp):
                    r = subprocess.run([binp, '-s', 'reload'], capture_output=True, timeout=15)
                    if r.returncode == 0:
                        reload_msg += '；命令 reload 成功'
                    break
        except Exception:
            pass

        self.__write_log('重新部署运行时引擎：' + ','.join(done))
        msg = '已部署 %d 个文件（%s），%s' % (len(done), ','.join(done), reload_msg)
        if failed:
            msg += '；失败：' + '、'.join(failed)
        return public.returnMsg(len(done) > 0, msg)

    # =========================================================================
    # 面板侧兜底推送 notify_pump
    # -------------------------------------------------------------------------
    # 引擎侧（nginx cosocket）推送不依赖这里；这个方法用 Python 直接读日志推送，
    # 用于：① 证明 Webhook + 内容组织是通的  ② 引擎推不动时的兜底（可挂计划任务）
    # 状态记在 /www/server/x_waf/.notify_state.json，记录每个日志文件已推到的字节偏移。
    # =========================================================================
    def __notify_state_file(self):
        return self.__path + '.notify_state.json'

    def __wecom_send_markdown(self, webhook, content):
        """用 Python 直接 POST 一条 markdown 消息到企业微信机器人"""
        body = json.dumps({'msgtype': 'markdown', 'markdown': {'content': content}}, ensure_ascii=False)
        try:
            import urllib.request as _u
            req = _u.Request(webhook, data=body.encode('utf-8'),
                             headers={'Content-Type': 'application/json'})
            with _u.urlopen(req, timeout=10) as r:
                resp = r.read().decode('utf-8', 'ignore')
        except Exception as e:
            return False, '发送失败：' + str(e)
        try:
            j = json.loads(resp)
            if j.get('errcode') == 0:
                return True, 'ok'
            return False, 'errcode=%s errmsg=%s' % (j.get('errcode'), j.get('errmsg'))
        except Exception:
            return False, resp[:200]

    def notify_pump(self, get):
        """扫描当天日志里"还没推送过"的拦截记录，聚合成一条消息推送给企业微信"""
        if self.throttle_backend():     # 防并发重复推
            return public.returnMsg(False, '上一次补推还在进行中，请稍候')
        cfg = self.get_config(None)
        nf = cfg.get('notify') or {}
        webhook = str(self.__gv(get, 'webhook', '') or nf.get('webhook') or '').strip()
        if not webhook:
            return public.returnMsg(False, '还没有配置 Webhook，请先在「拦截提醒设置」里填写并保存')
        hook, herr = self.__norm_webhook(webhook)
        if herr:
            return public.returnMsg(False, 'Webhook 地址有问题：' + herr)
        webhook = hook

        # 只看最近 max_minutes 分钟内的记录，避免一次把历史全推出来
        max_minutes = max(1, min(1440, self.__gint(get, 'minutes', 30)))
        force = self.__gbool(get, 'force', True)      # 首次补推时忽略偏移，直接看最近 N 分钟

        state = self.__load_json(self.__notify_state_file(), {})
        if not isinstance(state, dict):
            state = {}
        mday = time.strftime('%Y-%m-%d', time.localtime())
        now_ts = time.time()
        cutoff = now_ts - max_minutes * 60

        agg, order, total = {}, [], 0
        try:
            import glob as _glob
            for path in _glob.glob(self.__logs + '*_' + mday + '.log'):
                site = os.path.basename(path)[:-(len(mday) + 6)]
                try:
                    size = os.path.getsize(path)
                    skip = 0 if force else int(state.get(path, 0) or 0)
                    if skip > size:
                        skip = 0
                    with open(path, 'rb') as fp:
                        fp.seek(skip)
                        for line in fp:
                            try:
                                row = json.loads(line.decode('utf-8', 'ignore').strip())
                            except Exception:
                                continue
                            # 时间过滤
                            try:
                                lts = time.mktime(time.strptime(str(row[0]), '%Y-%m-%d %H:%M:%S'))
                            except Exception:
                                lts = now_ts
                            if lts < cutoff:
                                continue
                            total += 1
                            f = str(row[5] if len(row) > 5 else '')
                            if site not in agg:
                                agg[site] = {'count': 0, 'kinds': {}, 'first': row}
                                order.append(site)
                            agg[site]['count'] += 1
                            agg[site]['kinds'][f] = agg[site]['kinds'].get(f, 0) + 1
                        state[path] = fp.tell()
                except Exception:
                    continue
        except Exception as e:
            return public.returnMsg(False, '读取日志失败：' + str(e))

        if total == 0:
            return public.returnMsg(True, '最近 %d 分钟内没有新的拦截记录（说明没触发规则，或日志已清空）' % max_minutes)

        name_map = {'args': 'GET渗透', 'url': 'GET渗透', 'url_black': 'GET渗透', 'post': 'POST渗透',
                    'cc': 'CC攻击', 'limit_ip': 'URL限频', 'limit_key': 'URL限频',
                    'user_agent': '恶意UA', 'cookie': 'Cookie渗透', 'scan': '扫描器', 'head': '黑名单'}
        lines = ['**x_waf 拦截提醒（面板补推）**']
        shown = 0
        for site in order:
            shown += 1
            if shown > 5:
                break
            a = agg[site]
            parts = []
            for k, c in a['kinds'].items():
                parts.append('%s x%d' % (name_map.get(k, k), c))
            first = a['first']
            lines.append('> 站点：' + site)
            lines.append('> 类型：' + '、'.join(parts))
            lines.append('> 最近：%s  %s' % (first[1] if len(first) > 1 else '',
                                             str(first[3] if len(first) > 3 else '')[:90]))
        if len(order) > 5:
            lines.append('> 另有 %d 个站点也触发' % (len(order) - 5))
        lines.append('> 时间：%s  共 %d 条' % (time.strftime('%Y-%m-%d %H:%M:%S'), total))
        content = '\n'.join(lines)[:3000]

        ok, msg = self.__wecom_send_markdown(webhook, content)
        if ok:
            try:
                public.writeFile(self.__notify_state_file(), json.dumps(state))
            except Exception:
                pass
            self.__write_log('面板补推企业微信：%d 条' % total)
            return public.returnMsg(True, '已推送 %d 条拦截记录到企业微信，请查看群消息' % total)
        return public.returnMsg(False, '推送失败：' + msg)

    def throttle_backend(self):
        """面板侧简单互斥：10 秒内只允许一次补推"""
        marker = self.__path + '.notify_pump.lock'
        try:
            if os.path.exists(marker):
                if time.time() - os.path.getmtime(marker) < 10:
                    return True
            with open(marker, 'w') as fp:
                fp.write(str(int(time.time())))
            return False
        except Exception:
            return False

    def __norm_webhook(self, val):
        """把用户填的 Webhook 归一化成标准地址。

        面板/浏览器/复制粘贴都可能把网址弄脏，这里统一清洗：
          · 去首尾空白、零宽字符、引号
          · 全角符号转半角（＝ ？ ： ／ 等在中文输入法下很常见）
          · 缺 https:// 时自动补上
          · 只要能从串里提取到 key，就重建成企业微信标准地址
        返回 (标准地址, 错误信息)
        """
        s = str(val or '')
        for ch in ('\u200b', '\u200c', '\u200d', '\ufeff', '\n', '\r', '\t', ' '):
            s = s.replace(ch, '')
        s = s.strip().strip('"').strip("'")
        # 全角 → 半角
        table = {0xFF1D: '=', 0xFF1F: '?', 0xFF1A: ':', 0xFF0F: '/', 0xFF06: '&',
                 0x3002: '.', 0x3000: '', 0xFF0E: '.', 0xFF0D: '-'}
        s = s.translate(table)
        if not s:
            return '', 'Webhook 地址为空'
        if not s.lower().startswith('http'):
            s = 'https://' + s.lstrip('/')
        m = re.search(r'[?&]key=([A-Za-z0-9_\-]{8,})', s)
        if not m:
            return '', '地址里没有找到 key 参数，请重新复制企业微信机器人的 Webhook 地址'
        key = m.group(1)
        if 'weixin.qq.com' not in s:
            return '', '这不是企业微信的地址（应包含 qyapi.weixin.qq.com）'
        return 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=' + key, ''

    def __notify_default(self):
        """企业微信提醒默认配置"""
        return {
            'open': False,
            'webhook': '',
            'interval': 60,                       # 两次推送最小间隔（秒）
            'max_batch': 50,                      # 单次最多聚合多少条
            'rules': {
                'get': True, 'post': True, 'cc': True, 'scan': True,
                'user_agent': True, 'cookie': False, 'head': True,
                'limit': True, 'url_rule': True
            }
        }

    def get_notify_config(self, get):
        """读取企业微信提醒配置（缺字段自动补默认值）"""
        config = self.get_config(None)
        nf = config.get('notify')
        dft = self.__notify_default()
        if not isinstance(nf, dict):
            nf = dict(dft)
        for k, v in dft.items():
            if k == 'rules':
                if not isinstance(nf.get('rules'), dict):
                    nf['rules'] = dict(v)
                else:
                    for rk, rv in v.items():
                        nf['rules'].setdefault(rk, rv)
            else:
                nf.setdefault(k, v)
        return public.returnMsg(True, nf)

    def save_notify_config(self, get):
        """保存企业微信提醒配置：webhook、推送间隔、以及要推送哪些规则"""
        try:
            config = self.get_config(None)
            nf = self.__notify_default()
            nf['open'] = self.__gbool(get, 'open', False)
            hook, herr = self.__norm_webhook(self.__gv(get, 'webhook', ''))
            nf['webhook'] = hook
            nf['interval'] = max(10, self.__gint(get, 'interval', 60))
            nf['max_batch'] = max(1, min(200, self.__gint(get, 'max_batch', 50)))
            rules = {}
            for k in ('get', 'post', 'cc', 'scan', 'user_agent', 'cookie', 'head', 'limit', 'url_rule'):
                rules[k] = self.__gbool(get, 'rules_' + k, False)
            nf['rules'] = rules

            # 只有"启用推送"时才校验地址和规则勾选；关闭时随便存，不报错
            if nf['open']:
                if herr:
                    return public.returnMsg(False, 'Webhook 地址有问题：' + herr)
                if not any(rules.values()):
                    return public.returnMsg(False, '至少勾选一种要推送的规则')
            config['notify'] = nf
            try:
                public.writeFile(self.__path + 'config.json', json.dumps(config, ensure_ascii=False))
            except Exception as e:
                return public.returnMsg(False, '写入配置失败：' + str(e))
            try:
                public.serviceReload()
            except Exception:
                pass
            self.__write_log('保存企业微信提醒配置：' + ('开启' if nf['open'] else '关闭'))
            return public.returnMsg(True, '已保存（%s）' % ('已开启推送' if nf['open'] else '未开启推送'))
        except Exception as e:
            # 任何意外都把真实原因抛给前端，避免只显示"系统错误"
            return public.returnMsg(False, '保存异常：%s: %s' % (type(e).__name__, e))

    def test_notify(self, get):
        """发送一条测试消息到企业微信机器人"""
        hook, herr = self.__norm_webhook(self.__gv(get, 'webhook', ''))
        if herr:
            config = self.get_config(None)
            hook, herr = self.__norm_webhook((config.get('notify') or {}).get('webhook', ''))
            if herr:
                return public.returnMsg(False, 'Webhook 地址有问题：' + herr)
        webhook = hook
        msg = {
            'msgtype': 'markdown',
            'markdown': {
                'content': '**x_waf 测试消息**\n> 服务器：%s\n> 时间：%s\n> 收到这条消息说明机器人配置正确 ✅' % (
                    public.GetLocalIp() if hasattr(public, 'GetLocalIp') else '本机',
                    time.strftime('%Y-%m-%d %H:%M:%S'))
            }
        }
        body = json.dumps(msg, ensure_ascii=False)
        try:
            import urllib.request as _u
            req = _u.Request(webhook, data=body.encode('utf-8'),
                             headers={'Content-Type': 'application/json'})
            with _u.urlopen(req, timeout=8) as r:
                resp = r.read().decode('utf-8', 'ignore')
        except Exception as e:
            return public.returnMsg(False, '发送失败：' + str(e))
        try:
            j = json.loads(resp)
            if j.get('errcode') == 0:
                return public.returnMsg(True, '测试消息已发送，请到企业微信群查看')
            return public.returnMsg(False, '企业微信返回 errcode=%s errmsg=%s' % (
                j.get('errcode'), j.get('errmsg')))
        except Exception:
            return public.returnMsg(False, '返回异常：' + resp[:200])

    # -------------------------------------------------------------------------
    # 规则文件格式化读写
    #   __fmt_rule_json: 把规则数据序列化成"一条规则一行"的易读 JSON
    #   get_rule_file  : 读取某个规则文件，同时返回格式化文本与结构化数据
    #   save_rule_file : 保存规则文件（先校验 JSON，再写盘 + reload）
    # -------------------------------------------------------------------------
    def __fmt_rule_json(self, data):
        """规则文件美化输出：
        列表型 → 每条规则压成一行 [1, "正则", "名称", 0]，方便肉眼扫读；
        多行块型 → 标准缩进 JSON（值是带 \n 的正则块）。
        """
        def one(v):
            if isinstance(v, bool):
                return 'true' if v else 'false'
            if isinstance(v, (int, float)):
                return str(v)
            if v is None:
                return 'null'
            if isinstance(v, str):
                return json.dumps(v, ensure_ascii=False)
            if isinstance(v, list):
                return '[' + ', '.join(one(x) for x in v) + ']'
            if isinstance(v, dict):
                return '{' + ', '.join('%s: %s' % (json.dumps(k, ensure_ascii=False), one(x))
                                       for k, x in v.items()) + '}'
            return json.dumps(v, ensure_ascii=False)

        if isinstance(data, list):
            if not data:
                return '[]'
            lines = ['[']
            for i, item in enumerate(data):
                comma = ',' if i < len(data) - 1 else ''
                lines.append('  ' + one(item) + comma)
            lines.append(']')
            return '\n'.join(lines)
        if isinstance(data, dict):
            if not data:
                return '{}'
            lines = ['{']
            keys = list(data.keys())
            for i, k in enumerate(keys):
                comma = ',' if i < len(keys) - 1 else ''
                lines.append('  ' + json.dumps(k, ensure_ascii=False) + ': ' + one(data[k]) + comma)
            lines.append('}')
            return '\n'.join(lines)
        return json.dumps(data, ensure_ascii=False)

    def get_rule_file(self, get):
        """读取规则文件：返回格式化文本 + 结构化数据（供面板「查看」页展示）"""
        name = str(self.__gv(get, 'name', '')).strip()
        if name not in self.__RULE_FILES:
            return public.returnMsg(False, '未知规则文件：' + name)
        path = self.__rule_path(name)
        data = self.__load_json(path, None)
        if data is None:
            # 文件不存在时用插件内置规则兜底展示
            data = self.__load_json(self.__rule_builtin(name), [] if name != 'scan_black' else {})
            if data is None:
                return public.returnMsg(False, '规则文件不存在且没有内置默认值')
        kind = 'dict' if isinstance(data, dict) else 'list'
        return public.returnMsg(True, {
            'name': name,
            'kind': kind,
            'count': self.__count_rule_items(data),
            'raw': self.__fmt_rule_json(data),
            'data': data,
            'path': path
        })

    def save_rule_file(self, get):
        """保存规则文件（内容来自面板编辑框），校验 JSON 后再写盘"""
        name = str(self.__gv(get, 'name', '')).strip()
        if name not in self.__RULE_FILES:
            return public.returnMsg(False, '未知规则文件：' + name)
        txt = self.__gv(get, 'content', '')
        if isinstance(txt, str):
            try:
                data = json.loads(txt)
            except Exception as e:
                return public.returnMsg(False, 'JSON 格式错误：' + str(e))
        else:
            data = txt
        if name == 'scan_black':
            if not isinstance(data, dict):
                return public.returnMsg(False, 'scan_black.json 必须是 {"header": "...", "cookie": "...", "args": "..."} 结构')
        elif not isinstance(data, list):
            return public.returnMsg(False, '该规则文件必须是列表结构 [启用, 正则, 名称, 0]')
        else:
            for i, r in enumerate(data):
                if not isinstance(r, list) or len(r) < 2:
                    return public.returnMsg(False, '第 %d 条格式不对，应为 [1, "正则", "名称", 0]' % (i + 1))
        try:
            public.writeFile(self.__rule_path(name), self.__fmt_rule_json(data))
        except Exception as e:
            return public.returnMsg(False, '写入失败：' + str(e))
        try:
            public.serviceReload()
        except Exception:
            pass
        self.__write_log('修改规则文件：%s（%d 条）' % (name, self.__count_rule_items(data)))
        return public.returnMsg(True, '已保存 %s.json（%d 条规则），已生效' % (name, self.__count_rule_items(data)))

    # =========================================================================
    # 规则库：查看 / 一键批量拉取更新
    # -------------------------------------------------------------------------
    # 规则来源优先级：
    #   1) 前端传入的远端目录 URL（形如 https://example.com/x_waf/rule），
    #      依次拉取 <URL>/<文件>.json
    #   2) 插件包内自带的 defaults/rule/<文件>.json（升级插件包后即可获得新规则）
    # 合并策略：
    #   merge   —— 按"正则内容"去重追加，用户自己加的/改过的规则一条都不动（推荐）
    #   replace —— 直接用来源整体覆盖
    # =========================================================================
    __RULE_FILES = ('url', 'args', 'post', 'user_agent', 'cookie', 'scan_black',
                    'url_black', 'url_white', 'ip_white', 'ip_black', 'head_white', 'cn')

    # 统计规则条数：列表算元素个数，多行块算非空行数
    def __count_rule_items(self, data):
        """统计规则条数：列表型算元素个数；多行块型（scan_black）算非空行数"""
        if isinstance(data, list):
            return len(data)
        if isinstance(data, dict):
            n = 0
            for v in data.values():
                if isinstance(v, str):
                    n += len([x for x in v.split('\n') if x.strip()])
                elif isinstance(v, list):
                    n += len(v)
            return n
        return 0

    # 运行时规则文件路径 /www/server/x_waf/rule/<name>.json
    def __rule_path(self, name):
        """运行时规则文件绝对路径"""
        return self.__path + 'rule/' + name + '.json'

    # 插件包自带的默认规则文件路径 defaults/rule/<name>.json
    def __rule_builtin(self, name):
        """插件包自带的默认规则文件路径"""
        return self.__PATH + 'defaults/rule/' + name + '.json'

    # 拉取远端 JSON（优先面板 public.httpGet，失败再用 urllib），不可用返回 None
    def __fetch_json(self, url):
        """拉取远端 JSON；失败返回 None（不抛异常）"""
        for fn in ('httpGet', 'HttpGet'):
            try:
                f = getattr(public, fn, None)
                if f:
                    txt = f(url)
                    if txt:
                        return json.loads(txt)
            except Exception:
                pass
        try:
            import urllib.request as _u
            with _u.urlopen(url, timeout=8) as r:
                return json.loads(r.read().decode('utf-8', 'ignore'))
        except Exception:
            return None

    # 列出运行时规则文件：条数/大小/更新时间（「规则库」面板展示用）
    def get_rule_files(self, get):
        """列出运行时规则文件：条数 / 大小 / 修改时间，供「规则库」面板展示"""
        out = []
        for name in self.__RULE_FILES:
            path = self.__rule_path(name)
            item = {'name': name, 'path': path, 'count': 0, 'size': 0, 'mtime': '', 'exists': False}
            if os.path.exists(path):
                try:
                    item['exists'] = True
                    item['size'] = os.path.getsize(path)
                    item['mtime'] = time.strftime('%Y-%m-%d %H:%M',
                                                  time.localtime(os.path.getmtime(path)))
                    item['count'] = self.__count_rule_items(self.__load_json(path, []))
                except Exception:
                    pass
            out.append(item)
        total = sum(x['count'] for x in out)
        return public.returnMsg(True, {'files': out, 'total': total})

    # 一键批量更新规则库：mode=merge 去重追加 / replace 整体覆盖，url 可指定远端目录
    def update_rules(self, get):
        """一键批量更新规则库
        参数：
            mode = merge（默认，去重追加）| replace（整体覆盖）
            url  = 可选，远端规则目录；留空则用插件包内置规则
        """
        mode = str(self.__gv(get, 'mode', 'merge')).strip().lower()
        if mode not in ('merge', 'replace'):
            mode = 'merge'
        base_url = str(self.__gv(get, 'url', '')).strip().rstrip('/')

        rule_dir = self.__path + 'rule'
        if not os.path.exists(rule_dir):
            try:
                os.makedirs(rule_dir)
            except OSError:
                return public.returnMsg(False, '规则目录创建失败：' + rule_dir)

        detail = []
        total_added = 0
        remote_ok = 0
        remote_fail = 0

        for name in self.__RULE_FILES:
            cur_path = self.__rule_path(name)
            src = None
            src_from = 'builtin'

            # 1) 优先远端
            if base_url:
                src = self.__fetch_json('%s/%s.json' % (base_url, name))
                if src is not None:
                    remote_ok += 1
                else:
                    remote_fail += 1

            # 2) 回落插件内置
            if src is None:
                src = self.__load_json(self.__rule_builtin(name), None)
                src_from = 'builtin'
            if src is None:
                continue

            cur = self.__load_json(cur_path, None)
            before = self.__count_rule_items(cur) if cur is not None else 0

            # --- 多行块型（scan_black）：header/cookie/args 各是一段多行正则 ---
            if isinstance(src, dict):
                if mode == 'replace' or not isinstance(cur, dict):
                    merged = dict(src)
                else:
                    merged = dict(cur)
                    for k, v in src.items():
                        if not isinstance(v, str):
                            merged[k] = v
                            continue
                        old = merged.get(k) or ''
                        exist = set(x.strip() for x in old.split('\n') if x.strip())
                        add = [x for x in v.split('\n') if x.strip() and x.strip() not in exist]
                        if add:
                            merged[k] = (old.rstrip('\n') + '\n' + '\n'.join(add)).strip('\n')
            # --- 列表型：按正则去重追加 ---
            elif isinstance(src, list):
                if mode == 'replace' or not isinstance(cur, list):
                    merged = list(src)
                else:
                    merged = list(cur)
                    have = set()
                    for r in merged:
                        if isinstance(r, list) and len(r) > 1:
                            have.add(str(r[1]))
                    for r in src:
                        if isinstance(r, list) and len(r) > 1 and str(r[1]) not in have:
                            merged.append(r)
                            have.add(str(r[1]))
            else:
                continue

            try:
                public.writeFile(cur_path, self.__fmt_rule_json(merged))
            except Exception as e:
                detail.append({'name': name, 'error': str(e)})
                continue

            after = self.__count_rule_items(merged)
            total_added += max(0, after - before)
            detail.append({'name': name, 'before': before, 'after': after,
                           'added': max(0, after - before), 'source': src_from})

        try:
            public.serviceReload()
        except Exception:
            pass
        self.__write_log('一键更新规则库（%s）：共新增 %d 条%s' % (
            '合并' if mode == 'merge' else '覆盖', total_added,
            '，远端成功 %d 个文件' % remote_ok if base_url else '，来源：插件内置'))
        msg = '更新完成，共 %d 个文件，新增 %d 条规则' % (len(detail), total_added)
        if base_url and remote_fail:
            msg += '（远端 %d 个文件拉取失败，已用内置规则补上）' % remote_fail
        return public.returnMsg(True, msg, detail)

    # ================= 手动添加站点（nginx 配置里直接写的站点） =================
    def add_site(self, get):
        name = str(self.__gv(get, 'siteName', '')).strip().lower()
        if not name:
            return public.returnMsg(False, '站点名（主域名）不能为空')
        try:
            re.match(r'^[a-z0-9][a-z0-9._:\-*]{0,190}$', name)
        except Exception:
            pass
        if not re.match(r'^[a-z0-9][a-z0-9._:\-*]{0,190}$', name):
            return public.returnMsg(False, '站点名格式不正确（只能用域名/字母数字/点/横线）')

        panel_sites = [s['name'] for s in public.M('sites').field('name').select()]
        if name in panel_sites:
            return public.returnMsg(False, '该站点已在面板站点列表里，会自动显示，无需手动添加')

        raw = str(self.__gv(get, 'domains', ''))
        for ch in ('，', '；', ';', '\n', '\r', ' '):
            raw = raw.replace(ch, ',')
        dlist = []
        for d in raw.split(','):
            d = d.strip().lower()
            if d and d not in dlist:
                dlist.append(d)
        if name not in dlist:
            dlist.insert(0, name)

        cfg = self.__load_json(self.__path + 'site.json', {})
        if not isinstance(cfg, dict):
            cfg = {}
        if name in cfg:
            return public.returnMsg(False, '该站点已存在（如需修改域名，请先移除再添加）')
        conf = self.__get_site_conf()
        conf['manual'] = True
        conf['domains'] = dlist
        cfg[name] = conf
        public.writeFile(self.__path + 'site.json', json.dumps(cfg, ensure_ascii=False))
        try:
            self.__write_site_domains()
        except Exception:
            pass
        public.serviceReload()
        self.__write_log('手动添加站点【' + name + '】域名：' + ','.join(dlist))
        return public.returnMsg(True, '已添加站点 ' + name + '（域名 ' + ','.join(dlist) + '）')

    # 移除手动添加的站点（面板站点不允许在这里删）
    def remove_site(self, get):
        name = str(self.__gv(get, 'siteName', '')).strip().lower()
        cfg = self.__load_json(self.__path + 'site.json', {})
        if not isinstance(cfg, dict) or name not in cfg:
            return public.returnMsg(False, '站点配置不存在')
        if not cfg[name].get('manual'):
            return public.returnMsg(False, '面板站点不能在这里移除，请到【网站】里删除')
        cfg.pop(name)
        public.writeFile(self.__path + 'site.json', json.dumps(cfg, ensure_ascii=False))
        try:
            self.__write_site_domains()
        except Exception:
            pass
        public.serviceReload()
        self.__write_log('移除手动添加的站点【' + name + '】')
        return public.returnMsg(True, '已移除站点 ' + name)

    # ================= URL 限频（IP 维度 + Key 维度） =================
    def __limit_file(self):
        return self.__path + 'limit.json'

    # 安全取参数：get 里没有或为 None 时返回默认值
    def __gv(self, get, name, default=''):
        try:
            if name in get and get[name] is not None:
                return get[name]
        except Exception:
            pass
        return default

    # 把参数解析成布尔（1/0/true/false/on/off）
    def __gbool(self, get, name, default=True):
        v = str(self.__gv(get, name, '1' if default else '0')).strip().lower()
        return v not in ('0', 'false', 'off', '')

    # 把参数解析成整数，解析失败返回默认值
    def __gint(self, get, name, default=0):
        try:
            return int(float(str(self.__gv(get, name, default))))
        except Exception:
            return default

    # 读取全部 URL 限频规则
    def get_limits(self, get):
        data = self.__load_json(self.__limit_file(), [])
        if not isinstance(data, list):
            data = []
        return public.returnMsg(True, data)

    # 新增/保存一条 URL 限频规则（校验正则、维度、次数）
    def save_limit(self, get):
        index = self.__gint(get, 'index', -1)
        url = str(self.__gv(get, 'url', '')).strip()
        if not url:
            return public.returnMsg(False, 'URL 正则不能为空')
        try:
            re.compile(url)
        except Exception as e:
            return public.returnMsg(False, 'URL 正则不合法：' + str(e))

        ip_open = self.__gbool(get, 'ip_open', True)
        key_open = self.__gbool(get, 'key_open', False)
        ip_limit = self.__gint(get, 'ip_limit', 0)
        key_limit = self.__gint(get, 'key_limit', 0)
        if not ip_open and not key_open:
            return public.returnMsg(False, 'IP 维度和 Key 维度至少要启用一个')
        if ip_open and ip_limit <= 0:
            return public.returnMsg(False, 'IP 维度的次数必须大于 0')
        if key_open and key_limit <= 0:
            return public.returnMsg(False, 'Key 维度的次数必须大于 0')
        key_name = str(self.__gv(get, 'key_name', '')).strip()
        if key_open and not key_name:
            return public.returnMsg(False, 'Key 名称不能为空（如 X-Api-Key / token）')
        key_source = str(self.__gv(get, 'key_source', 'header')).strip()
        if key_source not in ('header', 'arg', 'cookie'):
            key_source = 'header'

        rule = {
            'open': self.__gbool(get, 'open', True),
            'url': url,
            'memo': str(self.__gv(get, 'memo', '')).strip()[:100],
            'status': self.__gint(get, 'status', 429) or 429,
            'ip': {
                'open': ip_open,
                'cycle': max(1, self.__gint(get, 'ip_cycle', 60)),
                'limit': max(0, ip_limit)
            },
            'key': {
                'open': key_open,
                'source': key_source,
                'name': key_name,
                'cycle': max(1, self.__gint(get, 'key_cycle', 60)),
                'limit': max(0, key_limit)
            }
        }

        data = self.__load_json(self.__limit_file(), [])
        if not isinstance(data, list):
            data = []
        if index >= 0 and index < len(data):
            data[index] = rule
            msg = '修改已保存'
        else:
            data.append(rule)
            msg = '限频规则已添加'
        public.writeFile(self.__limit_file(), json.dumps(data, ensure_ascii=False))
        public.serviceReload()
        self.__write_log('保存 URL 限频规则【' + url + '】')
        return public.returnMsg(True, msg)

    # 删除一条限频规则
    def remove_limit(self, get):
        data = self.__load_json(self.__limit_file(), [])
        if not isinstance(data, list):
            data = []
        index = self.__check_index(data, self.__gv(get, 'index', -1))
        if index is None:
            return public.returnMsg(False, '规则不存在，请刷新后重试')
        rule = data.pop(index)
        public.writeFile(self.__limit_file(), json.dumps(data, ensure_ascii=False))
        public.serviceReload()
        self.__write_log('删除 URL 限频规则【' + str(rule.get('url', '')) + '】')
        return public.returnMsg(True, '已删除')

    # 启用/停用一条限频规则
    def set_limit_state(self, get):
        data = self.__load_json(self.__limit_file(), [])
        if not isinstance(data, list):
            data = []
        index = self.__check_index(data, self.__gv(get, 'index', -1))
        if index is None:
            return public.returnMsg(False, '规则不存在，请刷新后重试')
        data[index]['open'] = not bool(data[index].get('open', True))
        public.writeFile(self.__limit_file(), json.dumps(data, ensure_ascii=False))
        public.serviceReload()
        return public.returnMsg(True, '已启用' if data[index]['open'] else '已停用')

    # 读取某个规则文件（url/args/post/…）
    def get_rule(self, get):
        rule = self.__get_rule(get.ruleName)
        if not rule: return [];
        return rule

    # 往规则文件追加一条规则
    def add_rule(self, get):
        rule = self.__get_rule(get.ruleName)
        ruleValue = [1, get.ruleValue.strip(), get.ps, 1]
        for ru in rule:
            if ru[1] == ruleValue[1]: return public.returnMsg(False, '指定规则已存在，请勿重复添加');
        rule.append(ruleValue)
        self.__write_rule(get.ruleName, rule)
        self.__write_log('添加全局规则【' + get.ruleName + '】【' + get.ps + '】');
        return public.returnMsg(True, '添加成功!');

    # 从规则文件删除一条规则
    def remove_rule(self, get):
        rule = self.__get_rule(get.ruleName)
        index = self.__check_index(rule, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        ps = rule[index][2]
        del (rule[index])
        self.__write_rule(get.ruleName, rule)
        self.__write_log('删除全局规则【' + get.ruleName + '】【' + ps + '】');
        return public.returnMsg(True, '删除成功!');

    # 修改规则文件里的一条规则
    def modify_rule(self, get):
        rule = self.__get_rule(get.ruleName)
        index = self.__check_index(rule, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        rule[index][1] = get.ruleBody
        rule[index][2] = get.rulePs
        self.__write_rule(get.ruleName, rule)
        self.__write_log('修改全局规则【' + get.ruleName + '】【' + get.rulePs + '】');
        return public.returnMsg(True, '修改成功!');

    # 启用/停用某条规则
    def set_rule_state(self, get):
        rule = self.__get_rule(get.ruleName)
        index = self.__check_index(rule, get.index)
        if index is None: return public.returnMsg(False, '规则不存在，请刷新后重试')
        if rule[index][0] == 0:
            rule[index][0] = 1;
        else:
            rule[index][0] = 0;
        self.__write_rule(get.ruleName, rule)
        self.__write_log(self.__state[rule[index][0]] + '全局规则【' + get.ruleName + '】【' + rule[index][2] + '】');
        return public.returnMsg(True, '设置成功!');

    # 读取站点被禁用的规则项（disable_ext 等）
    def get_site_disable_rule(self, get):
        rule = self.__get_rule(get.ruleName)
        site_config = self.get_site_config(None)
        site_rule = site_config[get.siteName]['disable_rule'][get.ruleName]
        for i in range(len(rule)):
            if rule[i][0] == 0: rule[i][0] = -1;
            if i in site_rule: rule[i][0] = 0;
        return rule;

    # 设置站点禁用某个规则项
    def set_site_disable_rule(self, get):
        site_config = self.get_site_config(None)
        index = int(get.index)
        if index in site_config[get.siteName]['disable_rule'][get.ruleName]:
            for i in range(len(site_config[get.siteName]['disable_rule'][get.ruleName])):
                if index == site_config[get.siteName]['disable_rule'][get.ruleName][i]:
                    del (site_config[get.siteName]['disable_rule'][get.ruleName][i])
                    break
        else:
            site_config[get.siteName]['disable_rule'][get.ruleName].append(index)
        self.__write_log('设置站点【' + get.siteName + '】应用规则【' + get.ruleName + '】状态');
        self.__write_site_config(site_config)
        return public.returnMsg(True, '设置成功!');

    # 分页读取站点拦截日志 / 封锁历史（按行倒序，10 或 14 条一页）
    def get_safe_logs(self, get):
        try:
            esc = self.__escape
            pythonV = sys.version_info[0]
            if 'drop_ip' in get:
                path = self.__path + 'drop_ip.log'
                num = 14
            else:
                path = self.__logs + get.siteName + '_' + get.toDate + '.log'
                num = 10
            if not os.path.exists(path): return []
            p = 1
            if 'p' in get:
                p = int(get.p)
            start_line = (p - 1) * num
            count = start_line + num
            fp = open(path, 'rb')
            buf = ""
            try:
                fp.seek(-1, 2)
            except:
                return []
            if fp.read(1) == "\n": fp.seek(-1, 2)
            data = []
            b = True
            n = 0
            c = 0
            while c < count:
                while True:
                    newline_pos = str.rfind(buf, "\n")
                    pos = fp.tell()
                    if newline_pos != -1:
                        if n >= start_line:
                            line = buf[newline_pos + 1:]
                            if line:
                                try:
                                    tmp_data = json.loads(esc(line, False))   # quote=False：否则会把 JSON 的引号转义掉导致解析失败
                                    for i in range(len(tmp_data)):
                                        if i == 7:
                                            tmp_data[i] = str(tmp_data[i]).replace('&amp;', '&').replace('&lt;',
                                                                                                         '<').replace(
                                                '&gt;', '>')
                                        else:
                                            tmp_data[i] = esc(str(tmp_data[i]), True)
                                    data.append(tmp_data)
                                except:
                                    c -= 1
                                    n -= 1
                                    pass
                            else:
                                c -= 1
                                n -= 1
                        buf = buf[:newline_pos]
                        n += 1
                        c += 1
                        break
                    else:
                        if pos == 0:
                            b = False
                            break
                        to_read = min(4096, pos)
                        fp.seek(-to_read, 1)
                        t_buf = fp.read(to_read)
                        if pythonV == 3: t_buf = t_buf.decode('utf-8', errors="ignore")
                        buf = t_buf + buf
                        fp.seek(-to_read, 1)
                        if pos - to_read == 0:
                            buf = "\n" + buf
                if not b: break
            fp.close()
            if 'drop_ip' in get:
                drop_iplist = self.get_waf_drop_ip(None)
                stime = time.time()
                setss = []
                for i in range(len(data)):
                    if (float(stime) - float(data[i][0])) < float(data[i][4]) and not data[i][1] in setss:
                        setss.append(data[i][1])
                        data[i].append(data[i][1] in drop_iplist)
                    else:
                        data[i].append(False)
        except:
            return public.get_error_info()
            data = []
        return data

    # 列出某站点有日志的日期（日志页的日期下拉）
    def get_logs_list(self, get):
        path = self.__logs
        sfind = get.siteName + '_'
        data = []
        for fname in os.listdir(path):
            if fname.find(sfind) != 0: continue;
            tmp = fname.replace(sfind, '').replace('.log', '')
            data.append(tmp)
        return sorted(data, reverse=True);

    # 读取当前被封禁的 IP 列表（内存 + 落盘）
    def get_waf_drop_ip(self, get):
        try:
            return json.loads(public.httpGet('http://127.0.0.1/get_btwaf_drop_ip'))
        except:
            return [];

    # 解封单个 IP，并同步给 lua 引擎
    def remove_waf_drop_ip(self, get):
        try:
            data = json.loads(public.httpGet('http://127.0.0.1/remove_btwaf_drop_ip?ip=' + get.ip))
            self.__write_log('从防火墙解封IP【' + get.ip + '】');
            return data
        except:
            return public.returnMsg(False, '获取数据失败');

    # 清空全部封禁记录
    def clean_waf_drop_ip(self, get):
        try:
            return json.loads(public.httpGet('http://127.0.0.1/clean_btwaf_drop_ip'))
            self.__write_log('从防火墙解封所有IP');
        except:
            return public.returnMsg(False, '获取数据失败');

    # 读取面板操作日志（谁在什么时候改了什么）
    def get_gl_logs(self, get):
        import page
        page = page.Page();
        count = public.M('logs').where('type=?', (u'' + self.__log_type,)).count();
        limit = 12;
        info = {}
        info['count'] = count
        info['row'] = limit
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = get
        info['return_js'] = ''
        if hasattr(get, 'tojs'):
            info['return_js'] = get.tojs

        data = {}

        # 获取分页数据
        data['page'] = page.GetPage(info, '1,2,3,4,5,8');
        data['data'] = public.M('logs').where('type=?', (u'' + self.__log_type,)).order('id desc').limit(
            str(page.SHIFT) + ',' + str(page.ROW)).field('log,addtime').select();
        return data;

    # 读取累计统计 total.json，并转成前端要的列表结构
    def get_total(self, get):
        try:
            total = json.loads(public.readFile(self.__path + 'total.json'))
        except:
            total = {"rules": {"user_agent": 0, "cookie": 0, "post": 0, "args": 0, "url": 0, "cc": 0}, "sites": {},
                     "total": 0}
            self.__write_total(total);
        if type(total['rules']) != dict:
            new_rules = {}
            for rule in total['rules']:
                new_rules[rule['key']] = rule['value'];
            total['rules'] = new_rules;
            self.__write_total(total);
        total['rules'] = self.__format_total(total['rules'])
        return total;

    # 把统计字典转成有序列表（[0]=POST,[1]=GET,[2]=CC,[3]=UA,[4]=Cookie…）
    def __format_total(self, total):
        total['get'] = 0;
        if 'args' in total:
            total['get'] += total['args'];
            del (total['args'])
        if 'url' in total:
            total['get'] += total['url'];
            del (total['url'])
        cnkey = [
            ['post', u'POST渗透'],
            ['get', u'GET渗透'],
            ['cc', u"CC攻击"],
            ['user_agent', u'恶意User-Agent'],
            ['cookie', u'Cookie渗透'],
            ['scan', u'恶意扫描'],
            ['head', u'恶意HEAD请求'],
            ['url_rule', u'URI自定义拦截'],
            ['url_tell', u'URI保护'],
            ['disable_upload_ext', u'恶意文件上传'],
            ['disable_ext', u'禁止的扩展名'],
            ['disable_php_path', u'禁止PHP脚本']
        ]
        data = []
        for ck in cnkey:
            tmp = {}
            tmp['name'] = ck[1]
            tmp['key'] = ck[0]
            tmp['value'] = 0;
            if ck[0] in total: tmp['value'] = total[ck[0]]
            data.append(tmp)
        return data

    # 测试蜘蛛 IP 校验逻辑（面板诊断按钮用）
    def test_check_zhilist(self, get):
        if not self.__cloud:
            return []
        try:
            userInfo = json.loads(public.ReadFile('/www/server/panel/data/userInfo.json'))
            data22 = {"access_key": userInfo['access_key'], "uid": userInfo['uid']}
            url = 'http://www.bt.cn/api/bt_waf/getSpiders'
            data_list = json.loads(public.httpPost(url, data22, timeout=3))
            if data_list:
                for i22 in data_list:
                    try:
                        path = self.__path + "%s.json" % i22
                        if os.path.exists(path):
                            ret = json.loads(public.ReadFile(path))
                            localhost_json = list(set(ret).union(data_list[i22]))
                            public.WriteFile(path, json.dumps(localhost_json))
                    except:
                        continue
        except:
            return []


    # 首页统计：累计拦截数 + 各类型分布 + 今日/昨日趋势
    def get_total_all(self, get):
        self.__check_cjson();
        nginxconf = self.__nginx_conf;
        if not os.path.exists(nginxconf): return public.returnMsg(False, '只支持nginx服务器');
        #if public.readFile(nginxconf).find('luawaf.conf') == -1: return public.returnMsg(False,'当前nginx不支持防火墙,请重装nginx');
        data = {}
        data['total'] = self.get_total(None)
        del (data['total']['sites'])
        data['drop_ip'] = []
        data['open'] = self.get_config(None)['open']
        conf = self.get_config(None)
        data['safe_day'] = 0
        if 'start_time' in conf:
            if conf['start_time'] != 0: data['safe_day'] = int((time.time() - conf['start_time']) / 86400)
        self.__write_site_domains()
        session_id = self.__get_md5("x_waf_test"+time.strftime('%Y-%m-%d'))
        from BTPanel import session
        if not session_id in session:
            self.test_check_zhilist(None)
        zhizhu_list=['1','2','4','5','6']
        for i in zhizhu_list:
            if not self.__cloud:
                break   # 关闭云上报时不清理本地蜘蛛记录
            try:
                if os.path.getsize(self.__path + 'zhizhu' + i + '.json') > 10:
                    f = open(self.__path + 'zhizhu' + i + '.json', 'r')
                    tt=[]
                    for i2 in f:
                        i2=i2.strip()
                        tt.append(i2)
                    f.close()
                    userInfo = json.loads(public.ReadFile('/www/server/panel/data/userInfo.json'))
                    data22 = {"type": i, "ip_list": json.dumps(tt),"access_key": userInfo['access_key'], "uid": userInfo['uid']}
                    url='http://www.bt.cn/api/bt_waf/addSpider'
                    if len(tt)>=1:
                         public.httpPost(url, data22)
                    public.WriteFile(self.__path + 'zhizhu' + i + '.json', "")
            except:continue
        return data

    # 把「站点 → 域名」映射写入 domains.json（含手动添加站点的域名）
    def __write_site_domains(self):
        sites = public.M('sites').field('name,id').select();
        my_domains = []
        for my_site in sites:
            tmp = {}
            tmp['name'] = my_site['name']
            tmp_domains = public.M('domain').where('pid=?', (my_site['id'],)).field('name').select()
            tmp['domains'] = []
            for domain in tmp_domains:
                tmp['domains'].append(domain['name'])
            binding_domains = public.M('binding').where('pid=?', (my_site['id'],)).field('domain').select()
            for domain in binding_domains:
                tmp['domains'].append(domain['domain'])
            my_domains.append(tmp)
        # 手动添加的站点也要写进域名映射，否则引擎按 host 找不到它
        site_cfg = self.__load_json(self.__path + 'site.json', {})
        if isinstance(site_cfg, dict):
            for sn, item in site_cfg.items():
                if isinstance(item, dict) and item.get('manual'):
                    dl = item.get('domains')
                    if not isinstance(dl, list) or not dl:
                        dl = [sn]
                    my_domains.append({'name': sn, 'domains': dl})
        public.writeFile(self.__path + 'domains.json', json.dumps(my_domains))
        return my_domains

    # 设置自动同步
    def __auto_sync_cnlist(self):
        return True

    # 读规则文件；文件缺失或为空时自动补内置默认规则并落盘
    def __get_rule(self, ruleName):
        # 修正 1：原来文件缺失/为空时返回 False，调用方 .insert()/.append() 直接抛异常 → 面板 500
        # 修正 2：规则文件缺失或为空时，自动补入插件自带的默认规则，做到"默认就有规则"，无需任何按钮
        path = self.__path + 'rule/' + ruleName + '.json'
        rules = self.__load_json(path, None)
        if isinstance(rules, (list, dict)) and len(rules) > 0:
            return rules

        dflt = self.__load_json(self.__PATH + 'defaults/rule/' + ruleName + '.json', None)
        if isinstance(dflt, (list, dict)) and len(dflt) > 0:
            try:
                if not os.path.isdir(os.path.dirname(path)):
                    os.makedirs(os.path.dirname(path))
                public.writeFile(path, json.dumps(dflt))
            except Exception:
                pass
            return dflt
        return rules if isinstance(rules, (list, dict)) else []

    # 写规则文件
    def __write_rule(self, ruleName, rule):
        path = self.__path + 'rule/' + ruleName + '.json'
        if not os.path.isdir(os.path.dirname(path)):
            try:
                os.makedirs(os.path.dirname(path))
            except OSError:
                pass
        public.writeFile(path, self.__fmt_rule_json(rule))
        public.serviceReload();

    # 同步面板站点：新增站点补默认配置，删除已不存在的站点（手动站点保留）
    def __check_site(self, site_config):
        sites = public.M('sites').field('name').select();
        siteNames = []
        n = 0
        for siteInfo in sites:
            siteNames.append(siteInfo['name'])
            if siteInfo['name'] in site_config: continue
            site_config[siteInfo['name']] = self.__get_site_conf()
            n += 1
        old_site_config = site_config.copy()
        for sn in list(site_config.keys()):
            item = site_config[sn] if isinstance(site_config[sn], dict) else {}
            # manual=手动添加的站点（nginx 配置里直接写的那些），不在面板站点表里也要保留
            if sn in siteNames or item.get('manual'):
                if not isinstance(site_config[sn], dict):
                    site_config[sn] = self.__get_site_conf()
                    n += 1
                    continue
                if not 'cdn_baidu' in site_config[sn]:
                    site_config[sn]['cdn_baidu']=False
                    n += 1
                if not 'retry_cycle' in site_config[sn]:
                    site_config[sn]['retry_cycle'] = 60
                    n += 1
                continue
            del (old_site_config[sn])
            self.__remove_log_file(sn)
            n += 1

        if n > 0:
            site_config = old_site_config.copy()
            self.__write_site_config(site_config)

        config = self.get_config(None)
        logList = os.listdir(config['logs_path'])
        mday = time.strftime('%Y-%m-%d', time.localtime());
        allNames = list(siteNames)
        for sn in site_config.keys():
            if sn not in allNames and isinstance(site_config[sn], dict) and site_config[sn].get('manual'):
                allNames.append(sn)
        for sn in allNames:
            site_config[sn]['log_size'] = 0;
            day_log = config['logs_path'] + '/' + sn + '_' + mday + '.log';
            if os.path.exists(day_log):
                site_config[sn]['log_size'] = os.path.getsize(day_log)

            tmp = []
            for logName in logList:
                if logName.find(sn + '_') != 0: continue;
                tmp.append(logName)

            length = len(tmp) - config['log_save'];
            if length > 0:
                tmp = sorted(tmp)
                for i in range(length):
                    filename = config['logs_path'] + '/' + tmp[i];
                    if not os.path.exists(filename): continue
                    os.remove(filename)
        return site_config;

    # 判断某 IP 是否落在给定 IP 段集合内
    def __is_ipn(self, ipn):
        for i in range(4):
            if ipn[0][i] == ipn[1][i]: continue;
            if ipn[0][i] < ipn[1][i]: break;
            return False
        return True

    # 把 IP 段格式化成统一展示文本
    def __format_ip(self, ip):
        tmp = ip.split('.')
        if len(tmp) < 4: return False
        tmp[0] = int(tmp[0])
        tmp[1] = int(tmp[1])
        tmp[2] = int(tmp[2])
        tmp[3] = int(tmp[3])
        return tmp;

    # 生成单个站点的默认配置（新站点初始化用）
    def __get_site_conf(self):
        if not self.__config: self.__config = self.get_config(None)
        conf = {
            'open': True,
            'project': '',
            'log': True,
            'cdn': False,
            'cdn_header': ['x-forwarded-for', 'x-real-ip'],
            'retry': self.__config['retry'],
            'retry_cycle': self.__config['retry_cycle'],
            'retry_time': self.__config['retry_time'],
            'disable_php_path': ['^/upload/', '^/static/'],
            'disable_path': [],
            'disable_ext': [],
            'disable_upload_ext': ['php', 'jsp'],
            'url_white': [],
            'url_rule': [],
            'url_tell': [],
            'disable_rule': {
                'url': [],
                'post': [],
                'args': [],
                'cookie': [],
                'user_agent': []
            },
            'cc': {
                'open': self.__config['cc']['open'],
                'cycle': self.__config['cc']['cycle'],
                'limit': self.__config['cc']['limit'],
                'endtime': self.__config['cc']['endtime']
            },
            'get': self.__config['get']['open'],
            'post': self.__config['post']['open'],
            'cookie': self.__config['cookie']['open'],
            'user-agent': self.__config['user-agent']['open'],
            'scan': self.__config['scan']['open'],
            'drop_abroad': False
        }
        return conf

    # 同步国内 IP 段（下载并写入 cn.json，默认关闭）
    def sync_cnlist(self, get):
        if not get:
            self.get_config(None)
            self.get_site_config(None)
        try:
            rcnlist = public.httpGet(public.get_url() + '/cnlist.json')
        except Exception as e:
            return public.returnMsg(False, '连接云端失败：' + str(e))
        if not rcnlist:
            return public.returnMsg(False, '连接云端失败（服务器无法访问 rules 云端，或云端返回为空）')
        try:
            cloudList = json.loads(rcnlist)
        except Exception:
            return public.returnMsg(False, '云端返回数据解析失败')
        if not isinstance(cloudList, list):
            return public.returnMsg(False, '云端返回数据格式不正确')

        cnlist = self.__get_rule('cn')
        if not isinstance(cnlist, list):
            cnlist = []
        n = 0
        for ipd in cloudList:
            if ipd in cnlist: continue
            cnlist.append(ipd)
            n += 1
        self.__write_rule('cn', cnlist)
        if get: return public.returnMsg(True, '同步成功，本次共增加 ' + str(n) + ' 个IP段')

    # 删除某站点的历史日志文件
    def __remove_log_file(self, siteName):
        # 修正：原版删除的是 /www/wwwlogs/x_waf/（日志并不在这个目录），永远删不掉
        try:
            import glob
            for f in glob.glob(self.__logs + siteName + '_*.log'):
                try:
                    os.remove(f)
                except OSError:
                    pass
        except Exception:
            pass
        total = self.__load_json(self.__path + 'total.json', {'sites': {}}) or {'sites': {}}
        if 'sites' not in total:
            total['sites'] = {}
        if siteName in total['sites']:
            del (total['sites'][siteName])
            self.__write_total(total)
        return True

    # 写 total.json，并把运行期可写文件恢复成 666（否则引擎写不进去）
    def __write_total(self, total):
        path = self.__path + 'total.json'
        ret = public.writeFile(path, json.dumps(total))
        # 面板写完后可能变成 root:root 644，nginx(www) 就写不进去了 → 站点统计归零，
        # 这里统一把运行期可写文件恢复成 666
        for f in (path, self.__path + 'drop_ip.log'):
            try:
                if os.path.exists(f):
                    os.chmod(f, 0o666)
            except Exception:
                pass
        return ret

    # 写全局配置并触发 nginx reload（引擎在 init 阶段重新加载）
    def __write_config(self, config):
        public.writeFile(self.__path + 'config.json', json.dumps(config))
        public.serviceReload();

    # 写站点配置并触发 nginx reload
    def __write_site_config(self, site_config):
        public.writeFile(self.__path + 'site.json', json.dumps(site_config))
        public.serviceReload();

    # 写面板操作日志
    def __write_log(self, msg):
        public.WriteLog(self.__log_type, msg)

    # 检查 cjson 是否可用（缺了规则匹配和日志都会失效）
    def __check_cjson(self):
        cjson = '/usr/local/lib/lua/5.1/cjson.so'
        if os.path.exists(cjson):
            if os.path.exists('/usr/lib64/lua/5.1'):
                if not os.path.exists('/usr/lib64/lua/5.1/cjson.so'):
                    public.ExecShell("ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so");
            if os.path.exists('/usr/lib/lua/5.1'):
                if not os.path.exists('/usr/lib/lua/5.1/cjson.so'):
                    public.ExecShell("ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so");
            return True

        c = '''wget -O lua-cjson-2.1.0.tar.gz http://download.bt.cn/install/src/lua-cjson-2.1.0.tar.gz -T 20
tar xvf lua-cjson-2.1.0.tar.gz
rm -f lua-cjson-2.1.0.tar.gz
cd lua-cjson-2.1.0
make
make install
cd ..
rm -rf lua-cjson-2.1.0
ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so
ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so
/etc/init.d/nginx reload
'''
        public.writeFile('/root/install_cjson.sh', c)
        public.ExecShell('cd /root && bash install_cjson.sh')
        return True
