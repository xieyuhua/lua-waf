# x_waf —— 宝塔面板 Nginx 免费防火墙（分支版）

在「Nginx免费防火墙」(第三方插件，作者 明国三年一场雨) 基础上做了改名与工程化整理：
运行时目录从 `/www/server/free_waf` 迁到 **`/www/server/x_waf`**，插件标识统一为 `x_waf`。

> ⚠️ **本包缺一份数据文件**：原包安装时会解压 `free_waf_data.zip` 里的 lua 引擎
> （`waf.lua` / `init.lua` / `rule/*.json` 等），这份 zip 在原始目录里已经被删掉了
> （install.sh 装完会 `rm -f` 它）。请把原插件的 `free_waf_data.zip` 解压到
> `x_waf/data/`（清单见 `data/README.txt`），否则安装脚本会明确报错退出，不会半装。

---

## 一、目录 / 命名对照

| 项目 | 原版 | 现在 |
|---|---|---|
| 运行时目录 | `/www/server/free_waf` | **`/www/server/x_waf`** |
| 面板插件目录 | `/www/server/panel/plugin/free_waf` | `/www/server/panel/plugin/x_waf` |
| 后端文件 / 类 | `free_waf_main.py` / `free_waf_main` | `x_waf_main.py` / `x_waf_main` |
| nginx 包含文件 | `vhost/nginx/free_waf.conf` | `vhost/nginx/x_waf.conf` |
| 插件图标 | `ico-free_waf.png` | `ico-x_waf.png` |
| 日志目录 | `/www/wwwlogs/free_waf_log` | `/www/wwwlogs/x_waf_log` |
| 前端 JS 对象 / plugin_name | `free_waf` | `x_waf` |
| lua 共享内存名 | `free_waf` / `free_waf_drop_ip` / `free_waf_drop_sum` | **保持不变**（见下） |

**为什么 lua_shared_dict 名字没跟着改？** 这三个名字写在 lua 引擎里
（`ngx.shared.free_waf` 等），而引擎不在本仓库内。改了名而引擎没改，WAF 会直接
`ngx.shared.xxx is nil` 报错，nginx 起不来。等你拿到 `waf.lua` 之后再一起改，或者
一直保留这两个名字（对功能无影响）。

---

## 二、这次改了什么（除了改名）

### install.sh（基本重写）

1. **所有路径集中到文件顶部 6 个变量**，以后再换目录只改一处；原来 22 处硬编码
   `/www/server/free_waf` 散在各函数里。
2. **安装前预检**：Nginx 是否存在、vhost 目录是否存在、是否装了付费版
   `btwaf.conf`、是否残留原版 `free_waf.conf` / `/www/server/free_waf`
   （共享内存重名会直接让 nginx 起不来）。原版是直接 `rm -rf btwaf.conf` 硬删别人的配置。
3. **数据包缺失时立即退出并给出中文原因**，不再"装一半把 nginx 弄挂"。
4. **lua 编译改用 `make generic`**（不依赖 readline，失败再退回 `make linux`）；
   原版用 `make linux`，没装 `libreadline-dev` 的机器会直接失败。
5. **cjson 增加 ABI 检查**：先拷预编译 `.so`，然后 `luajit -e "require 'cjson'"`
   验证，出现 `undefined symbol` 就自动回退源码编译（ARM 机器常见）；原版只做了一半。
6. **不再 `sed -i "/lua_package_path/d"` 粗暴删除 nginx.conf 里的指令**，改成加
   `#x_waf-disabled:` 标记注释 + 备份 `nginx.conf.x_waf.bak`，卸载时精确还原。
7. **健康检查换成 `nginx -t` + curl/ss/pgrep**；原版是
   `netstat -nltp|grep nginx|grep 80`——nginx 不监听 80、机器没装 netstat、
   或者端口是 8080 都会误判成安装失败，然后被删掉半套文件。
8. **失败自动回滚**：撤掉包含文件、还原 nginx.conf、重启，保证站点不中断。
9. **重装不再覆盖用户规则**：原来每次安装都用数据包里的 `args.json` / `post.json`
   覆盖线上规则，调过的规则白调；现在规则库只在缺失时补齐。
10. **权限修正**：目录统一 755（原来 `chmod -R 666 rule` 会连目录一起给 666，
    结果是 www 无法进入该目录），运行期由 www 写入的文件单独给 666。
11. 去掉无用的 `Install_cjson2()`（从没被调用）、去掉反复解压源码包不清理的问题
    （lua / cjson 源码编译完立刻删，不再留在插件目录里）。
12. 卸载时清理图标、日志目录可选 `purge`；保留日志不静默删除。

### x_waf_main.py

1. 路径常量集中在类顶部：`__path` / `__logs` / `__PATH` / `__nginx_conf` /
   `__log_type`，替换了全文散落的硬编码。
2. **修 bug**：`__remove_log_file()` 原来删的是 `/www/wwwlogs/x_waf/`（日志根本不
   在那），删站点的日志永远删不掉；现在按日志目录精确 `glob + unlink`，也不再走
   `ExecShell rm -rf`。
3. **修 bug**：`import_data()` 里 IP 正则没转义点号，`1a2b3c4d` 这种脏数据也能过；
   换成严格的段值校验（0-255、掩码 0-32），并返回"新增 N 条 / 忽略 M 条"。
4. **修 bug**：`getdir(dir, pc='', lis=[])` 可变默认参数，同一进程多次扫描会把上次
   结果累积进来。
5. **容错**：`config.json` / `site.json` / `total.json` 缺失或损坏时不再抛 500，
   用 `__load_json()` + 默认配置兜底（原来 `json.loads(readFile(...))` 一处不存在就
   整页报错）。
6. **兼容**：`cgi.escape` 在 Py3.8 已移除，统一走 `html.escape` 兜底。
7. **隐私/安全**：默认关闭向第三方回传——`send_baota`（把站点文件内容 POST 到
   `bt.cn/api/panel/btwaf_submit`）、`upload_file_url`（上传到百度杀毒）、
   `test_check_zhilist` / `get_total_all` 里的蜘蛛池上报（带你的 `access_key`、`uid`）。
   需要时把类属性 `__cloud` 改成 `True` 即可恢复。
8. 面板操作日志的分类名收敛到 `__log_type` 常量（原为写死的「Nginx免费防火墙」）。

### 其他

- `info.json` 重写：原文件今天被存成了乱码（`Nginx鍏嶈垂闃茬伀澧?`，GBK/UTF-8
  串码），现在 UTF-8 正常，`name` 与目录/类名一致为 `x_waf`，`shell` 指向 `install.sh`。
- `free_waf.conf` → `x_waf.conf`，加上共享内存名不可改的注释说明。
- `fail2ban_main.py`（宝塔官方 fail2ban 插件的后台，本插件前端从未调用，含
  `eval()`）移到 `extras/`，默认不随包安装。
- 删掉 `lua-5.1.5/`、`lua-cjson-2.1.0/` 两个解压后的源码目录（含 Linux `.o` 产物），
  只保留 `.tar.gz` 和预编译 `cjson.so`，包体从 ~1.9MB 降到 ~350KB。

---

## 三、本地安装

前提：宝塔面板自带商店能正常打开；机器上有 Nginx。

**方式 A：面板导入（推荐）**

1. 把 `free_waf_data.zip` 解压进 `x_waf/data/`（见上面的 ⚠️）。
2. 把 `x_waf` 目录打包成 `x_waf.zip`（zip 里第一层是 `x_waf/`）。
3. 面板 → 软件商店 → 第三方应用 →「导入插件」→ 上传 `x_waf.zip`。
4. 装完后在软件商店里会出现「Nginx免费防火墙 x_waf」。

## 三·五、页面样式修复（v1.1）

「全局配置」等页面样式错乱的两类成因都从根上解决：

1. **图标字体外链没了**：原来 `index.html` 用
   `<link href="free_waf/static/font_xxx.css">` 引 iconfont，插件目录改名后该路径 404，
   全站图标变空白/方块，看起来就是"样式乱了"。现在把 iconfont CSS 和
   fixedheadertable JS **全部内联进 index.html**，不再依赖任何相对路径或 CDN。
2. **后端字段缺失导致整页渲染中断**：`index.html` 的 `http()` 封装遇到
   `{status:false}` 不会回调 `success`，而"全局配置"表格完全靠 JS 渲染，
   一旦 `get_config` 失败或返回里没有 `cc` / `from_data` 等 key，页面就只剩骨架。
   现在后端 `get_config()` 会做深度补齐（cc/get/post/cookie/user-agent/scan/
   drop_abroad/ip_white/ip_black/url_white/from_data 全部兜底），前端也加了空值守卫
   和明确的错误提示，不会再出现"白板"。

改了 `index.html` / `x_waf_main.py` 之后，覆盖到服务器上需要刷新插件：

```bash
# 只更新两个文件（保留已装好的运行时目录和你的规则）
scp index.html x_waf_main.py root@host:/www/server/panel/plugin/x_waf/
ssh root@host 'bt restart'     # 或 面板设置 → 重启面板
# 浏览器 Ctrl+Shift+R 强刷
```

## 三·六、vhost 目录自适应（v1.2）

**症状**：安装时报 “`/www/server/panel/vhost/nginx` 目录不存在，没有复制成功”，`x_waf.conf` 没落地。

**原因**：原脚本假定这个目录一定存在。实际上**新装面板/还没建过站点时，这个目录是不存在的**
（nginx.conf 里的 `include .../vhost/nginx/*.conf;` 空通配符 nginx 不报错，所以一直没人发现）。

**现在的逻辑**（`resolve_vhost_dir()`）：

1. 从 `nginx.conf` 里读 `include ...vhost...*.conf`，取它指向的目录 —— 这是最权威的
   来源，不猜默认路径；并且**显式排除 `vhost/rewrite/*.conf`**（站点级重写规则，
   塞进去会让 WAF 配置只在单个 server 块生效甚至报错）。
2. 目录不存在就 `mkdir -p` 创建（有 `include` 通配符在，建好即生效）。
3. 如果 `nginx.conf` 里根本没有 vhost 包含指令，就把
   `include <目录>/x_waf.conf;` 插到 `http{}` 里，备份 `nginx.conf.x_waf.bak`，
   写完立刻 `nginx -t`，不通过就回滚；卸载时按标记精确删除这一行。
4. 安装成功会打印实际落地的三个路径，不再需要靠猜。

排查用：

```bash
bash /www/server/panel/plugin/x_waf/install.sh check
```

会打印 nginx 路径、版本、nginx.conf 是否存在、插件/运行时/日志目录状态、
以及 nginx.conf 里所有 include 行——一眼就能看出配置该放哪。

## 三·七、内置默认规则库（v1.3）

**症状**：全局配置里点「规则」，表格是**空的**——没有 GET-URL / GET-参数 / POST / User-Agent
的内置规则，常见扫描器、IP 黑白名单、URL 白名单也是空的。

**原因**：这些规则原本来自数据包里的 `rule/*.json`。原版 install.sh 只在
「整个 `rule` 目录不存在」时才复制，目录在、文件是 `[]` 的情况下**永远补不上**。

**现在**：插件自带一套默认规则库 `defaults/rule/`（66 条），双保险：

| 时机 | 行为 |
|---|---|
| 安装 / 重装 | `rule/*.json` 缺失**或内容为 `[]` / `{}`** 时，从 `defaults/rule/` 补入；已有内容的文件不动 |
| 手动 | 全局配置页顶部「导入内置默认规则」按钮 = 全量合并；每个「编辑规则」弹窗里也有「导入默认规则」= 只补当前这类 |

合并规则是「按规则内容去重、只加不改」，你调过的规则、自己加的规则都不会被覆盖。

默认规则内容（`data/rule/` 里同名文件优先级更高）：

| 文件 | 条数 | 覆盖 |
|---|---|---|
| `url.json` | 16 | 目录穿越、敏感文件探测、SQLi/XSS/命令执行特征、危险协议、后门文件名、框架管理端口 |
| `args.json` | 20 | SQLi（含盲注/报错注入/恒真）、XSS、RCE、文件包含、Log4j、二次编码绕过 |
| `post.json` | 13 | 一句话木马、命令执行函数、写文件后门、非法上传、动态包含 |
| `user_agent.json` | 12 | sqlmap/nikto/nuclei/fscan 等扫描器、目录爆破、脚本请求、空 UA |
| `cookie.json` | 5 | SQLi / XSS / 后门函数 / 穿越 / Log4j |
| `scan_black.json` | 3 段 | 常见扫描器的 header / cookie / args 正则（多行文本） |
| `ip_white.json` | 1 | 默认放行 `127.0.0.1` |
| 其余 | 0 | `ip_black` / `url_white` / `url_black` / `head_white` / `cn` 留空，按需自己加或点「同步」拉国内 IP 段 |

> 规则是**通用基线**，不是万能。上线前建议按自己业务在白名单里放行后台/接口路径，
> 并先开着「仅记录」观察几天——免费版没有 CC 防护，规则误杀只能靠白名单兜。

## 三·八、安装日志 / 引擎多来源 / lua 模块预检（v1.4）

**症状**：装完 `x_waf.conf` 不在 `/www/server/panel/vhost/nginx/`，且 `/www/server/x_waf` 里没有 `.lua` 文件。

**根因是一条链**：lua 引擎没就位 → `init_by_lua_file /www/server/x_waf/init.lua` 找不到文件 
→ `nginx -t` 失败 → 脚本回滚时把刚写好的 `x_waf.conf` 删掉。所以"配置没复制成功"其实是回滚。

**改了三处：**

1. **引擎多来源自动查找**，只要机器上还有一份能跑的引擎就不用再找原始 zip：

   | 顺序 | 来源 |
   |---|---|
   | 1 | 插件目录 `data/waf.lua` |
   | 2 | 插件目录 `data/free_waf/waf.lua`（原版插件目录结构） |
   | 3 | 插件目录 `x_waf_data.zip`（自动解压并识别多一层目录） |
   | 4 | **旧版运行时目录 `/www/server/free_waf/`（原版插件装在这里）** |
   | 5 | 当前 `/www/server/x_waf/`（升级安装，原地保留） |

   从旧目录复制后，会把引擎里写死的 `/www/server/free_waf`、`/www/wwwlogs/free_waf_log` 
   自动改写为新路径。

2. **全程安装日志**：`/www/server/x_waf/install.log`，同时实时打到标准输出，面板的
   "安装日志"窗口直接能看到带时间戳的分步进度（`1/8 环境检查` → `8/8 校验`），
   包括 `nginx -t` 的原始输出。安装成功会打印：

   ```
   [17:33:22] 安装完成
   [17:33:22]   包含文件：/www/server/panel/vhost/nginx/x_waf.conf ✓
   [17:33:22]   运行时目录：/www/server/x_waf（lua：5 个）
   [17:33:22]   规则库  ：12 个文件
   ```

   复制 `x_waf.conf` 后还会**回读校验**文件是否存在，不存在直接报错，不再"静默成功"。

3. **lua 模块预检**：`nginx -V` 里没有 `lua-nginx-module` / `http_lua` / `openresty` 时
   直接拒绝安装并说明原因（否则必然回滚）。确实要装可 `FORCE=1 bash install.sh install`。

排查命令（v1.4 起 `check` 会打印日志路径）：

```bash
bash /www/server/panel/plugin/x_waf/install.sh check
tail -50 /www/server/x_waf/install.log
```

## 三·九、自带 lua 引擎（v1.5，原版引擎缺失时的兜底）

你的环境里找不到 `free_waf_data.zip`，`/www/server/x_waf` 里也就没有 `.lua`，
安装卡在「准备 lua 引擎」这一步。**现在插件自带一套可用的 lua 引擎**，不再依赖那个数据包。

| 文件 | 作用 |
|---|---|
| `init.lua` | `init_by_lua_file`：加载 config.json / site.json / domains.json / 全部规则，预编译 IP 段区间（二分查找） |
| `waf.lua` | `access_by_lua_file`：实际拦截逻辑 + 面板内部接口 |
| `init_worker.lua` | `init_worker_by_lua_file`：每 15 秒把内存计数器落盘到 `total.json` |

**拦截顺序**：封禁期内IP → IP白名单 → IP黑名单 → 站点开关 → 禁止海外访问(cn.json)
→ CC 计数/封禁 → URL白名单 → URL黑名单 → User-Agent → 常见扫描器(header/cookie/args)
→ Cookie → URL/GET 参数 → POST body（含 From-data 协议检查）。

**面板接口**（`waf.lua` 里实现，仅 127.0.0.1 可调用，供面板「封锁历史」用）：
`/get_btwaf_drop_ip`、`/remove_btwaf_drop_ip?ip=`、`/clean_btwaf_drop_ip`。

**数据格式**与面板完全对齐（这套格式是照面板解析代码反推的）：

- 站点日志 `$logs_path/<站点>_<YYYY-MM-DD>.log`，每行一个 JSON 数组
  `[时间, IP, 类型, URL, UA, 过滤器, "规则 >> 传入值", 风险值]`
- 封禁记录 `drop_ip.log`：`[开始时间戳, IP, 站点, 0, 封锁秒数, 原因(cc/retry), ""]`
- `total.json`：`{"rules":{8类计数},"sites":{站点:{...}},"total":N}`

**安全设计**：

- 整个 `main()` 包在 `pcall` 里，引擎自身出错只写 `nginx error.log`，**绝不影响站点访问**
- `ngx.exit` 特意放在 `pcall` 之外执行 —— 它靠抛异常终止请求，放在 pcall 内会被吞掉导致"该拦的没拦"
- 单条正则写错只跳过该条（记 error log），不影响其它规则

**已验证**（在 WSL 里用 lua5.1 + lua-cjson + grep -P 模拟 PCRE 跑通）：

- `luac -p` 三个文件语法全过
- `init.lua` 真实加载：66 条规则、domains 映射、IP 段二分查找、ip2n 边界（`256.1.1.1` 返回 nil）
- `waf.lua` 12 个用例全过：正常首页/正常 UA/正常表单**放行**；
  SQL注入、XSS、目录穿越、`.env` 探测、sqlmap UA、空 UA、一句话木马、命令拼接**拦截**；
  内部接口正常返回 JSON
- 安装流程：无 data、无旧目录 → 用自带引擎装完，`x_waf.conf` 落地并回读校验

**限制（务必知道）**：这是**重新实现**的引擎，不是作者原版。

- CC 是 shared-dict 简单计数（`cycle` 秒内超 `limit` 次封 `endtime` 秒），没有原版的滑动窗口/语义分析
- 无「蜘蛛池」自动学习、无云查杀联动（面板里那两个按钮本来就依赖 bt.cn 云接口，分支里默认已关闭回传）
- 没有 `from_data` 的完整 multipart 解析，只做 boundary 存在性检查
- 规则是通用基线：**上线先观察「封锁历史」，把误杀路径加进 URL 白名单**

如果以后拿到原版 `free_waf_data.zip`，解压到 `data/` 后重装，会**优先使用原版引擎**（自带引擎自动让位）。

## 三·十、安装校验判据修正（v1.6）

**症状**：日志里 `nginx -t` 明明 `test is successful`，第 8 步还是判定失败并回滚。

**原因**：健康检查写得太严 —— `curl 127.0.0.1` + `ss -lntp | grep nginx` + `pgrep -f 'nginx: master'`
三个都得命中才算成功。以下情况都会误判：80 端口没站点、机器没装 `ss`/`pgrep`、
nginx 绑定的不是 127.0.0.1、重启慢了一拍。

**现在**：

| 判据 | 作用 |
|---|---|
| `重启命令退出码` | **硬判据**：`/etc/init.d/nginx restart` 返回 0 才算重启成功 |
| `nginx -t`（双通道） | **硬判据**：编译默认配置 + `-c /www/server/nginx/conf/nginx.conf`，都不能有 `emerg` |
| pid 文件 / `ps` / `ss` / `curl` | **软检测**：只打印"运行中 ✓"或提示手动确认，**不再据此回滚** |

失败回滚时会把 `nginx -t` 输出、重启输出、`ps -ef | grep nginx` 现场全部打进日志。

同时 vhost 目录探测修掉了另一个坑：宝塔的
`include /www/server/panel/vhost/nginx/tcp/*.conf;` 属于 `stream{}` 上下文，
把 `access_by_lua_file` 写进去必然 `directive is not allowed here` ——
现在候选目录会排除 `rewrite` / `/tcp/` / `/udp/` / `stream`，并且**每写一个目录就跑一次
`nginx -t`**，不通过就删掉换下一个，最后才回退到默认目录并往 `http{}` 补 include。

## 三·十一、检测增强：规则库 v2 + 引擎 v2（v1.7）

### 1. 规则库扩到 111 条（+ 扫描器 14 行），覆盖 2021–2025 常见攻击面

| 文件 | 条数 | 新增重点 |
|---|---|---|
| `url.json` | 40 | Log4j(`${jndi:`)、CVE-2021-41773(`/cgi-bin/.%2e`)、Spring4Shell、Actuator 未授权、Nacos 认证绕过、WebLogic(`wls-wsat`)、Confluence OGNL、Laravel Ignition、PHPUnit `eval-stdin`、.env/.git/.svn、备份包、Hadoop/ES 未授权、IoT 路由器探测 |
| `args.json` | 28 | SQLi（含盲注/报错/**堆叠**）、NoSQL(`$ne`/`$where`)、XSS、**SSTI**(`{{7*7}}`)、SpEL/OGNL、Log4j、命令拼接、文件包含、**反序列化 magic**(`rO0AB`)、**Fastjson autoType**、**ThinkPHP 5.x**、XXE、**内网 SSRF**、**CRLF 注入**、二次编码绕过 |
| `post.json` | 22 | 一句话/回调后门、命令执行、**上传可执行文件**(`filename="x.php"`)、`.htaccess` 写入、图片马(GIF89a+PHP)、SQLi/XSS、**Spring4Shell**(`class.module.classLoader`)、Fastjson、XXE、SSTI、混淆后门 |
| `user_agent.json` | 13 | sqlmap/nuclei/xray/fscan/goby/wpscan/ffuf/nikto/masscan、商业扫描器、脚本请求库、空 UA、注入字符、SEO 采集 |
| `cookie.json` | 8 | **Shiro `rememberMe=`**、Java 反序列化 magic、WebLogic `$Version=`、注入/XSS/后门 |
| `scan_black.json` | 14 行 | header/cookie/args 三段扫描器特征 |

所有正则都用 **真实 PCRE（grep -P）逐条编译校验：129 条，0 失败**。

### 2. 引擎增强

| 能力 | 说明 |
|---|---|
| **容忍阈值自动封禁** | 面板「非法请求容忍阈值」的三个参数（`retry` / `retry_cycle` / `retry_time`）以前没用上，现在生效：`cycle` 秒内累计命中 `retry` 次 → 自动封 `retry_time` 秒并记入「封锁历史」 |
| **原始 + 解码双份匹配** | 同时检查 `ngx.var.uri`（解码后）、`request_uri`（原始）、`ngx.var.args`（原始查询串），`%2e%2e`、`%252e` 这类编码绕过也能命中 |
| **站点级策略生效** | `disable_ext`（禁止扩展名）、`disable_php_path`（禁止 PHP 执行路径）、`url_rule`（自定义 URI 拦截）从站点配置读取并执行 |
| **参数级扫描补全** | POST body 除了过 post 规则，还会过一遍扫描器 args 特征 |

### 3. 实测：32 个用例全过

放行（7 个）：正常首页、中文博客页、正常搜索词（含 `select` 单词）、静态资源、登录表单、JSON 提交、正常 Chrome UA

拦截（25 个）：SQL 注入/盲注、XSS、NoSQL、命令执行、SSTI、内网 SSRF、Log4j2、Spring4Shell、Fastjson、Shiro、ThinkPHP RCE、CVE-2021-41773、Nacos、Actuator、PHPUnit、`.git`、XXE、上传 php 木马、sqlmap/nuclei UA、空 UA、POST 一句话、目录穿越

容忍阈值：同一 IP 连续命中 3 次 → 写入 1 条 600 秒封禁记录 → 之后普通请求直接被封禁期内规则拦掉 ✓

## 三·十二、按 URL 限频（v1.8）：IP 维度 + Key 维度

面板左侧新增 **「URL限频」** 页：每条规则针对一个 URL，可同时启用两种计数维度。

| 维度 | 计数对象 | 典型用途 |
|---|---|---|
| **IP 维度** | 客户端 IP | 登录/短信/发码接口防爆破（同一 IP 60 秒最多 5 次） |
| **Key 维度** | 请求里的某个 Key 的值 | 按 token / AppKey / 手机号限流，不同用户互不影响 |

### 配置项

```json
[
  {
    "open": true,
    "url": "^/api/login",              // 对「请求URI+查询串」的正则
    "status": 429,                     // 超限响应码（429/503/403/444）
    "ip":  {"open": true,  "cycle": 60, "limit": 5},                       // 每 IP
    "key": {"open": true,  "source": "header", "name": "X-Api-Key",
            "cycle": 60, "limit": 300}                                     // 每 Key
  }
]
```

- `source` 三选一：`header`（请求头）、`arg`（URL 参数 / 表单字段）、`cookie`
- `limit` 为 0 或 `open:false` 表示该维度不启用
- 两个维度**同时启用时任一侧超限即拦截**，超限响应默认 429 并带 `Retry-After`

### 引擎行为

- 计数存在 `lua_shared_dict free_waf_drop_sum`（10MB），**key 自带 TTL**（=cycle 秒），不会无限增长
- 限频检查位于 CC 防御之后、规则匹配之前（先限流再查规则，省 CPU）
- 超限会写站点日志：类型 **「访问频率超限」**，过滤器 `limit_ip` / `limit_key`，详情带 `"60秒内超过5次 >> 1.2.3.4"`
- 同时计入「非法请求容忍阈值」：反复超限的 IP 会被自动封禁并进「封锁历史」

### 实测

| 场景 | 结果 |
|---|---|
| `^/api/login` 限 3 次/60 秒，同一 IP 连续 5 次 | `放 放 放 429 429` |
| 换一个 IP 再请求 | 放行 |
| `^/api/data` 限 2 次/60 秒，同一 `X-Api-Key` 连续 4 次 | `放 放 429 429` |
| 换一个 Key 再请求 | 放行 |
| 没配限频的 `/index.html` 连续 5 次 | 全部放行 |

### 怎么加规则

插件页 → 左侧 **URL限频** → 左上角「添加规则」：

- URL 正则：`^/api/login`、`^/api/sms/send`、`^/api/.*`（必填，保存前会校验正则合法性）
- IP 维度：勾启用 + 周期秒 + 次数
- Key 维度：勾启用 + 来源（Header/参数/Cookie）+ 名称 + 周期秒 + 次数
- 超限响应：默认 429

保存后自动 `nginx reload`（引擎在 `init_by_lua` 阶段重新加载 `limit.json`），**立即生效，无需重启**。

### 编辑界面（v1.9 重做）

原来所有字段挤在一行里、没有校验、没有场景模板，重做成三块：

```
┌ 基础设置 ────────────────────────────────────────┐
│ URL 正则  [ ^/api/login                        ] │
│           ✓ 正则格式正确                          │
│           [ 粘贴真实 URL 试命中      ] [测试] ✓会命中│
│ 备注      [ 登录防爆破                          ] │
│ 超限响应  [ 429 ▾ ]  429=请求过多（推荐）         │
│ 快捷模板  [登录防爆破] [短信/验证码] [开放API按Key] [高频页面限速] │
├ IP 维度（按客户端 IP 计数） ────────────────────┤
│ 频率      每 [60] 秒 最多 [5] 次                  │
├ Key 维度（按 Key 的值独立计数） ────────────────┤
│ 取值来源  [ 请求头 Header ▾ ]                     │
│ Key 名称  [ X-Api-Key              ]             │
│ 频率      每 [60] 秒 最多 [300] 次                │
└─────────────────────────────────────────────────┘
```

具体改进：

| 项 | 说明 |
|---|---|
| **分区卡片** | 基础 / IP 维度 / Key 维度三块独立，标签右对齐、输入框自适应宽度 |
| **维度联动** | 不勾选的维度整块变淡并禁用点击，避免填了却不生效 |
| **正则实时校验** | 输入即校验，合法显示绿色「正则格式正确」，非法显示红色具体错误 |
| **URL 命中测试** | 粘贴一个真实 URL，点「测试」立刻告诉你规不规范、会不会命中 |
| **快捷模板** | 一键套用「登录防爆破 / 短信验证码 / 开放API按Key / 高频页面限速」，套完可继续微调 |
| **备注字段** | 新增 `memo`，列表里显示在 URL 下方，方便区分规则用途 |
| **保存前校验** | 正则合法、至少启用一个维度、启用维度的次数 > 0、Key 名称非空 |
| **列表优化** | 状态用彩色标签（已启用/已停用）、维度用标签展示、无规则时给引导文案、表格可横向滚动 |

`node --check` 校验插件 JS 语法通过；引擎侧 `limit.lua` 一并纳入 `luac -p` 检查。

## 三·十三、resty.core 启动失败修复（v2.0）

**症状**：安装到第 7 步重启 nginx 时报

```
nginx: [alert] failed to load the 'resty.core' module
  (reason: module 'resty.core' not found: no file '/www/server/x_waf/resty/core.lua' ...)
```

**原因**（两个叠加的坑，都是我埋的）：

1. `x_waf.conf` 里写了 `lua_package_path "/www/server/x_waf/?.lua";` ——
   这条指令**会覆盖** openresty 默认的 lua 搜索路径，而 openresty 的
   `lua-resty-core`（`resty.core`）就在默认路径里。覆盖后 nginx 一启动就找不到它，
   **整个 nginx 起不来**。
2. 安装脚本的 `sync_lualib()` 里有一行 `rm -rf "${waf_path}/resty"`，
   把刚拷进去的 lualib 又删了。

**修法**：

| 改动 | 说明 |
|---|---|
| `x_waf.conf` 删除 `lua_package_path` | `init_by_lua_file` / `access_by_lua_file` 都用绝对路径，本来就不需要它 |
| `init.lua` 改用 `dofile(XWAF.path.."/limit.lua")` | 不再 `require("limit")`，彻底不依赖 package.path |
| `sync_lualib()` 不再拷 lualib、**不再删 resty/ngx** | 完全交给 openresty 自己的 lualib |
| 安装时调用 `restore_nginx_lua_path()` | 老版本会注释掉 nginx.conf 里的 `lua_package_path`，新版本安装时自动把这行还原 |

**实测**（复现你的环境：nginx.conf 里有 `lua_package_path "...lualib/?.lua;;"` +
被上次安装注释成 `#x_waf-disabled:` 标记，stub 模拟“vhost 里一旦出现 lua_package_path 就报 resty.core”）：

```
[6/8] 已还原 nginx.conf 中的 lua_package_path
[6/8] 包含文件写入并通过 nginx -t：.../vhost/nginx/x_waf.conf
[7/8] 重启命令退出码：0
[8/8] 校验结果：重启退出码=0，nginx -t=通过
安装完成
```

装完 `nginx.conf` 里那行回到正常状态、`x_waf.conf` 里没有任何 `lua_package_path`。

> 顺带说明：`nginx -t` **测不出**这类错误（配置语法没问题，是启动阶段加载 lua 模块失败）。
> 所以安装脚本的最终判据用的是「重启命令退出码 + nginx -t」，这次正是靠退出码抓到的。

## 三·十四、Permission denied 修复（v2.1）

**症状**：nginx 启动正常，但**每个请求都报错**：

```
[error] failed to load external Lua file "/www/server/x_waf/waf.lua":
        cannot open /www/server/x_waf/waf.lua: Permission denied
```

**为什么启动不报、请求才报**：
`init_by_lua_file` 由 master（root）加载 → 读得到；
`access_by_lua_file` 由 **worker（www 用户）** 在每次请求时加载 → 读不到。

**原因**：`cp` 在收紧的 umask（如 077）下复制出的文件是 `600 root:root`，
而原来的 `fix_perms()` 只 chmod 了目录，没管文件。

**修法**：

| 改动 | 说明 |
|---|---|
| `fix_perms()` 显式设置文件权限 | 目录统一 `755`，`*.lua / *.json / *.so / *.html` 统一 `644` |
| 新增 `ensure_www_readable()` | 用 `su www -c 'head -c 1 文件'` **实测** www 能不能读，读不到自动 chmod/chcon 重试，仍失败则中止安装（避免装完站点全 500） |
| SELinux Enforcing 自动处理 | `getenforce = Enforcing` 时给 `$waf_path` 打 `httpd_sys_content_t` 上下文 |
| 第 8 步新增 lua 加载检查 | 重启前记录 `error.log` 行数 → 重启后打一个测试请求 → 只检查**新增行**里有没有 `failed to load external Lua file` |

**实测**（命令前显式 `umask 077` 模拟你的环境）：

```
[8/8] 权限自检：www 可读 ✓
安装完成
-rw-r--r-- /www/server/x_waf/waf.lua        ← 644（原来是 600）
-rw-r--r-- /www/server/x_waf/init.lua
drwxr-xr-x /www/server/x_waf/
drwxr-xr-x /www/server/x_waf/rule/
残留 600 文件：无
```

### 现场急救（已经装坏了、站点正在 500 时）

```bash
chmod 755 /www/server/x_waf
find /www/server/x_waf -type d -exec chmod 755 {} +
find /www/server/x_waf -type f -exec chmod 644 {} +
chown www:www /www/server/x_waf/drop_ip.log /www/server/x_waf/total.json /www/server/x_waf/zhizhu*.json 2>/dev/null
chmod 666 /www/server/x_waf/drop_ip.log /www/server/x_waf/total.json /www/server/x_waf/zhizhu*.json 2>/dev/null
# SELinux 为 Enforcing 时再执行：
# chcon -R -t httpd_sys_content_t /www/server/x_waf
/www/server/nginx/sbin/nginx -s reload
ls -l /www/server/x_waf/waf.lua        # 确认是 -rw-r--r--，不是 -rw-------
```

## 三·十五、「响应代码」设置消失修复（v2.2）

**症状**：全局配置表格里「响应」这一列空白，点不到、也就设不了响应码。

**原因**：前端表格渲染 `type:'link'` 的列时有一句 `if(_text !== '')`，
而我的默认配置里每个功能的 `status` 是空字符串 `""` → 整格不渲染 → 看起来"功能没了"。

**修法（双保险）**：

| 层 | 改动 |
|---|---|
| 前端 | `link` 列新增 `empty_text` 支持：「响应」列空值时显示 **默认** 且依然可点；不再整格消失 |
| 后端 | `__default_config()` 给出真实默认响应码（过滤类 `403`、CC `503`）；`get_config()` 发现 `status` 为空时**自动补默认值并写回 config.json**（老配置自愈） |
| 数据 | `defaults/config.json` 同步改成 `403` / `503` |

**实测**（直接调 `get_config()`，喂一份 `status:''` 的旧配置）：

```
get.status  = '403'      ← 原来 ''
cc.status   = '503'
post.status = '403'      ← 原来整个 key 缺失
已落盘 get.status = '403'  ← 自动写回 config.json
```

点「响应」列的链接即可选择 200 / 404 / 403 / 444 / 500 / 502 / 503，保存后引擎按该码返回。

## 三·十六、统计与日志查看修复（v2.3）

### 1. 统计数量不准

`init_worker.lua` 里原来写了：

```lua
sites[site][kind2] = v
sites[site]["total"] = v      -- ← 每处理一个 kind 就覆盖一次 total
```

共享内存 key 的遍历顺序是随机的，所以站点「拦截次数」最后等于**某一个 kind 的计数**（还可能是 `head` 这种小值），不是真实总数。

现在：`total` 只认 `n:<站点>` 这个独立计数键，缺失时才按各 kind 求和；并且落盘间隔从 **15 秒改成 5 秒**，页面数字更及时。

**实测**（构造 `n:a.com=6`、`s:a.com:args=3/url=2/post=1`、`n:b.com=4`、`s:b.com:user_agent=4`）：

```
total      = 10          （期望 10）
rules      = args 3 / url 2 / post 1 / 其余 0
a.com total= 6  args=3 url=2 post=1 cc=0
b.com total= 4  ua=4
```

### 2. 「详细」看不了 / 传入值不完整

- **传入值**：原来日志 `[6]` 记的是「正则**匹配到的那一小段**」（比如 `<`、`1`），
  现在记**完整传入值**（超长截断 1000 字符）。
  `(?i)(union...select...) >> 1 union select 1,2,3` ⇦ 现在是完整参数值
- **详情弹窗打不开**：弹窗里 `new RegExp(rule_arry[0])` 遇到规则里的 PCRE 内联标志 `(?i)`
  会直接抛 `SyntaxError`，整个弹窗挂掉。现在剥掉内联标志改用 `i` 参数，并全程 `try/catch`。

### 3. 「HTTP」列空白

面板把日志 `[7]` 当作完整 HTTP 报文渲染，原来这个位置被我写成了风险值片段。现在输出真实报文：

```
GET /article?x=1 HTTP/1.1
host: a.com
user-agent: Mozilla/5.0
cookie: ...
x-forwarded-for: ...
<其余头最多 20 个>

username=admin&password=1' or 1=1   ← POST body（超 2000 字符截断）
```

### 4. 分页翻不到底 / 空白页

`render_logs_pages(pages, p, num)` 原来把「每页条数」当成了总页数：`pages <= num` 恒成立，
所以**末页也显示「下一页」**，翻过去就是空白页。现在按「本页条数 >= 每页条数」判断，
并且站内日志每页 **10** 条、封锁历史 **14** 条（与后端 `get_safe_logs` 的 `num` 对齐）。

## 三·十七、拦截响应页模板（v2.4）

**症状**：全局配置里点「操作 → 响应内容」，面板提示**文件不存在**。

**原因**：这个按钮走的是面板的 `bt.pub.on_edit_file(0, '/www/server/x_waf/html/<类型>.html')`，
直接打开对应文件来编辑。原版这些模板在数据包里，而我们没有数据包，`html/` 目录是空的。

**修法**：插件自带 5 个拦截页模板 `defaults/html/`，安装时逐文件补齐（缺失才补，不覆盖你改过的）：

| 文件 | 对应拦截类型 |
|---|---|
| `get.html` | GET 渗透 / URL 规则 / 默认页 |
| `post.html` | POST 渗透 |
| `cookie.html` | Cookie 渗透 |
| `user_agent.html` | 恶意 User-Agent |
| `other.html` | IP 黑名单 / CC / 限频 / 禁止海外 等 |

模板是自带样式的完整 HTML（自适应、带拦截时间），安装后权限统一 `644`，
`init.lua` 启动时加载，**改完面板里保存即可生效**（保存会触发 `nginx reload`）。

**实测**（umask 077 下安装）：

```
-rw-r--r-- get.html
-rw-r--r-- post.html
-rw-r--r-- cookie.html
-rw-r--r-- user_agent.html
-rw-r--r-- other.html
```

想换成自己公司风格，直接在「响应内容」里改，或覆盖 `/www/server/x_waf/html/*.html` 后 `nginx -s reload`。

## 三·十八、手动添加站点（v2.5）

**场景**：站点不是通过面板【网站】建的，nginx 配置直接写在一个文件里（或手工加了 server 块）。
面板数据库里没有它 → 站点配置列表里看不到 → 也配不了防护。

### 用法

站点配置页顶部新增 **「新增站点」**：

```
站点/主域名  [ tools.jiaoyuhua.cn          ]
其它域名     [ www.tools.jiaoyuhua.cn, api.tools.jiaoyuhua.cn ]   ← 可留空，逗号分隔
```

添加后：

- 表格里该站点「来源」列显示 **手动**（面板建站显示 **面板**）
- 可以点「设置」逐项开关防护，也会出现在日志/统计里
- 操作列多出 **「移除」**（只对手动站点显示；面板站点请到【网站】里删）

### 实现要点

| 点 | 说明 |
|---|---|
| **不会被自动清掉** | `__check_site()` 原来会删除"不在面板站点表里"的配置，现在带 `manual: true` 的站点一律保留 |
| **域名映射生效** | `__write_site_domains()` 现在把手动站点的 `domains` 也写进 `domains.json`，引擎才能按 Host 找到它 |
| **日志与统计** | 日志轮转/`log_size` 统计的范围也把手动站点算进去 |
| **防重复** | 同名站点或已在面板里的站点会被拒绝，并给出提示 |
| **不动 nginx** | 只在防火墙里增加配置，不会写 nginx 配置、不影响网站本身 |

### 实测

```
1. 新增 tools.jiaoyuhua.cn + 两个子域
   site.json  manual=True  domains=[主域,www,api]
   domains.json [{name: tools.jiaoyuhua.cn, domains:[...]}]
2. 重复添加            → 拒绝：该站点已存在（如需修改域名，请先移除再添加）
3. get_site_config     → 手动站点仍在，没有被删
4. remove 面板站点     → 拒绝：面板站点不能在这里移除，请到【网站】里删除
5. remove 手动站点     → 已移除，site.json 只剩 panel.com
```

## 三·十九、插件图标（v2.6）

新图标：**小人举盾牌**（蓝色盾牌 + 白色对勾 + 微笑小人），扁平风格，32px 下仍可辨识。

| 文件 | 用途 |
|---|---|
| `x_waf/icon.png` | 插件图标（64×64），安装时复制为 `/www/server/panel/static/img/soft_ico/ico-x_waf.png` |
| 包根目录 `x_waf-icon-512.png` | 512×512 大图，可用作 favicon、文档配图、图标底稿 |

配色：盾牌 `#2D7FF9`、高光 `#7EB2FF`、描边 `#16469B`，皮肤 `#F3CDA7`，统一深描边 `#22303F`，
背景 `#F3F7FE` 圆角块（白卡 / 深色栏下都清晰）。

**更新图标**（不用重装）：

```bash
scp x_waf/icon.png root@服务器:/www/server/panel/plugin/x_waf/icon.png
ssh root@服务器 'cp -f /www/server/panel/plugin/x_waf/icon.png /www/server/panel/static/img/soft_ico/ico-x_waf.png && bt restart'
```

然后 Ctrl+Shift+R 强刷面板。

> 想换成插画风：在 DSH 里配置 **Settings → Plugins → Image generation** 后告诉我，我按同一配色重画一版。

## 三·二十、站点统计一直为 0 修复（v2.7）

**症状**：站点配置里「GET / POST / UA」的命中次数永远是 0，首页总数却在涨。

**原因**：`init_worker.lua` 落盘用的是「临时文件 + rename」：

```lua
local f = io.open(XWAF.path .. "/total.json.tmp", "w")   -- 目录是 root:root 755
```

而 `/www/server/x_waf` 目录属主是 `root:root 755`，nginx 的 worker 用户 **www 没有目录写权限**，
`total.json.tmp` 根本创建不出来 → `total.json` 永远停在初始值 `{"sites":{}}` → 站点统计全 0。
（`drop_ip.log` 没受影响，因为它是对**已存在**的文件追加，不需要目录写权限。）

**修法**：

| 改动 | 说明 |
|---|---|
| `init_worker.lua` 直接覆盖写 `total.json` | 该文件是 `www:www 666`，可写；`flush_lock` 已保证同一时刻只有一个 worker 在写，不需要临时文件 |
| 写失败会打 `error.log` | `x_waf: 无法写入 .../total.json`，不再静默失败 |
| 面板 `__write_total()` 写完恢复 666 | 面板改写后可能变成 `root:root 644`，顺手把 `total.json` / `drop_ip.log` chmod 回 666 |
| 安装脚本第 8 步加**写权限实测** | 用 `su www -c ': >> total.json'` 真写一次，输出 `读=✓ 写=✓` |

**实测**（模拟目录 555 不可创建文件、`total.json` 666 可写）：

```
旧写法(临时文件)能否创建:  不能 ✓ 复现了权限问题
total      = 7         （期望 7）
a.com total= 5         （期望 5） args=3 cc=2
b.com total= 2         （期望 2） ua=2
rules      = 4 / 3     （期望 4/3）
```

**验证命令**：

```bash
ls -l /www/server/x_waf/total.json      # 应为 -rw-rw-rw- www www
cat /www/server/x_waf/total.json        # sites 里应有你的站点计数
```

统计每 **5 秒**落盘一次；`nginx -s reload` 不清零（共享内存保留），`restart` 会清零。

## 三·二十一、站点统计全 0 的真正原因（v2.8）+ HTTP 弹窗优化

### 站点统计全 0

首页有数、站点配置全是 0 —— 说明计数器本身没问题，是**对不上号**：

引擎是按**请求 Host** 记计数的（`n:www.a.com`），而面板站点名是 `a.com`，
`total.json` 里 key 是 `www.a.com`，面板按 `a.com` 去取 → 取不到 → 全 0。

**三处一起修**：

| 改动 | 说明 |
|---|---|
| 计数**按别名合并** | `__collect_site_total()` 把「站点名 + 该站点所有绑定域名」在 `total.json` 里的计数累加，`www.a.com` 的命中会算到 `a.com` 上 |
| **当日日志兜底** | 合计仍为 0 时，`__count_today_log()` 直接解析当天的 `站点_日期.log`，按「过滤器」字段归类统计，口径与「日志」页完全一致 |
| 引擎打印未匹配告警 | `resolve_site()` 找不到站点时，每 host 每 5 分钟往 `error.log` 写一条：`x_waf: 未匹配到站点配置 host=xxx` |

**实测**：

```
场景1 引擎记在 www.a.com，面板站点名 a.com
   POST = 1   GET = 5      （期望 1 / 5）✓
场景2 total.json 里没有站点计数，走当天日志兜底
   POST = 1  GET = 2  CC = 1  UA = 1     ✓
```

> 之前的「未匹配」日志会落到 `_default_<日期>.log`，这类请求不计入任何站点。
> 更新后先看 `grep '未匹配到站点配置' /www/server/nginx/logs/error.log` 确认有没有这种 host。

### HTTP 详情弹窗

| 改动 | 说明 |
|---|---|
| 右上角关闭按钮 | `closeBtn:1` → `closeBtn:2`（更大的圆形按钮），底部再加 **复制内容 / 关闭** 两个按钮，`shadeClose:false` 不会误关 |
| 一键复制 | 工具栏「复制全部」+ 底部「复制内容」，复制后弹提示且**不关闭**弹窗 |
| 可读性 | `pre` 区域独立滚动（`flex:1; overflow:auto`），等宽字体、行高 1.7，顶部显示「共 N 行」 |
| 自动换行开关 | 长 Header 不会横向溢出，可点「自动换行：关/开」切换 |
| 空数据提示 | 旧日志没有 `[7]` 字段时提示「旧日志没有记录，新拦截才会有」 |

## 三·二十二、规则库扩容 + 一键批量更新（v2.9）

### 1. 规则从 111 条扩到 234 条

新增的都是 **2021~2025 主流漏洞与扫描器特征**（`defaults/rule/*.json`）：

| 文件 | 原来 | 现在 | 新增覆盖 |
|---|---|---|---|
| `url.json` | 40 | **79** | 路径穿越编码变体、`/etc/passwd`、`.git/config`、`.env`、备份文件、`/actuator/env`、Spring Cloud Gateway(CVE-2022-22947)、Solr、Nacos、Druid、JBoss、WebLogic、Jenkins、Liferay、PHPUnit eval-stdin、ThinkPHP `?s=/`、Laravel Ignition(CVE-2021-3129)、Fortinet(CVE-2018-13379)、Cisco ASA、Ivanti(CVE-2024-21887)、F5、Citrix(CVE-2019-19781)、Exchange ProxyLogon、Grafana(CVE-2021-43798)、ES/Kibana、Swagger、IoT 设备 |
| `args.json` | 28 | **51** | Log4Shell(CVE-2021-44228)、Spring4Shell(CVE-2022-22965)、SpEL、Fastjson、OGNL(Struts2/Confluence)、SSTI 模板注入、XXE、SSRF 危险协议、云元数据 `169.254.169.254`、Java/PHP 反序列化、SQL 报错注入、NoSQL、LDAP、命令注入、CRLF |
| `post.json` | 22 | **36** | Java 反序列化、Log4j、Fastjson、PHP 对象注入、免杀木马（`base64_decode($_POST)`）、ThinkPHP RCE、Ignition、POST 型 SQLi、XXE、恶意文件上传、内嵌 PHP |
| `user_agent.json` | 13 | **20** | nuclei / ffuf / gobuster / dirsearch / xray / goby / fscan / w12scan、Censys / Shodan / zgrab / LeakIX、Metasploit / Nessus / AWVS / AppScan、masscan / naabu、whatweb / wpscan |
| `cookie.json` | 8 | **12** | Log4j(Cookie)、Shiro `rememberMe` 反序列化、BeEF 钩子、PHP 对象注入 |
| `scan_black.json` | 3 段 | **35 行** | header / cookie / args 三段多行正则同步扩容 |

全部 **234 条正则已用 PCRE 逐条编译验证：0 失败**；`waf.lua` 用例 **32/32 通过**。

### 2. 全局配置 → 一键批量更新规则库

```
[一键批量更新规则库]  [合并新增（推荐）▾]  [可选：远端规则目录URL]   规则库共 234 条 / 12 个文件
```

下方是规则文件清单（条数 / 更新时间 / 「查看」直接编辑），点「查看」用面板编辑器打开对应 JSON。

| 模式 | 行为 |
|---|---|
| **合并新增（推荐）** | 按「正则内容」去重追加，**你手工加的/改过的规则一条都不动** |
| **完全覆盖** | 用最新规则整体替换（慎用） |

规则来源优先级：

1. 填了远端目录 URL → 依次拉取 `<URL>/url.json`、`<URL>/args.json` …（单个失败会用内置规则补上）
2. 留空 → 用**插件包自带的最新规则**（升级 zip 后点一下就能把新规则灌进运行时）

更新完自动 `nginx -s reload`，引擎在 `init_by_lua` 阶段重新编译规则，**立即生效**。

### 3. 全部 167 个函数补了中文注释

| 文件 | 新增注释 |
|---|---|
| `x_waf_main.py` | 99 个方法（读配置、站点、规则、限频、日志、统计…） |
| `waf.lua` / `init.lua` / `init_worker.lua` / `limit.lua` | 20 个函数（匹配、拦截、计数、落盘、限频…） |
| `install.sh` | 14 个函数（环境检查、部署、权限、校验、回滚…） |

原本已有注释的函数保持原样，不重复插入。

**实测**：

```
get_rule_files      12 个文件，url.json 条数正确
一键更新(merge)      共 12 个文件，新增 234 条；自定义规则保留 ✓，Log4j 规则已加入 ✓
再点一次(merge)      新增 0 条（幂等）✓
完全覆盖(replace)    自定义规则被清除，条数回到内置 79 条 ✓
远端不可用           自动回落内置规则，并提示"远端 12 个文件拉取失败，已用内置规则补上" ✓
```

## 三·二十三、一键清空统计 / 企业微信拦截提醒（v3.0）

### 1. 站点配置 → 一键清空统计和日志

站点配置页顶部多两个按钮：

| 按钮 | 作用 |
|---|---|
| **一键清空统计和日志** | 清零所有站点的命中统计 + 删除全部日志（含封锁历史），规则和配置不动。二次确认后执行 |
| **拦截提醒设置** | 见下面第 2 节 |

每个站点的操作列还多了 **「清空」**，只清这个站点的统计与日志：

```
清空 a.com 后：sites 只剩 b.com，total 18 → 8，a.com 的日志已删，b.com 的日志保留
```

实现要点：`clear_site_data()` 会同步改 `total.json`（并**扣减全局总数**）、删 `logs/<站点>_*.log`、
把 `site.json` 里的 `log_size` 归零，最后 `nginx reload`。

### 2. 企业微信机器人推送提醒

「拦截提醒设置」弹窗：

```
☑ 启用企业微信机器人推送
  Webhook   [ https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxxx ]
  推送间隔  [60] 秒最多推送一条

选择触发哪些规则后推送
  ☑ GET渗透（URL/参数过滤）  ☑ POST渗透  ☑ CC攻击/禁止海外  ☑ 常见扫描器
  ☑ 恶意 User-Agent  ☐ Cookie渗透  ☑ IP黑名单/HEAD  ☑ URL限频  ☑ 自定义URI拦截

[保存] [发送测试消息] [取消]
```

**推送效果**（企业微信 markdown 消息，命中多时自动聚合，不刷屏）：

```
x_waf 拦截提醒
> 站点：tools.example.com
> 类型：GET渗透 x12、扫描器 x3
> 最近：1.2.3.4  /index.php?id=1 union select 1
> 时间：2026-10-29 21:30:12  本次推送 15 条
```

**架构**（全异步，不影响网站性能）：

| 环节 | 做法 |
|---|---|
| 命中时 | `waf.lua` 把事件写入共享内存队列 `wqe:<自增号>`（TTL 600 秒），**只做一次 set，不阻塞请求** |
| 推送时 | `init_worker.lua` 每 15 秒检查一次，按 `interval` 限频，用 nginx **cosocket** 异步 POST 到机器人 Webhook |
| 聚合 | 按站点 + 规则类型合并计数，一条消息最多列 5 个站点，超过 3000 字节截断 |
| 失败处理 | 发送失败写 `error.log`，事件保留在队列里下轮重试（TTL 到期自动清理） |
| 开关 | 只推送你勾选的规则类型；未勾选的类型连队列都不进 |

**实测**：

```
清空单站点   a.com 统计清零、total 18→8、a.com 日志删除、b.com 不受影响 ✓
一键清空     sites={} total=0 rules归零、日志目录清空 ✓
未填 webhook 启用   → 拒绝：启用推送时必须填写 Webhook 地址 ✓
填错域名            → 拒绝：Webhook 地址格式不正确 ✓
合法配置            → 保存成功，读回 open/interval/rules 全部正确 ✓
关闭推送不填 webhook → 允许保存 ✓
```

> 说明：引擎侧只做「入队 + 定时推送」，Webhook 只从你填的地址发出，不会上传到任何第三方。
> 「发送测试消息」由面板直接发送，收到消息就说明配置通了。

## 三·二十四、规则文件格式化查看（v3.1）

全局配置 → 规则库 → 点 **「查看」** 不再调用面板的裸文件编辑器，而是打开内置查看器：

```
规则文件【url.json】共 79 条
[格式化视图] [原始 JSON（可编辑）]                        复制格式化文本
──────────────────────────────────────────────────────────────
 序号  状态   名称                    正则
  1   启用   目录穿越 ../            (?i)(\.\./|\.\.\\)
  2   启用   探测系统敏感文件          (?i)(/etc/(passwd|shadow|group)|...)
  3   启用   空字节截断               (?i)(%00|%2500|\\x00)
  ...
```

| 能力 | 说明 |
|---|---|
| **格式化视图** | 列表型规则渲染成表格（序号 / 启用状态 / 中文名 / 正则）；`scan_black` 三段正则按「header / cookie / args」分组逐条列出行号 |
| **原始 JSON（可编辑）** | 切过去就是**一条规则一行**的美化 JSON，可直接改、直接按「保存」 |
| **保存校验** | 写盘前校验 JSON 语法与结构（列表必须是 `[1,"正则","名称",0]`，`scan_black` 必须是三段对象），报错精确到第几条 |
| **保存即生效** | 保存后自动 `nginx -s reload`，引擎在 `init_by_lua` 重新编译规则 |
| **复制格式化文本** | 一键复制整个规则文件，方便贴到工单/备份 |

### 写盘格式也一并美化了

以前 `json.dumps()` 出来的是一整行，现在是「一条规则一行」：

```
[
  [1, "(?i)(\\.\\./|\\.\\.\\\\\\)", "目录穿越 ../", 0],
  [1, "(?i)(/etc/(passwd|shadow|group)|/proc/self/(environ|cmdline))", "探测系统敏感文件", 0],
  ...
]
```

插件内置的 12 个规则文件、以及「一键批量更新」「单条规则增删改」写盘时都用这个格式，
所以**磁盘上看到的文件本身就是可读的**，出问题直接用 `vi` 也能看懂。

**实测**：

```
查看 url.json      kind=list  count=79   一条规则一行
查看 scan_black    kind=dict  count=35   header/cookie/args 三段
原样保存回去       成功，写盘 81 行（2 行括号 + 79 条规则）
坏 JSON            → 拒绝：JSON 格式错误：Expecting value: line 1 column 10
结构不对（对象）    → 拒绝：该规则文件必须是列表结构 [启用, 正则, 名称, 0]
scan_black 传列表   → 拒绝：必须是 {"header": "...", "cookie": "...", "args": "..."} 结构
追加一条后保存      成功，条数 79 → 80，内容正确
```

美化后规则仍是 **234 条、PCRE 编译 0 失败**、`waf.lua` 用例 **32/32 通过**。

## 三·二十五、企业微信 Webhook「地址不正确」修复（v3.2）

**症状**：明明是正确的企业微信机器人地址，保存时提示「Webhook 地址格式不正确」。

**实测**：直接向该地址 POST，返回 `{"errcode":0,"errmsg":"ok"}` —— 地址本身没问题，是插件把它弄脏了。

**根因**：面板自带的 `escapeHTML()` 里有一句 `.replace(/=/g, "＝")`（把等号换成**全角**）。
弹窗回填 webhook 时用了它，于是 `send?key=xxx` 变成 `send？key＝xxx`，
再保存时正则 `send\?key=` 匹配不上 → 报「地址不正确」。

**修法**：

| 层 | 改动 |
|---|---|
| 前端 | 新增 `escape_val()`（只转 `& " < >`，保留 `= ( ) \`` 等字符），webhook / 限频正则 / 备注 / Key 名称等**输入框**全部改用它 |
| 前端 | 弹窗打开时把历史脏数据清洗一遍（`＝？：／` → `=?://`，去空白） |
| 后端 | 新增 `__norm_webhook()`：去空白/零宽字符/引号、全角转半角、缺 `https://` 自动补、**只要串里能提取到 key 就重建成标准地址** |
| 后端 | 不在「启用」状态时**完全不校验**地址，随便存不报错 |
| 后端 | `save_notify_config` 全函数包了 try/except，异常时把真实原因返回前端，不再只显示「系统错误」 |

**实测 12 种输入**：

```
不启用 + 空 webhook        OK
不启用 + 正确 webhook      OK
不启用 + 全角等号 ＝        OK   ← 原来会报错
不启用 + 只传部分字段       OK
不启用 + None 字段         OK
启用 + 正确 webhook        OK
启用 + 全角等号 ＝          OK   ← 自动纠正
启用 + 前后空格/换行        OK   ← 自动去掉
启用 + 缺 https://         OK   ← 自动补全
启用 + 带引号              OK   ← 自动去掉
启用 + 错域名              ERR  不是企业微信的地址
启用 + 没有 key            ERR  没找到 key 参数
```

**服务器侧直接测（不经插件）**：

```bash
curl -s -X POST 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=你的KEY' \
  -H 'Content-Type: application/json' \
  -d '{"msgtype":"text","text":{"content":"x_waf 测试"}}'
# 返回 {"errcode":0,"errmsg":"ok"} 就说明地址没问题
```

## 三·二十六、弹窗「点一次开多个」修复（v3.3）

**症状**：点「拦截提醒设置」或「添加规则」，一次点击弹出好几个弹窗。

**两个原因**：

1. **同一个按钮被绑了两次**：原版遗留的 `$('.update_rule').click(...)`（直连 `update_overall_rule`）
   和新增的委托绑定同时挂在一个按钮上；
2. **委托绑定会累积**：`$(document).on('click', '.xxx', ...)` 在 `init()` 被多次执行时
   （页面重复渲染、iframe 重载等）会叠加多个相同处理器，点一次触发 N 次。

**修法**：

| 改动 | 说明 |
|---|---|
| 命名空间委托绑定 | 改成 `$(document).off('click.xwaf')` + `$(document).on('click.xwaf', ...)`，先解绑再绑，天然幂等 |
| 删除重复绑定 | 移除原版遗留的 `$('.update_rule').click()` |
| 事件隔离 | 每个处理器加 `e.preventDefault(); e.stopPropagation();`，避免冒泡触发其它处理器 |
| **弹窗互斥** | 新增 `ifOpen()` 守卫：已有 `layui-layer-page` 打开时直接忽略这次点击。所有弹窗（提醒设置 / 新增站点 / 限频编辑 / 规则查看）入口都加了 |

**验证**：

```
document 级绑定只剩 5 条，全部带 .xwaf 命名空间        ✓
新增按钮上的直接绑定 0 条                              ✓
ifOpen() 定义 1 处、调用 4 处（四个弹窗入口各一）      ✓
node --check 语法通过                                  ✓
```

## 三·二十七、弹窗高度自适应（v3.4）

**症状**：URL 限频 / 提醒设置 / 新增站点 弹窗底部空一大块白，内容没铺满。

**原因**：弹窗高度写死（`area:['680px','640px']`），而内容区又被限成 `max-height:430px`，
两者一减就是那块空白。

**修法**：

| 改动 | 说明 |
|---|---|
| 弹窗高度改 `auto` | `area:['700px','auto']`，弹窗跟着内容走，有几个字段就多高 |
| 内容区不再写死 430px | `.xw-lf{max-height:calc(100vh - 210px);overflow:auto}`，内容多时才内部滚动，不会顶出屏幕 |
| 兜底 | 极少数面板的 layui 不认 `auto`，`success` 里量一下高度，小于阈值就退回固定高度（560/380px），并整段 `try/catch` |
| 维度联动后重算 | 勾选/取消「Key 维度」时内容高度会变，自动重新贴合弹窗 |

三个弹窗都改了：**URL 限频编辑**、**企业微信提醒设置**、**新增站点**。

顺带把 `index.html` 的换行统一成 LF（原来 CRLF/LF 混用 3793 处，导致后续精确替换容易匹配不上），
纯格式整理，**不影响任何功能**。

## 三·二十八、推送诊断 + 一键重新部署引擎（v3.5）

**症状**：站点日志里有拦截记录，企业微信收不到提醒。

**九成原因是：运行时 lua 引擎还是旧版。**

推送代码在 **`waf.lua`（命中入队）** 和 **`init_worker.lua`（定时推送）** 里，
而这两个文件在服务器上位于 **`/www/server/x_waf/`** —— 只有 `install.sh` 会从插件目录部署过去。
如果只执行了 `cp -rf x_waf/. /www/server/panel/plugin/x_waf/` + `bt restart`，
插件界面（py/html）是新的，**引擎还是旧的**，日志照写、但根本没有推送逻辑。

### 先自查（3 条命令）

```bash
grep -c queue_alert  /www/server/x_waf/waf.lua           # 应 >=1，0 表示引擎是旧版
grep -c notify_flush /www/server/x_waf/init_worker.lua    # 应 >=1
python3 -c "import json;print(json.load(open('/www/server/x_waf/config.json')).get('notify'))"
```

### 面板里一键修

「拦截提醒设置」弹窗现在有四个按钮：**保存 / 一键诊断 / 发送测试消息 / 取消**

点 **「一键诊断」**，逐项检查并给结论：

```
检查项                        结果
运行时 waf.lua 的命中入队代码   缺失 ✗（引擎是旧版，需要重新部署）
运行时 init_worker.lua 定时推送 缺失 ✗
运行时 init.lua 的配置加载代码  缺失 ✗
引擎文件版本对比               插件包比运行时新 3599 秒，建议重新部署引擎
配置中的推送开关               已开启 ✓
配置中的 Webhook               https://qyapi.weixin.qq.com/...
勾选推送的规则类型             get、post、cc、scan、user_agent、head、limit、url_rule
error.log 中的相关告警         没有异常记录 ✓

[重新部署引擎并重载]   ← 点这里
```

点「重新部署引擎并重载」会把 `init.lua / init_worker.lua / waf.lua / limit.lua`
+ 5 个拦截页同步到 `/www/server/x_waf/`、设成 644，然后 reload nginx；
完成后自动再诊断一遍，全绿即可。

### 实测

```
诊断(运行时旧版)   发现 3 项缺失 + 版本落后 3599 秒，status=False
重新部署引擎      已部署 4 个文件，nginx 已 reload，拦截页 5 个补齐
再诊断            全部 OK，status=True
```

### 还是收不到？

| 排查 | 命令 / 位置 |
|---|---|
| nginx 出网是否被限制 | `tail -50 /www/server/nginx/logs/error.log | grep 企业微信` |
| 引擎里有没有告警代码 | `grep -c notify_flush /www/server/x_waf/init_worker.lua` |
| 推送间隔没到 | 默认 60 秒一条，最多等 15+60 秒 |
| 勾选的规则类型不对 | 你触发的是哪类就勾哪类（比如 SQL 注入属 GET/POST 渗透） |

## 三·二十九、规则文件「查看」点了没反应修复（v3.6）

**症状**：全局配置 → 规则文件 → 点「查看」没有任何反应。

**原因**：v3.3 为了防重复弹窗加的守卫判断错了：

```js
if($('.layui-layer-page:visible').length > 0) return true;   // ← 太宽
```

它把面板自己开的任何 page 层都算成"已有弹窗"，于是 `rule_view()` 一进去就 `return`，
表现就是点了没反应。

**修法**：

| 改动 | 说明 |
|---|---|
| 守卫改**精确计数器** | `ifOpen()` 只看本插件自己开的弹窗数（`markDlg(1)` / `markDlg(-1)`），不再猜 DOM |
| 规则查看**彻底去掉守卫** | 查看器多开一个也无害，直接放行 |
| 计数回滚 | 读配置失败时把计数还回去，避免一次失败之后所有弹窗都被挡住 |
| 事件改委托 | `.rule_view` 改成 `$(document).on('click.xwaf', '.rule_view', ...)`，表格重新渲染也不会丢事件 |
| 双重兜底 | 后端读规则文件失败时，自动改用面板自带文件编辑器打开 `/www/server/x_waf/rule/<name>.json` |

**验证**：

```
ifOpen() 调用 3 处（提醒设置 / 新增站点 / 限频编辑），rule_view 无守卫  ✓
markDlg(1) ×3 + markDlg(-1) ×3（end 回调）                            ✓
.rule_view 委托绑定 1 处，位于 init() 内                               ✓
node --check 语法通过                                                 ✓
```

## 三·三十、点一次弹两次——统一开窗闸门（v3.7）

**症状**：按钮点一次，弹窗出现两个。

单纯"同一个函数被调两次"用计数器就能挡住，既然仍会叠，说明是**两条不同代码路径**在开窗，
或者 confirm 类弹窗（`bt.confirm`）被重复触发。所以这次不猜原因，直接从机制上收口。

### 改动

| 机制 | 说明 |
|---|---|
| **统一开窗闸门 `openDlg(tag, opts)`** | 本插件 4 个弹窗（提醒设置 / 新增站点 / 限频编辑 / 规则查看）全部改走这里：<br>· 同一 `tag` 600ms 内重复触发 → 直接忽略（挡双击 / 重复绑定 / 冒泡）<br>· 打开新窗前先关掉本插件之前开的窗（挡两条路径同时开窗）<br>· 每个弹窗都打上 `xwaf-dlg` class，方便定位 |
| **`throttle(tag, ms)` 通用节流** | 一键清空、一键更新规则库、站点清空、推送诊断这些 `bt.confirm` 类动作也加上 600ms 节流 |
| 移除计数器守卫 | 上一版的 `ifOpen()`/`markDlg()` 有"失败不回滚"的隐患（会把后续点击全挡住），已删除，改由 `openDlg` 统一负责 |

### 自助排查（F12 Console）

```js
// 1) document 上挂了几个 click 处理器？（正常是 1，>1 说明还有重复绑定）
$._data(document, 'events').click.length

// 2) 当前有几个本插件弹窗？（关闭后应为 0）
$('.xwaf-dlg').length

// 3) 看某个按钮绑了几次
$._data($('.notify_setting')[0], 'events')
```

### 验证

```
openDlg('addsite'|'notify'|'rulefile'|'limit', ...)   4 处  ✓
throttle() 4 处（clear_site / clear_all / update_rules / diag）✓
markDlg 残留仅定义、无调用                                   ✓
node --check 语法通过                                        ✓
```

## 三·三十一、推送还是不触发：两条立即验证的路（v3.8）

### 路线 A：面板侧「立即补推」（不依赖引擎，最快验证）

拦截提醒设置 → **一键诊断** → 点 **「立即补推最近30分钟拦截」**

它由 **面板（Python）** 直接读当天日志、聚合成 markdown、POST 到你的 Webhook：

- 收到消息 → Webhook、出网、消息格式都没问题，问题只在**引擎没生效**（见路线 B）
- 提示「最近 30 分钟内没有新的拦截记录」→ 说明**根本没触发规则**（日志里的记录可能是更早的）
- 提示 `推送失败：errcode=...` → 企业微信返回的具体原因

### 路线 B：服务器侧一键体检脚本

`notify_check.sh`（随包提供，只读 + 一次真实推送）：

```bash
scp notify_check.sh root@服务器:/tmp/ && bash /tmp/notify_check.sh
```

输出六段：

```
1. 运行时引擎是否有推送代码        ← 缺哪个文件就是引擎没部署
2. 引擎文件时间                    ← 和插件目录里的同名文件比，谁新
3. 配置里的 notify                 ← open / webhook / rules
4. nginx 出网 + Webhook 连通性     ← 真实 POST，返回 errcode:0 就通
5. 最近的拦截日志                  ← 今天有没有记录、最后一条长啥样
6. nginx 错误日志里的推送相关记录   ← 有「企业微信推送失败」就是 nginx 出网问题
```

末尾直接给结论：

```
· 第 1 步有 [!!] → 引擎旧版：点「重新部署引擎并重载」或跑 install.sh
· 第 4 步能到群   → Webhook 与出网正常，问题只在引擎没生效
· 第 4 步 curl(6)/(7) → 服务器出不了网，放行 qyapi.weixin.qq.com:443
· 1、4 都 OK 但收不到 → 规则类型没勾，或 60s 间隔没到
```

### 为什么引擎侧容易"看起来没生效"

| 环节 | 依赖 | 症状 |
|---|---|---|
| 命中入队 | `waf.lua`（运行时） | 日志有、但队列里没东西 |
| 定时推送 | `init_worker.lua`（运行时） | 队列有、永远不发 |
| 配置加载 | `init.lua`（运行时） | `XWAF.notify` 为 nil，直接跳过 |
| 出网 | nginx 进程（worker） | error.log 出现「企业微信推送失败」 |

**这三个文件都在 `/www/server/x_waf/`，只有 `install.sh` 或面板「重新部署引擎」会更新它们。**
只 `cp` 插件目录 + `bt restart` 是**不会**更新的。

**方式 B：手动放置（不上商店）**

```bash
# 插件目录
scp -r x_waf root@host:/www/server/panel/plugin/x_waf
# 运行时目录由 install.sh 负责创建
chmod +x /www/server/panel/plugin/x_waf/install.sh
bash /www/server/panel/plugin/x_waf/install.sh install
```

刷新面板即可看到插件（`info.json` 的 `checks` 指向插件目录）。

**方式 C：覆盖原版（不推荐，先卸载原版）**

原版与本分支的 `lua_shared_dict` 同名，**必须先卸载原版**，否则安装脚本会拒绝执行。
确实要强装：`FORCE=1 bash install.sh install`。

卸载：

```bash
bash /www/server/panel/plugin/x_waf/install.sh uninstall          # 保留拦截日志
bash /www/server/panel/plugin/x_waf/install.sh uninstall purge    # 连日志一起删
```

---

## 四、已知限制

- 免费版能力边界（作者原文）：**没有 CC 防护**、非四层拦截、无语义分析、
  XSS 规则为降误报做过删减。要 CC 请用付费版或前方加 CDN/WAF。
- Nginx 版本：1.22 / 1.24 / 1.25 / 1.26 已验证；ARM 机器建议配 OpenResty。
  与「堡塔网站加速」有兼容性冲突。
- 与付费版「Nginx 网站防火墙」互斥，只能装一个。
- 插件以 root 运行 `install.sh`，改脚本请自己 review 后再上生产。
