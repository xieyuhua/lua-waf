把原插件包里的 free_waf_data.zip 解压到这个目录（data/）即可。

安装脚本需要的最小文件清单：

必要：只要 lua 引擎，规则库已经有了
    waf.lua            主拦截逻辑（access_by_lua_file）
    init.lua           初始化（原包中叫 4.7.lua，脚本会自动改名识别）

规则库（rule/*.json）插件已自带一套默认值放在 ../defaults/rule/，
   安装时会自动补进 /www/server/x_waf/rule/（只补空的/缺失的，不覆盖你调过的）。
   如果你有原版调教好的规则，放进 data/rule/ 会优先于默认规则生效。

可选：
    multipart.lua  zhi.lua  dns.lua
    1.json ~ 7.json            蜘蛛/扫描器特征
    zhizhu1/2/4/5/6.json       蜘蛛 IP 池
    drop_ip.log                封禁记录
    html/get.html              拦截提示页模板
    html/post.html  html/cookie.html  html/user_agent.html  html/other.html

放好之后：面板 → 软件商店 → 导入插件，上传 x_waf.zip 即可。
文件名保持原样即可，安装脚本会把里面写死的 /www/server/free_waf、
/www/wwwlogs/free_waf_log 自动改成 /www/server/x_waf、/www/wwwlogs/x_waf_log。

如果懒得解压，也可以直接把原来的 free_waf_data.zip 改名为 x_waf_data.zip
放在插件根目录（不是本目录），安装脚本会自动解压。
