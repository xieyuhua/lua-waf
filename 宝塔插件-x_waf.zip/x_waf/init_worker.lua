-- ============================================================================
--  x_waf init_worker.lua —— worker 启动后周期把内存计数器落盘到 total.json
--  由 x_waf.conf 的 init_worker_by_lua_file 调用
-- ============================================================================
local XWAF = _G.XWAF
if not XWAF then
    return
end

local cjson_ok, cjson = pcall(require, "cjson")
local DICT = ngx.shared.free_waf
local KINDS = { "post", "args", "url", "cc", "user_agent", "cookie", "scan", "head" }

-- 生成一份全 0 的统计结构（保证面板取不到 key 时不出错）
local function zero_rules()
    local r = {}
    for _, k in ipairs(KINDS) do r[k] = 0 end
    return r
end

-- 定时把共享内存里的计数落盘到 total.json（每 5 秒，带锁防并发）
local function flush(premature)
    if premature or not DICT or not cjson_ok then
        return
    end
    -- 多 worker 只让一个落盘
    if not DICT:add("flush_lock", 1, 4) then
        return
    end

    local rules = zero_rules()
    local sites = {}
    local total = DICT:get("T") or 0

    local ok, keys = pcall(DICT.get_keys, DICT, 0)
    if not ok or type(keys) ~= "table" then
        return
    end

    for _, k in ipairs(keys) do
        local v = DICT:get(k)
        if v then
            local kind = string.match(k, "^r:(.+)$")
            if kind then
                rules[kind] = v
            else
                local rest = string.match(k, "^s:(.+)$")
                if rest then
                    local site, kind2 = string.match(rest, "^(.*):([^:]+)$")
                    if site and kind2 then
                        sites[site] = sites[site] or zero_rules()
                        sites[site][kind2] = v
                        -- 注意：原来这里还有 sites[site]["total"] = v，
                        -- 会被最后一个 kind 覆盖掉，导致站点"拦截次数"统计错乱
                    end
                else
                    local site2 = string.match(k, "^n:(.+)$")
                    if site2 then
                        sites[site2] = sites[site2] or zero_rules()
                        sites[site2]["total"] = v
                    end
                end
            end
        end
    end

    for name, item in pairs(sites) do
        if type(item) ~= "table" then sites[name] = zero_rules(); item = sites[name] end
        if not item["total"] or item["total"] == 0 then
            local sum = 0
            for _, kk in ipairs(KINDS) do sum = sum + (tonumber(item[kk]) or 0) end
            item["total"] = sum
        end
        for _, kk in ipairs(KINDS) do
            if not item[kk] then item[kk] = 0 end
        end
    end

    local data = { rules = rules, sites = sites, total = total }
    local ok2, json = pcall(cjson.encode, data)
    if not ok2 then
        return
    end
    -- 注意：不要用"临时文件 + rename"的写法。
    -- /www/server/x_waf 目录是 root:root 755，nginx worker(www) 无法在目录里创建新文件，
    -- io.open("total.json.tmp","w") 会失败 → total.json 永远不更新 → 面板统计一直是 0。
    -- total.json 本身是 www 可写(666)，直接覆盖写即可；flush_lock 已保证同一时刻只有一个 worker 在写。
    local dst = XWAF.path .. "/total.json"
    local f, err = io.open(dst, "w")
    if f then
        f:write(json)
        f:close()
    else
        ngx.log(ngx.ERR, "x_waf: 无法写入 ", dst, " （", tostring(err), "），站点统计不会更新")
    end
end

-- ============================================================================
--  企业微信机器人告警
--  waf.lua 在命中时把事件写进共享内存队列（wqe:<自增号>，TTL 600 秒），
--  这里每 15 秒检查一次：达到 notify.interval 间隔就聚合推送一条 markdown 消息。
--  推送用的是 nginx cosocket，全异步，不阻塞请求。
-- ============================================================================
local KIND_NAME = {
    get = "GET渗透", post = "POST渗透", cc = "CC攻击", scan = "扫描器",
    user_agent = "恶意UA", cookie = "Cookie渗透", head = "黑名单/HEAD",
    limit = "URL限频", url_rule = "自定义URI拦截"
}

-- 发一个 HTTPS 请求到企业微信机器人（返回 true/false, 错误信息）
local function wecom_post(url, body)
    local scheme, host, path = string.match(url, "^(https?)://([^/]+)(/.*)$")
    if not scheme then
        return false, "webhook 地址格式不正确"
    end
    local sock = ngx.socket.tcp()
    sock:settimeout(5000)
    local ok, err = sock:connect(host, (scheme == "https") and 443 or 80)
    if not ok then
        return false, err
    end
    if scheme == "https" then
        local sok, serr = sock:sslhandshake(false, host, false)
        if not sok then
            sock:close()
            return false, serr
        end
    end
    local req = "POST " .. path .. " HTTP/1.1" .. "\r\n" ..
        "Host: " .. host .. "\r\n" ..
        "Content-Type: application/json" .. "\r\n" ..
        "Content-Length: " .. #body .. "\r\n" ..
        "Connection: close" .. "\r\n\r\n" .. body
    local wok, werr = sock:send(req)
    if not wok then
        sock:close()
        return false, werr
    end
    local status = sock:receive("*l")
    sock:close()
    if status and string.find(status, " 200", 1, true) then
        return true
    end
    return false, status or "无响应"
end

-- 截断过长的字段，保证消息体不超过企业微信 4096 字节
local function cut(txt, maxlen)
    txt = tostring(txt or "")
    if #txt > maxlen then
        return string.sub(txt, 1, maxlen) .. "..."
    end
    return txt
end

-- 定时检查队列并推送
local function notify_flush(premature)
    if premature or not DICT then
        return
    end
    local nf = XWAF.notify
    if not nf or not nf.open or not nf.webhook or nf.webhook == "" then
        return
    end

    -- 最小推送间隔
    local interval = tonumber(nf.interval) or 60
    local last = tonumber(DICT:get("wq_last_send")) or 0
    if ngx.now() - last < interval then
        return
    end
    -- 多 worker 只让一个发送
    if not DICT:add("wq_lock", 1, 10) then
        return
    end

    -- 取队列
    local keys = DICT:get_keys(0) or {}
    local items = {}
    for _, k in ipairs(keys) do
        if string.sub(k, 1, 4) == "wqe:" then
            local v = DICT:get(k)
            if v then
                items[#items + 1] = { k, v }
            end
        end
    end
    if #items == 0 then
        DICT:delete("wq_lock")
        return
    end
    table.sort(items, function(a, b) return a[1] < b[1] end)

    local maxb = tonumber(nf.max_batch) or 50
    local take = math.min(#items, maxb)

    -- 按站点聚合
    local agg, order = {}, {}
    for i = 1, take do
        local v = items[i][2]
        local site, kind, ip, uri, rule, val =
            string.match(v, "^([^\t]*)\t([^\t]*)\t([^\t]*)\t([^\t]*)\t([^\t]*)\t(.*)$")
        if site then
            local a = agg[site]
            if not a then
                a = { count = 0, kinds = {}, first = { ip = ip, uri = uri } }
                agg[site] = a
                order[#order + 1] = site
            end
            a.count = a.count + 1
            a.kinds[kind] = (a.kinds[kind] or 0) + 1
        end
    end

    -- 组装 markdown
    local lines = { "**x_waf 拦截提醒**" }
    local shown = 0
    for _, site in ipairs(order) do
        shown = shown + 1
        if shown > 5 then break end
        local a = agg[site]
        local parts = {}
        for k, c in pairs(a.kinds) do
            parts[#parts + 1] = (KIND_NAME[k] or k) .. " x" .. c
        end
        lines[#lines + 1] = "> 站点：" .. site
        lines[#lines + 1] = "> 类型：" .. table.concat(parts, "、")
        lines[#lines + 1] = "> 最近：" .. tostring(a.first.ip or "") .. "  " .. cut(a.first.uri, 90)
    end
    if #order > 5 then
        lines[#lines + 1] = "> 另有 " .. (#order - 5) .. " 个站点也触发"
    end
    lines[#lines + 1] = "> 时间：" .. ngx.localtime() .. "  本次推送 " .. take .. " 条"
    local content = cut(table.concat(lines, "\n"), 3000)

    local body_ok, body = pcall(cjson.encode, { msgtype = "markdown", markdown = { content = content } })
    if not body_ok then
        DICT:delete("wq_lock")
        return
    end

    local ok, err = wecom_post(nf.webhook, body)
    if ok then
        for i = 1, take do
            DICT:delete(items[i][1])
        end
        DICT:set("wq_last_send", ngx.now(), 0)
    else
        ngx.log(ngx.ERR, "x_waf: 企业微信推送失败：", tostring(err))
    end
    DICT:delete("wq_lock")
end

ngx.timer.every(15, notify_flush)

local ok, err = ngx.timer.every(5, flush)
if not ok then
    ngx.log(ngx.ERR, "x_waf: 无法创建统计落盘定时器: ", err)
end
