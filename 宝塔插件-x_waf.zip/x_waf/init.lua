-- ============================================================================
--  x_waf init.lua —— 初始化阶段加载配置/规则（nginx -s reload 时重新执行）
--  由 x_waf.conf 的 init_by_lua_file 调用
-- ============================================================================
local cjson_ok, cjson = pcall(require, "cjson")

local XWAF = {
    path = "/www/server/x_waf",
    cfg = {},
    sites = {},
    domains = {},
    rules = {},
    scan = {},
    ip_white = {},
    ip_black = {},
    cn = {},
    url_white = {},
    url_black = {},
    html = {},
    ready = false
}

_G.XWAF = XWAF

-- 读文件内容（失败返回 nil）
local function read_file(p)
    local f = io.open(p, "rb")
    if not f then return nil end
    local c = f:read("*a")
    f:close()
    if not c or c == "" then return nil end
    return c
end

-- 读 JSON 文件，失败返回默认值
local function read_json(p, default)
    local c = read_file(p)
    if not c then return default end
    if not cjson_ok then return default end
    local ok, v = pcall(cjson.decode, c)
    if not ok or v == nil then return default end
    return v
end

-- "1.2.3.4" -> 数字（用于 IP 段比较）
local function ip2n(s)
    if not s then return nil end
    local a, b, c, d = string.match(s, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if not a then return nil end
    a, b, c, d = tonumber(a), tonumber(b), tonumber(c), tonumber(d)
    if not (a and b and c and d) then return nil end
    if a > 255 or b > 255 or c > 255 or d > 255 then return nil end
    return a * 16777216 + b * 65536 + c * 256 + d
end

XWAF.ip2n = ip2n

-- 把 [[a,b,c,d],[a,b,c,d]] 形式的 IP 段转成数字区间并排序，便于二分查找
local function build_ranges(list)
    local out = {}
    if type(list) ~= "table" then return out end
    for _, item in ipairs(list) do
        if type(item) == "table" and type(item[1]) == "table" and type(item[2]) == "table" then
            local s = table.concat(item[1], ".")
            local e = table.concat(item[2], ".")
            local sn, en = ip2n(s), ip2n(e)
            if sn and en then
                out[#out + 1] = { sn, en }
            end
        elseif type(item) == "string" then
            local sn = ip2n(item)
            if sn then out[#out + 1] = { sn, sn } end
        end
    end
    table.sort(out, function(x, y) return x[1] < y[1] end)
    return out
end

XWAF.in_range = function(ranges, ipn)
    if not ipn then return false end
    local n = #ranges
    if n == 0 then return false end
    local lo, hi = 1, n
    while lo <= hi do
        local mid = math.floor((lo + hi) / 2)
        local r = ranges[mid]
        if ipn < r[1] then
            hi = mid - 1
        elseif ipn > r[2] then
            lo = mid + 1
        else
            return true
        end
    end
    return false
end

-- 读取规则文件（4 元组格式：[状态, 正则, 说明, 可删除]）
local function load_rules(name)
    local list = read_json(XWAF.path .. "/rule/" .. name .. ".json", {})
    local out = {}
    if type(list) ~= "table" then return out end
    for i, item in ipairs(list) do
        if type(item) == "table" and type(item[2]) == "string" and item[2] ~= "" then
            -- 状态：1/true 启用，0/false/-1 停用
            local st = item[1]
            local enabled = (st == 1 or st == true or st == "1")
            if st == nil then enabled = true end
            if enabled then
                out[#out + 1] = { idx = i - 1, pat = item[2], ps = item[3] or "" }
            end
        end
    end
    return out
end

-- 加载简单字符串列表型的规则文件
local function load_simple_list(name)
    local list = read_json(XWAF.path .. "/rule/" .. name .. ".json", {})
    local out = {}
    if type(list) == "table" then
        for _, v in ipairs(list) do
            if type(v) == "string" and v ~= "" then out[#out + 1] = v end
        end
    end
    return out
end

-- 引擎初始化总入口：读配置/站点/规则/拦截页，编译所有正则
function XWAF.load()
    XWAF.cfg = read_json(XWAF.path .. "/config.json", {}) or {}

-- 企业微信提醒配置（面板「拦截提醒设置」维护；关闭时为 nil，引擎不做任何额外动作）
XWAF.notify = (type(XWAF.cfg.notify) == "table") and XWAF.cfg.notify or nil
if XWAF.notify and not XWAF.notify.open then XWAF.notify = nil end
    if type(XWAF.cfg) ~= "table" then XWAF.cfg = {} end
    XWAF.sites = read_json(XWAF.path .. "/site.json", {}) or {}
    if type(XWAF.sites) ~= "table" then XWAF.sites = {} end

    -- host -> 站点名
    XWAF.domains = {}
    local dom = read_json(XWAF.path .. "/domains.json", {})
    if type(dom) == "table" then
        for _, item in ipairs(dom) do
            if type(item) == "table" and item.name and type(item.domains) == "table" then
                for _, d in ipairs(item.domains) do
                    if type(d) == "string" then XWAF.domains[string.lower(d)] = item.name end
                end
            end
        end
    end

    XWAF.rules = {
        url = load_rules("url"),
        args = load_rules("args"),
        post = load_rules("post"),
        cookie = load_rules("cookie"),
        user_agent = load_rules("user_agent")
    }

    local scan = read_json(XWAF.path .. "/rule/scan_black.json", {})
    XWAF.scan = {}
    if type(scan) == "table" then
        for _, k in ipairs({ "header", "cookie", "args" }) do
            local out = {}
            if type(scan[k]) == "string" then
                for line in string.gmatch(scan[k], "[^\r\n]+") do
                    line = string.gsub(line, "^%s+", "")
                    line = string.gsub(line, "%s+$", "")
                    if line ~= "" then out[#out + 1] = line end
                end
            end
            XWAF.scan[k] = out
        end
    end

    XWAF.ip_white = build_ranges(read_json(XWAF.path .. "/rule/ip_white.json", {}))
    XWAF.ip_black = build_ranges(read_json(XWAF.path .. "/rule/ip_black.json", {}))
    XWAF.cn = build_ranges(read_json(XWAF.path .. "/rule/cn.json", {}))
    XWAF.url_white = load_simple_list("url_white")
    XWAF.url_black = load_simple_list("url_black")

    -- 拦截提示页（读不到就用内置的）
    local function html(name)
        return read_file(XWAF.path .. "/html/" .. name .. ".html")
    end
    XWAF.html = {
        base = html("get") or "<html><head><meta charset=\"utf-8\"><title>已拦截</title></head>"
            .. "<body style=\"font-family:sans-serif;text-align:center;padding-top:80px\">"
            .. "<h1>请求已被 x_waf 拦截</h1><p>如有疑问请联系网站管理员</p></body></html>",
        post = html("post"),
        cookie = html("cookie"),
        user_agent = html("user_agent"),
        other = html("other")
    }

    -- URL 限频规则（面板「URL限频」页维护）
    XWAF.limits = read_json(XWAF.path .. "/limit.json", {})
    if type(XWAF.limits) ~= "table" then XWAF.limits = {} end
    -- 用 dofile 绝对路径加载，避免依赖 lua_package_path（覆盖它会顶掉 openresty 的 resty.core）
    local ok_lm, lm = pcall(dofile, XWAF.path .. "/limit.lua")
    XWAF.limit_mod = (ok_lm and type(lm) == "table") and lm or nil
    if not ok_lm then
        ngx.log(ngx.ERR, "x_waf: limit.lua 加载失败: ", tostring(lm))
    end

    XWAF.ready = true

    if ngx and ngx.log then
        if not cjson_ok then
            ngx.log(ngx.ERR, "x_waf: 未加载 cjson，规则与配置无法解析（检查 /www/server/x_waf/cjson.so 或系统 lua-cjson）")
        else
            local n = 0
            for _, t in pairs(XWAF.rules) do n = n + #t end
            ngx.log(ngx.NOTICE, "x_waf 已加载：开关=", tostring(XWAF.cfg.open),
                " 过滤规则=", tostring(n),
                " 国内IP段=", tostring(#XWAF.cn),
                " 日志目录=", tostring(XWAF.cfg.logs_path or "/www/wwwlogs/x_waf_log"))
            if n == 0 then
                ngx.log(ngx.WARN, "x_waf: 规则库为空，请到面板【全局配置 → 导入内置默认规则】")
            end
        end
    end
    return true
end

XWAF.load()
