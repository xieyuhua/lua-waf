-- ============================================================================
--  x_waf limit.lua —— 按 URL 限频（IP 维度 + Key 维度）
--  被 init.lua 引用：XWAF.load_limits()
--  配置：/www/server/x_waf/limit.json（面板「URL限频」页维护）
--   [
--     {
--       "open": true,
--       "url": "^/api/login",                     -- 对 request_uri 的正则
--       "status": 429,                            -- 超限响应码
--       "ip":  {"open": true,  "cycle": 60, "limit": 10},                      -- 每 IP
--       "key": {"open": true,  "source": "header", "name": "X-Api-Key",
--               "cycle": 60, "limit": 300}                                     -- 每 Key
--     }
--   ]
--   source: arg（URL参数/POST表单） | header（请求头） | cookie
-- ============================================================================

local M = {}

-- 从请求里取出 Key 的值
function M.get_key_value(source, name, args)
    if not name or name == "" then return nil end
    source = string.lower(tostring(source or "header"))
    if source == "header" then
        local h = ngx.req.get_headers()
        local v = h[name] or h[string.lower(name)]
        if type(v) == "table" then v = v[1] end
        return v
    elseif source == "cookie" then
        local c = ngx.var.http_cookie
        if not c then return nil end
        local pat = "(?i)(?:^|;)\\s*" .. string.gsub(name, "([^%w])", "%%%1") .. "\\s*=\\s*([^;]+)"
        local m = ngx.re.match(c, pat, "jo")
        if m and m[1] then return m[1] end
        return nil
    else -- arg
        local v = (args or {})[name]
        if v == nil then
            -- 退一步：POST 表单里找
            local body = ngx.req.get_body_data()
            if body and #body < 65536 then
                local m = ngx.re.match(body, "(?i)(?:^|&)" .. string.gsub(name, "([^%w])", "%%%1") .. "=([^&]*)", "jo")
                if m and m[1] then v = m[1] end
            end
        end
        if type(v) == "table" then v = v[1] end
        return v
    end
end

-- 返回命中的规则信息（用于日志）或 nil
-- 命中并超限时返回 {dim='ip'|'key', rule=规则表, cycle=, limit=, value=}
function M.check(limits, raw_uri, uri, ip, args)
    if type(limits) ~= "table" or #limits == 0 then return nil end
    local SUM = ngx.shared.free_waf_drop_sum
    if not SUM then return nil end

    for idx, r in ipairs(limits) do
        if r.open ~= false and type(r.url) == "string" and r.url ~= "" then
            local matched = ngx.re.find(raw_uri, r.url, "jo")
            if not matched and uri ~= raw_uri then
                matched = ngx.re.find(uri, r.url, "jo")
            end
            if matched then
                -- IP 维度
                local ipc = r.ip
                if type(ipc) == "table" and ipc.open ~= false then
                    local cycle = tonumber(ipc.cycle) or 60
                    local limit = tonumber(ipc.limit) or 0
                    if limit > 0 then
                        local key = "lp:" .. idx .. ":" .. tostring(ip)
                        local n = SUM:incr(key, 1, 0, cycle)
                        if not n then
                            n = (SUM:get(key) or 0) + 1
                            SUM:set(key, n, cycle)
                        end
                        if n > limit then
                            return { dim = "ip", cycle = cycle, limit = limit, status = tonumber(r.status) or 429, value = tostring(ip) }
                        end
                    end
                end
                -- Key 维度
                local kc = r.key
                if type(kc) == "table" and kc.open ~= false then
                    local val = M.get_key_value(kc.source, kc.name, args)
                    if val and val ~= "" then
                        local cycle = tonumber(kc.cycle) or 60
                        local limit = tonumber(kc.limit) or 0
                        if limit > 0 then
                            local key = "lk:" .. idx .. ":" .. tostring(val)
                            local n = SUM:incr(key, 1, 0, cycle)
                            if not n then
                                n = (SUM:get(key) or 0) + 1
                                SUM:set(key, n, cycle)
                            end
                            if n > limit then
                                return { dim = "key", cycle = cycle, limit = limit,
                                         status = tonumber(r.status) or 429,
                                         value = tostring(kc.source) .. ":" .. tostring(kc.name) .. "=" .. tostring(val) }
                            end
                        end
                    end
                end
            end
        end
    end
    return nil
end

return M
