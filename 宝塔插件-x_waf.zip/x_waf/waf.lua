-- ============================================================================
--  x_waf waf.lua —— 请求拦截主逻辑（access_by_lua_file）
--  v2：新增「容忍阈值自动封禁」、原始/解码双份匹配、站点级路径与上传策略
--  任何内部错误都只记日志，绝不阻断站点
-- ============================================================================
local XWAF = _G.XWAF
if not XWAF or not XWAF.ready then
    return
end

local cjson_ok, cjson = pcall(require, "cjson")
local cfg = XWAF.cfg or {}
local DICT = ngx.shared.free_waf
local DROP = ngx.shared.free_waf_drop_ip
local SUM = ngx.shared.free_waf_drop_sum

local LOG_DIR = (cfg.logs_path and cfg.logs_path ~= "") and cfg.logs_path or "/www/wwwlogs/x_waf_log"

-- ---------------------------------------------------------------- 小工具
local function now_ts()
    return ngx.time()
end

-- 共享内存计数器自增：按 TSV 参数逐个键累加，用于全局/站点统计
local function inc(key, n)
    if not DICT then return end
    local v, err = DICT:incr(key, n or 1, 0)
    if not v and err == "not found" then
        DICT:set(key, n or 1, 86400 * 7)
    end
end

-- 计数 + 写站点日志（字段顺序与面板解析严格一致）
-- 生成完整 HTTP 报文（面板「HTTP」列展示的就是这一段）
-- 企业微信提醒：把一次命中丢进共享内存队列（真正发送在 init_worker 的定时器里）
-- 队列键 wqe:<自增号>，带 TTL 自动过期，消费端读走即删
local NOTIFY_MAP = {
    args = "get", url = "get", url_black = "get",
    post = "post",
    cc = "cc", limit_ip = "limit", limit_key = "limit", drop_abroad = "cc",
    scan = "scan", ip_black = "head",
    user_agent = "user_agent", cookie = "cookie",
    head = "head", url_rule = "url_rule"
}

local function queue_alert(site, kind, uri, value, rule)
    if not XWAF.notify or not DICT then return end
    local key = NOTIFY_MAP[kind]
    if not key then return end
    local rules = XWAF.notify.rules
    if type(rules) == "table" and rules[key] == false then return end
    local seq = DICT:incr("wqseq", 1, 0)
    if not seq then return end
    if seq > 1000000 then                      -- 自增号循环用，避免数字无限增长
        DICT:set("wqseq", 1, 0)
    end
    local item = (site or "_default") .. "\t" .. tostring(key) .. "\t" ..
                 (ngx.var.remote_addr or "") .. "\t" .. tostring(uri or "") .. "\t" ..
                 tostring(rule or "") .. "\t" .. tostring(value or "")
    if #item > 900 then item = string.sub(item, 1, 900) end
    DICT:set("wqe:" .. seq, item, 600)          -- 10 分钟没人取就自动过期
end

local function http_dump(body)
    local proto = ngx.var.server_protocol or "HTTP/1.1"
    local lines = { (ngx.req.get_method() or "GET") .. " " .. (ngx.var.request_uri or "/") .. " " .. proto }
    local hdr = ngx.req.get_headers() or {}
    local prio = { "host", "user-agent", "referer", "cookie", "content-type", "content-length", "x-forwarded-for", "x-real-ip" }
    local seen = {}
    for _, k in ipairs(prio) do
        local v = hdr[k]
        if type(v) == "table" then v = table.concat(v, ", ") end
        if v and v ~= "" then
            lines[#lines + 1] = k .. ": " .. tostring(v)
            seen[k] = true
        end
    end
    local n = 0
    for k, v in pairs(hdr) do
        local lk = string.lower(tostring(k))
        if not seen[lk] and n < 20 then
            if type(v) == "table" then v = table.concat(v, ", ") end
            lines[#lines + 1] = lk .. ": " .. tostring(v)
            n = n + 1
        end
    end
    local b = body
    if b == nil then
        local okb, rb = pcall(ngx.req.get_body_data)
        if okb then b = rb end
    end
    if b and b ~= "" then
        if #b > 2000 then b = string.sub(b, 1, 2000) .. "\n...[已截断]" end
        lines[#lines + 1] = ""
        lines[#lines + 1] = b
    end
    return table.concat(lines, "\n")
end

-- 写一条站点日志：同时累计统计、按站点分文件落盘
local function write_log(site, kind, type_name, filter, rule, value, http_info)
    if not cjson_ok then return end
    local full = tostring(value or "")
    if #full > 1000 then full = string.sub(full, 1, 1000) .. "...[已截断]" end
    if http_info == nil then
        local okd, d = pcall(http_dump)
        http_info = okd and d or ""
    end
    local arr = {
        ngx.localtime(),                          -- [0] 时间
        ngx.var.remote_addr or "",                -- [1] 用户IP
        type_name,                                -- [2] 类型
        ngx.var.request_uri or "",                -- [3] URI地址
        ngx.var.http_user_agent or "",            -- [4] User-Agent
        filter,                                   -- [5] 过滤器
        tostring(rule or "") .. " >> " .. full,   -- [6] 过滤规则 >> 传入值（完整）
        tostring(http_info or "")                 -- [7] 完整 HTTP 报文
    }
    local ok, line = pcall(cjson.encode, arr)
    if not ok then return end
    local path = LOG_DIR .. "/" .. (site or "_default") .. "_" .. ngx.today() .. ".log"
    local f = io.open(path, "a")
    if f then
        f:write(line, "\n")
        f:close()
    end
    queue_alert(site, kind, ngx.var.request_uri, value, rule)
    inc("T")
    inc("r:" .. kind)
    if site then
        inc("n:" .. site)
        inc("s:" .. site .. ":" .. kind)
    end
end

-- 直接拉黑
local function ban_ip(ip, site, seconds, reason)
    if not DROP or not ip or ip == "" then return end
    seconds = tonumber(seconds) or 600
    if seconds <= 0 then seconds = 600 end
    DROP:set(ip, now_ts() + seconds, seconds)
    if cjson_ok then
        local ok, line = pcall(cjson.encode, { now_ts(), ip, site or "_default", 0, seconds, reason or "retry", "" })
        if ok then
            local f = io.open(XWAF.path .. "/drop_ip.log", "a")
            if f then f:write(line, "\n"); f:close() end
        end
    end
    inc("r:" .. ((reason == "cc") and "cc" or "head"))
end

-- 容忍阈值：cycle 秒内累计命中 retry 次 → 封 retry_time 秒
-- 对应面板「全局配置 → 非法请求容忍阈值」的三个参数
local function penalize(ip, site)
    if not SUM or not ip or ip == "" then return end
    local cycle = tonumber(cfg.retry_cycle) or 60
    local retry = tonumber(cfg.retry) or 3
    if retry <= 0 then return end
    local key = "bad:" .. ip
    local n = SUM:incr(key, 1, 0, cycle)
    if not n then
        n = (SUM:get(key) or 0) + 1
        SUM:set(key, n, cycle)
    end
    if n >= retry then
        SUM:delete(key)
        ban_ip(ip, site, cfg.retry_time or 600, "retry")
    end
end

-- 记录待拦截结果；ngx.exit 必须放在 pcall 之外
-- （lua-nginx-module 的 ngx.exit 靠抛异常终止请求，在 pcall 里会被吞掉 → 该拦的没拦）
local BLOCK = nil
-- 拦截收尾：按配置的响应码输出拦截页（444 直接断连）
local function block(kind, code)
    code = tonumber(code) or 403
    BLOCK = {
        code = code,
        kind = kind,
        page = (XWAF.html and (XWAF.html[kind] or XWAF.html.base)) or "Blocked by x_waf"
    }
    return nil
end

-- 在规则列表里逐条匹配，返回命中的规则名和正则
local function match_rules(list, subject, disable)
    -- 空字符串也要参与匹配（UA 黑名单里有 ^$ 这种"空 UA"规则）
    if type(list) ~= "table" or subject == nil then return nil end
    for _, r in ipairs(list) do
        if not (disable and disable[r.idx]) then
            local from, to, err = ngx.re.find(subject, r.pat, "jo")
            if from then
                return r, string.sub(subject, from, to)
            elseif err then
                ngx.log(ngx.ERR, "x_waf bad rule [", r.pat, "]: ", err)
            end
        end
    end
    return nil
end

-- 在一组正则里找第一个命中的，返回正则本身
local function match_list(list, subject)
    if type(list) ~= "table" or subject == nil or subject == "" then return nil end
    for _, pat in ipairs(list) do
        local from, to = ngx.re.find(subject, pat, "jo")
        if from then return pat, string.sub(subject, from, to) end
    end
    return nil
end

-- 站点解析：host -> 站点名
local function resolve_site()
    if not XWAF.sites then return nil, nil end
    local host = ngx.var.host
    if host then
        host = string.lower(host)
        local name = XWAF.domains and XWAF.domains[host]
        if name and XWAF.sites[name] then return name, XWAF.sites[name] end
        if XWAF.sites[host] then return host, XWAF.sites[host] end
        local bare = string.gsub(host, "^www%.", "")
        if XWAF.domains and XWAF.domains[bare] then
            local n2 = XWAF.domains[bare]
            if XWAF.sites[n2] then return n2, XWAF.sites[n2] end
        end
        if XWAF.sites[bare] then return bare, XWAF.sites[bare] end

        -- 没匹配到站点：每个 host 每 5 分钟记一条，方便排查"站点统计为空"
        if DICT and DICT:add("warnhost:" .. host, 1, 300) then
            ngx.log(ngx.WARN, "x_waf: 未匹配到站点配置 host=", host,
                    "，该请求的日志会写到 _default_*.log 且不计入站点统计")
        end
    end
    return nil, nil
end

-- ---------------------------------------------------------------- 内部接口
local function internal_api(uri)
    if not cjson_ok then return false end
    if uri == "/get_btwaf_drop_ip" then
        local list = {}
        if DROP then
            local keys = DROP:get_keys(0)
            local ts = now_ts()
            for _, ip in ipairs(keys) do
                local exp = DROP:get(ip)
                if exp and exp > ts then
                    list[#list + 1] = ip
                elseif exp then
                    DROP:delete(ip)
                end
            end
        end
        ngx.header["Content-Type"] = "application/json"
        ngx.print(cjson.encode(list))
        return true
    end
    if uri == "/remove_btwaf_drop_ip" then
        local ip = ngx.var.arg_ip
        if DROP and ip and ip ~= "" then DROP:delete(ip) end
        ngx.header["Content-Type"] = "application/json"
        ngx.print(cjson.encode({ status = true, msg = "已解封 IP " .. tostring(ip or "") }))
        return true
    end
    if uri == "/clean_btwaf_drop_ip" then
        if DROP then DROP:flush_all() end
        ngx.header["Content-Type"] = "application/json"
        ngx.print(cjson.encode({ status = true, msg = "已解封全部 IP" }))
        return true
    end
    return false
end

-- ---------------------------------------------------------------- 站点级策略
local function site_policy(sc, site, uri, ip)
    if not sc then return nil end

    -- 1) 禁止的扩展名（站点配置：禁止的扩展名）
    local ext_list = sc.disable_ext
    if type(ext_list) == "table" and #ext_list > 0 then
        local lower = string.lower(uri)
        for _, ext in ipairs(ext_list) do
            ext = tostring(ext):gsub("^%.", "")
            if ext ~= "" and string.sub(lower, -(#ext + 1)) == "." .. ext then
                write_log(site, "url", "禁止的扩展名", "disable_ext", "禁止访问 ." .. ext, uri)
                penalize(ip, site)
                return block("other", 403)
            end
        end
    end

    -- 2) 禁止执行 PHP 的路径（站点配置：禁止PHP脚本）
    local php_path = sc.disable_php_path
    if type(php_path) == "table" and #php_path > 0 and string.find(string.lower(uri), "%.php") then
        for _, pat in ipairs(php_path) do
            local from = ngx.re.find(uri, pat, "jo")
            if from then
                write_log(site, "url", "禁止PHP脚本", "disable_php_path", pat, uri)
                penalize(ip, site)
                return block("other", 403)
            end
        end
    end

    -- 3) 自定义 URI 拦截（站点配置：url_rule = [[uri, 正则], ...]）
    local url_rule = sc.url_rule
    if type(url_rule) == "table" then
        for _, item in ipairs(url_rule) do
            if type(item) == "table" and type(item[1]) == "string" and type(item[2]) == "string" then
                if string.find(uri, item[1], 1, true) then
                    local subject = (ngx.var.request_uri or "") .. " " .. (ngx.var.args or "")
                    local from = ngx.re.find(subject, item[2], "jo")
                    if from then
                        write_log(site, "url_rule", "URI自定义拦截", "url_rule", item[2], item[1])
                        penalize(ip, site)
                        return block("other", 403)
                    end
                end
            end
        end
    end
    return nil
end

-- ---------------------------------------------------------------- 主流程
local function main()
    local method = ngx.req.get_method()
    local uri = ngx.var.uri or "/"
    local raw_uri = ngx.var.request_uri or uri
    local raw_args = ngx.var.args or ""
    local ip = ngx.var.remote_addr or ""
    local ipn = XWAF.ip2n(ip)

    -- 面板/本机调用的内部接口
    if ip == "127.0.0.1" or ip == "::1" then
        if internal_api(uri) then return end
    end

    if cfg.open == false then return end

    local site, sc = resolve_site()
    if sc and sc.open == false then return end

    -- 1) 封禁期内
    if DROP then
        local exp = DROP:get(ip)
        if exp then
            if exp > now_ts() then
                write_log(site, "head", "IP黑名单", "drop_ip", "封禁期内访问", uri)
                return block("other", (cfg.cc and cfg.cc.status) or 403)
            end
            DROP:delete(ip)
        end
    end

    -- 2) IP 白名单 / 黑名单
    if #XWAF.ip_white > 0 and XWAF.in_range(XWAF.ip_white, ipn) then
        return
    end
    if #XWAF.ip_black > 0 and XWAF.in_range(XWAF.ip_black, ipn) then
        write_log(site, "head", "IP黑名单", "ip_black", "IP黑名单命中", ip)
        ban_ip(ip, site, cfg.retry_time or 600, "retry")
        return block("other", 403)
    end

    -- 3) 禁止海外访问
    local drop_abroad = (sc and sc.drop_abroad) or (cfg.drop_abroad and cfg.drop_abroad.open)
    if drop_abroad and #XWAF.cn > 0 and ipn and not XWAF.in_range(XWAF.cn, ipn) then
        write_log(site, "head", "禁止海外访问", "drop_abroad", "非国内IP", ip)
        penalize(ip, site)
        return block("other", 403)
    end

    -- 4) CC 防御
    local cc = (sc and sc.cc) or cfg.cc
    if cc and cc.open and SUM then
        local key = "cc:" .. tostring(site or "_") .. ":" .. ip
        local cycle = tonumber(cc.cycle) or 60
        local limit = tonumber(cc.limit) or 120
        local endtime = tonumber(cc.endtime) or 600
        local cnt = SUM:incr(key, 1, 0, cycle)
        if not cnt then
            cnt = (SUM:get(key) or 0) + 1
            SUM:set(key, cnt, cycle)
        end
        if cnt > limit then
            write_log(site, "cc", "CC攻击", "cc",
                string.format("%d秒内请求超过%d次", cycle, limit), uri)
            ban_ip(ip, site, endtime, "cc")
            return block("other", cc.status or 503)
        end
    end

    -- 4.5) 按 URL 限频（IP 维度 + Key 维度，规则来自面板「URL限频」页）
    if XWAF.limit_mod and type(XWAF.limits) == "table" and #XWAF.limits > 0 then
        local hitl = XWAF.limit_mod.check(XWAF.limits, raw_uri, uri, ip, ngx.req.get_uri_args(100))
        if hitl then
            local desc = string.format("%d秒内超过%d次", hitl.cycle, hitl.limit)
            if hitl.dim == "ip" then
                write_log(site, "limit", "访问频率超限", "limit_ip", desc, hitl.value)
            else
                write_log(site, "limit", "访问频率超限", "limit_key", desc, hitl.value)
            end
            penalize(ip, site)
            ngx.header["Retry-After"] = tostring(hitl.cycle)
            return block("other", hitl.status or 429)
        end
    end

    local ua = ngx.var.http_user_agent or ""
    local cookie = ngx.var.http_cookie or ""

    -- 5) URL 白名单：命中则整体跳过
    if #XWAF.url_white > 0 then
        if match_list(XWAF.url_white, raw_uri) or match_list(XWAF.url_white, uri) then return end
    end

    -- 6) URL 黑名单
    if #XWAF.url_black > 0 then
        local pat, hit = match_list(XWAF.url_black, raw_uri)
        if not pat then pat, hit = match_list(XWAF.url_black, uri) end
        if pat then
            write_log(site, "url", "URI自定义拦截", "url_black", pat, raw_uri)
            penalize(ip, site)
            return block("other", 403)
        end
    end

    -- 7) 站点级策略
    local p = site_policy(sc, site, uri, ip)
    if p then return p end

    -- 8) User-Agent
    local ua_open = (sc and sc["user-agent"]) or (cfg["user-agent"] and cfg["user-agent"].open)
    if ua_open then
        local disable = sc and sc.disable_rule and sc.disable_rule.user_agent
        local r, hit = match_rules(XWAF.rules.user_agent, ua, disable)
        if r then
            write_log(site, "user_agent", "恶意User-Agent", "user_agent", r.pat, ua)
            penalize(ip, site)
            return block("user-agent", (cfg["user-agent"] and cfg["user-agent"].status) or 403)
        end
    end

    -- 9) 常见扫描器（header / cookie / args）
    local scan_open = (sc and sc.scan) or (cfg.scan and cfg.scan.open)
    if scan_open and XWAF.scan then
        local hdr = ngx.req.get_headers()
        local hbuf = {}
        for k, v in pairs(hdr) do
            if type(v) == "table" then v = table.concat(v, ",") end
            hbuf[#hbuf + 1] = tostring(k) .. ": " .. tostring(v)
        end
        local hstr = table.concat(hbuf, "\n")
        local r1, hit1 = match_list(XWAF.scan.header, hstr)
        local r2, hit2 = match_list(XWAF.scan.cookie, cookie)
        if r1 or r2 then
            write_log(site, "scan", "恶意扫描", "scan", r1 or r2, r1 and hstr or cookie)
            penalize(ip, site)
            return block("other", (cfg.scan and cfg.scan.status) or 403)
        end
    end

    -- 10) Cookie
    local cookie_open = (sc and sc.cookie) or (cfg.cookie and cfg.cookie.open)
    if cookie_open and cookie ~= "" then
        local disable = sc and sc.disable_rule and sc.disable_rule.cookie
        local r, hit = match_rules(XWAF.rules.cookie, cookie, disable)
        if r then
            write_log(site, "cookie", "Cookie渗透", "cookie", r.pat, cookie)
            penalize(ip, site)
            return block("cookie", (cfg.cookie and cfg.cookie.status) or 403)
        end
    end

    -- 11) URL 路径规则：解码后的 uri + 原始 request_uri 都查
    local get_open = (sc and sc.get) or (cfg.get and cfg.get.open)
    if get_open then
        local duri = sc and sc.disable_rule and sc.disable_rule.url
        local r, hit = match_rules(XWAF.rules.url, uri, duri)
        if not r and raw_uri ~= uri then
            r, hit = match_rules(XWAF.rules.url, raw_uri, duri)
        end
        if r then
            write_log(site, "url", "GET渗透", "url", r.pat, raw_uri)
            penalize(ip, site)
            return block("get", (cfg.get and cfg.get.status) or 403)
        end

        -- 12) GET 参数：解析后的每个值 + 整个原始查询串都查
        local dargs = sc and sc.disable_rule and sc.disable_rule.args
        local args = ngx.req.get_uri_args(100)
        for _, v in pairs(args) do
            if type(v) == "table" then v = table.concat(v, "&") end
            local r2, hit2 = match_rules(XWAF.rules.args, tostring(v), dargs)
            if r2 then
                write_log(site, "args", "GET渗透", "args", r2.pat, tostring(v))
                penalize(ip, site)
                return block("get", (cfg.get and cfg.get.status) or 403)
            end
        end
        if raw_args ~= "" then
            local r3, hit3 = match_rules(XWAF.rules.args, raw_args, dargs)
            if r3 then
                write_log(site, "args", "GET渗透", "args", r3.pat, raw_args)
                penalize(ip, site)
                return block("get", (cfg.get and cfg.get.status) or 403)
            end
            local r4, hit4 = match_list(XWAF.scan.args, raw_args)
            if r4 then
                write_log(site, "scan", "恶意扫描", "scan", r4, raw_args)
                penalize(ip, site)
                return block("get", (cfg.scan and cfg.scan.status) or 403)
            end
        end
    end

    -- 13) POST body
    local post_open = (sc and sc.post) or (cfg.post and cfg.post.open)
    if post_open and (method == "POST" or method == "PUT" or method == "PATCH") then
        local lctype = string.lower(ngx.var.content_type or "")
        if cfg.from_data and string.find(lctype, "multipart/form%-data", 1) then
            if not string.find(lctype, "boundary=", 1) then
                write_log(site, "head", "From-data协议异常", "from_data", "缺少 boundary", raw_uri)
                penalize(ip, site)
                return block("post", (cfg.post and cfg.post.status) or 403)
            end
        end
        ngx.req.read_body()
        local body = ngx.req.get_body_data()
        if not body then
            local bf = ngx.req.get_body_file()
            if bf then
                local f = io.open(bf, "rb")
                if f then body = f:read("*a"); f:close() end
            end
        end
        if body and body ~= "" then
            local dpost = sc and sc.disable_rule and sc.disable_rule.post
            local r, hit = match_rules(XWAF.rules.post, body, dpost)
            if r then
                write_log(site, "post", "POST渗透", "post", r.pat, body)
                penalize(ip, site)
                return block("post", (cfg.post and cfg.post.status) or 403)
            end
            local r2, hit2 = match_list(XWAF.scan.args, body)
            if r2 then
                write_log(site, "scan", "恶意扫描", "scan", r2, body)
                penalize(ip, site)
                return block("post", (cfg.scan and cfg.scan.status) or 403)
            end
        end
    end
end

-- 引擎自身出错只记日志，不影响站点
local ok, err = pcall(main)
if not ok then
    ngx.log(ngx.ERR, "x_waf crashed: ", tostring(err))
end

-- 拦截动作在 pcall 之外执行
if BLOCK then
    local code = BLOCK.code
    if code == 444 then
        return ngx.exit(444)
    end
    ngx.status = code
    ngx.header["Content-Type"] = "text/html; charset=utf-8"
    if BLOCK.kind == "user-agent" then
        ngx.header["Server"] = "nginx"
    end
    ngx.print(BLOCK.page)
    return ngx.exit(code)
end
